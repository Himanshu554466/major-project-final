import React, { useEffect, useState } from 'react';
import { User, Phone, Mail, Shield, Edit3, Save, X, Lock, Eye, EyeOff, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';

interface Profile {
  username: string;
  email: string;
  phone?: string;
  role: string;
}

export default function Account() {
  const { user, login, token } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState({ username: '', phone: '' });
  const [saving, setSaving] = useState(false);
  const [profileMsg, setProfileMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Password change
  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '', confirmNewPassword: '' });
  const [showPw, setShowPw] = useState({ current: false, new: false, confirm: false });
  const [changingPw, setChangingPw] = useState(false);
  const [pwMsg, setPwMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    // Pre-fill from AuthContext immediately so page isn't blank
    if (user) {
      setProfile({ username: user.username || '', email: user.email, phone: user.phone || '', role: user.role });
      setForm({ username: user.username || '', phone: user.phone || '' });
      setLoading(false);
    }
    // Then fetch fresh data from API
    api.get('/customer/profile')
      .then(res => {
        const p: Profile = res.data.user || res.data.profile || res.data;
        if (p && p.email) {
          setProfile(p);
          setForm({ username: p.username || '', phone: p.phone || '' });
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [user]);

  const handleSaveProfile = async () => {
    setSaving(true);
    setProfileMsg(null);
    try {
      const res = await api.put('/customer/profile', { username: form.username, phone: form.phone });
      const updated: Profile = res.data.user || res.data.profile || res.data;
      setProfile(updated);
      if (token && user) {
        login(token, { ...user, username: updated.username, phone: updated.phone });
      }
      setEditMode(false);
      setProfileMsg({ type: 'success', text: 'Profile updated successfully!' });
      setTimeout(() => setProfileMsg(null), 3000);
    } catch {
      setProfileMsg({ type: 'error', text: 'Failed to update profile.' });
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pwForm.newPassword !== pwForm.confirmNewPassword) {
      setPwMsg({ type: 'error', text: 'New passwords do not match.' });
      return;
    }
    if (pwForm.newPassword.length < 6) {
      setPwMsg({ type: 'error', text: 'Password must be at least 6 characters.' });
      return;
    }
    setChangingPw(true);
    setPwMsg(null);
    try {
      await api.put('/customer/change-password', {
        currentPassword: pwForm.currentPassword,
        newPassword: pwForm.newPassword,
      });
      setPwMsg({ type: 'success', text: 'Password changed successfully!' });
      setPwForm({ currentPassword: '', newPassword: '', confirmNewPassword: '' });
      setTimeout(() => setPwMsg(null), 3000);
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
      setPwMsg({ type: 'error', text: msg || 'Failed to change password.' });
    } finally {
      setChangingPw(false);
    }
  };

  const getInitials = (name?: string, email?: string) => {
    if (name) return name.slice(0, 2).toUpperCase();
    if (email) return email.slice(0, 2).toUpperCase();
    return 'U';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">My Account</h1>

        {/* Profile Card */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-5">
          {/* Avatar + Name */}
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-orange-400 to-indigo-500 flex items-center justify-center text-white text-xl font-bold flex-shrink-0">
              {getInitials(profile?.username, profile?.email)}
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-800">{profile?.username || 'User'}</h2>
              <p className="text-sm text-gray-500">{profile?.email}</p>
              <span className="inline-flex items-center gap-1 mt-1 text-xs bg-indigo-100 text-indigo-600 px-2.5 py-0.5 rounded-full font-medium capitalize">
                <Shield className="w-3 h-3" /> {profile?.role}
              </span>
            </div>
            {!editMode && (
              <button
                onClick={() => setEditMode(true)}
                className="ml-auto flex items-center gap-1.5 text-sm text-orange-500 hover:text-orange-600 font-medium border border-orange-200 hover:border-orange-400 px-3 py-1.5 rounded-lg transition-colors"
              >
                <Edit3 className="w-4 h-4" /> Edit
              </button>
            )}
          </div>

          {profileMsg && (
            <div className={`mb-4 flex items-center gap-2 text-sm px-4 py-3 rounded-xl ${
              profileMsg.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'
            }`}>
              {profileMsg.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              {profileMsg.text}
            </div>
          )}

          {/* Profile Fields */}
          <div className="space-y-4">
            {/* Email (read-only) */}
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
                Email Address
              </label>
              <div className="flex items-center gap-3 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3">
                <Mail className="w-4 h-4 text-gray-400 flex-shrink-0" />
                <span className="text-sm text-gray-600">{profile?.email}</span>
                <span className="ml-auto text-xs text-gray-400 bg-gray-200 px-2 py-0.5 rounded-full">Read-only</span>
              </div>
            </div>

            {/* Username */}
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
                Username
              </label>
              {editMode ? (
                <div className="flex items-center gap-3 border border-orange-300 rounded-xl px-4 py-3 bg-orange-50">
                  <User className="w-4 h-4 text-orange-400 flex-shrink-0" />
                  <input
                    type="text"
                    value={form.username}
                    onChange={e => setForm(prev => ({ ...prev, username: e.target.value }))}
                    className="flex-1 bg-transparent text-sm text-gray-800 outline-none"
                    placeholder="Enter username"
                  />
                </div>
              ) : (
                <div className="flex items-center gap-3 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3">
                  <User className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  <span className="text-sm text-gray-700">{profile?.username || '—'}</span>
                </div>
              )}
            </div>

            {/* Phone */}
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
                Phone Number
              </label>
              {editMode ? (
                <div className="flex items-center gap-3 border border-orange-300 rounded-xl px-4 py-3 bg-orange-50">
                  <Phone className="w-4 h-4 text-orange-400 flex-shrink-0" />
                  <input
                    type="tel"
                    value={form.phone}
                    onChange={e => setForm(prev => ({ ...prev, phone: e.target.value }))}
                    className="flex-1 bg-transparent text-sm text-gray-800 outline-none"
                    placeholder="Enter phone number"
                  />
                </div>
              ) : (
                <div className="flex items-center gap-3 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3">
                  <Phone className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  <span className="text-sm text-gray-700">{profile?.phone || '—'}</span>
                </div>
              )}
            </div>

            {/* Edit Actions */}
            {editMode && (
              <div className="flex gap-3 pt-2">
                <button
                  onClick={handleSaveProfile}
                  disabled={saving}
                  className="flex-1 bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300 text-white font-semibold py-2.5 rounded-xl flex items-center justify-center gap-2 transition-colors"
                >
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  {saving ? 'Saving...' : 'Save Changes'}
                </button>
                <button
                  onClick={() => {
                    setEditMode(false);
                    setForm({ username: profile?.username || '', phone: profile?.phone || '' });
                  }}
                  className="px-4 py-2.5 border border-gray-200 rounded-xl text-gray-600 hover:bg-gray-50 flex items-center gap-1.5 text-sm"
                >
                  <X className="w-4 h-4" /> Cancel
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Change Password */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <Lock className="w-5 h-5 text-orange-500" /> Change Password
          </h2>

          {pwMsg && (
            <div className={`mb-4 flex items-center gap-2 text-sm px-4 py-3 rounded-xl ${
              pwMsg.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'
            }`}>
              {pwMsg.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
              {pwMsg.text}
            </div>
          )}

          <form onSubmit={handleChangePassword} className="space-y-4">
            {[
              { key: 'currentPassword', label: 'Current Password', showKey: 'current' as const },
              { key: 'newPassword', label: 'New Password', showKey: 'new' as const },
              { key: 'confirmNewPassword', label: 'Confirm New Password', showKey: 'confirm' as const },
            ].map(field => (
              <div key={field.key}>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">
                  {field.label}
                </label>
                <div className="flex items-center border border-gray-200 rounded-xl px-4 py-3 focus-within:border-orange-400 transition-colors">
                  <Lock className="w-4 h-4 text-gray-400 flex-shrink-0 mr-3" />
                  <input
                    type={showPw[field.showKey] ? 'text' : 'password'}
                    value={(pwForm as Record<string, string>)[field.key]}
                    onChange={e => setPwForm(prev => ({ ...prev, [field.key]: e.target.value }))}
                    placeholder={field.label}
                    className="flex-1 text-sm text-gray-800 outline-none bg-transparent"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw(prev => ({ ...prev, [field.showKey]: !prev[field.showKey] }))}
                    className="text-gray-400 hover:text-gray-600 ml-2"
                  >
                    {showPw[field.showKey] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            ))}

            <button
              type="submit"
              disabled={changingPw}
              className="w-full bg-indigo-500 hover:bg-indigo-600 disabled:bg-indigo-300 text-white font-semibold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              {changingPw ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
              {changingPw ? 'Changing...' : 'Change Password'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
