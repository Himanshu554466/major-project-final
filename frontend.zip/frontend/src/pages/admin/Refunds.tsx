import { useEffect, useState, useCallback } from 'react';
import {
  RotateCcw, CheckCircle, ChevronLeft, ChevronRight,
  Loader2, AlertCircle, User, Package, Clock,
  CreditCard, RefreshCw,
} from 'lucide-react';
import API from '../../services/api';

interface Customer { id: number; email: string; username?: string; phone?: string; }
interface OrderItem { id: string; quantity: number; price: number; product: { title: string } }
interface ReturnShipment { id: number; status: string; trackingEvents: { status: string; message: string; timestamp: string }[] }

interface RefundOrder {
  id: number;
  status: string;
  paymentStatus: string;
  paymentMethod: string;
  totalAmount: number;
  returnReason?: string;
  createdAt: string;
  updatedAt: string;
  customer: Customer;
  items: OrderItem[];
  returnShipment?: ReturnShipment | null;
}

interface Stats { pending: number; completed: number; totalRefunded: number; }

const STATUS_BADGE: Record<string, string> = {
  refund_initiated: 'bg-yellow-100 text-yellow-700',
  refund_completed: 'bg-green-100 text-green-700',
  returned: 'bg-teal-100 text-teal-700',
};

// refund methods removed — not currently used in admin view

// (Process modal removed — not used by current admin UI)

// ── Main Component ───────────────────────────────────────────────────────────
export default function AdminRefunds() {
  const [orders, setOrders] = useState<RefundOrder[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('refund_initiated');
  const [loading, setLoading] = useState(true);
  const [toast] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  const fetchStats = useCallback(() => {
    API.get('/admin/refunds/stats').then(res => setStats(res.data)).catch(() => {});
  }, []);

  const fetchOrders = useCallback(() => {
    setLoading(true);
    API.get(`/admin/refunds?page=${page}&limit=15&status=${statusFilter}`)
      .then(res => {
        setOrders(res.data.orders || []);
        setTotal(res.data.total || 0);
        setPages(res.data.pages || 1);
      })
      .catch(() => setOrders([]))
      .finally(() => setLoading(false));
  }, [page, statusFilter]);

  useEffect(() => { fetchStats(); }, [fetchStats]);
  useEffect(() => { fetchOrders(); }, [fetchOrders]);

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

  return (
    <div className="max-w-6xl mx-auto py-8 px-4">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.type === 'success' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'
        }`}>
          {toast.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
            <RotateCcw className="w-5 h-5 text-gray-700" /> Refunds (View Only)
          </h1>
          <p className="text-sm text-gray-400 mt-0.5">Refunds are processed by sellers. Admin view only.</p>
        </div>
        <button onClick={() => { fetchOrders(); fetchStats(); }}
          className="flex items-center gap-1.5 px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50">
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
            <p className="text-xs font-semibold text-yellow-600 uppercase tracking-wider">Pending Refunds</p>
            <p className="text-3xl font-bold text-yellow-700 mt-1">{stats.pending}</p>
            <p className="text-xs text-yellow-600 mt-1">Awaiting admin action</p>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-xl p-4">
            <p className="text-xs font-semibold text-green-600 uppercase tracking-wider">Completed</p>
            <p className="text-3xl font-bold text-green-700 mt-1">{stats.completed}</p>
            <p className="text-xs text-green-600 mt-1">Refunds processed</p>
          </div>
          <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4">
            <p className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">Total Refunded</p>
            <p className="text-2xl font-bold text-indigo-700 mt-1">₹{stats.totalRefunded.toLocaleString('en-IN')}</p>
            <p className="text-xs text-indigo-600 mt-1">All time</p>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-2 mb-5">
        {[
          { value: 'refund_initiated', label: '⏳ Pending' },
          { value: 'refund_completed', label: '✅ Completed' },
          { value: 'all', label: 'All' },
        ].map(f => (
          <button key={f.value} onClick={() => { setStatusFilter(f.value); setPage(1); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              statusFilter === f.value ? 'bg-gray-800 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
            }`}>
            {f.label}
          </button>
        ))}
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex items-center justify-center h-48">
          <Loader2 className="w-8 h-8 animate-spin text-gray-500" />
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-16 bg-white border border-gray-200 rounded-xl">
          <RotateCcw className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="text-sm text-gray-400">No refunds found</p>
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Order</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Customer</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Items</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Amount</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Return Status</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Payment</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Date</th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {orders.map(order => (
                  <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <p className="font-mono text-xs text-gray-600">#{String(order.id).padStart(6, '0')}</p>
                      {order.returnReason && (
                        <p className="text-xs text-pink-600 mt-0.5 max-w-[120px] truncate" title={order.returnReason}>
                          ↩ {order.returnReason}
                        </p>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                          <User className="w-3.5 h-3.5 text-gray-400" />
                        </div>
                        <div>
                          <p className="text-xs font-medium text-gray-800">{order.customer.username || '—'}</p>
                          <p className="text-xs text-gray-400">{order.customer.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <Package className="w-3.5 h-3.5 text-gray-400" />
                        <span className="text-xs text-gray-600">{order.items?.length || 0} item(s)</span>
                      </div>
                      <p className="text-xs text-gray-400 mt-0.5 max-w-[120px] truncate">
                        {order.items?.[0]?.product?.title}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="font-bold text-gray-900">₹{order.totalAmount.toLocaleString('en-IN')}</p>
                      <p className="text-xs text-gray-400 capitalize">{order.paymentMethod?.replace(/_/g, ' ')}</p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${STATUS_BADGE[order.status] || 'bg-gray-100 text-gray-600'}`}>
                        {order.status.replace(/_/g, ' ')}
                      </span>
                      {order.returnShipment && (
                        <p className="text-xs text-gray-400 mt-0.5">
                          Shipment: {order.returnShipment.status.replace(/_/g, ' ')}
                        </p>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <CreditCard className="w-3.5 h-3.5 text-gray-400" />
                        <span className={`text-xs font-medium capitalize ${
                          order.paymentStatus === 'refunded' ? 'text-green-600' :
                          order.paymentStatus === 'paid' ? 'text-blue-600' : 'text-gray-600'
                        }`}>{order.paymentStatus}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Clock className="w-3 h-3" />
                        {formatDate(order.updatedAt)}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1.5">
                        {order.status === 'refund_initiated' && (
                          <span className="text-xs text-yellow-600 font-medium bg-yellow-50 px-2 py-1 rounded-lg">
                            ⏳ Seller processing
                          </span>
                        )}
                        {order.status === 'refund_completed' && (
                          <span className="flex items-center gap-1 text-xs text-green-600 font-medium">
                            <CheckCircle className="w-3.5 h-3.5" /> Done
                          </span>
                        )}
                        {order.status === 'returned' && (
                          <span className="text-xs text-gray-400 italic">Awaiting seller</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Pagination */}
      {pages > 1 && (
        <div className="flex items-center justify-between mt-5">
          <p className="text-sm text-gray-500">Page {page} of {pages} ({total} total)</p>
          <div className="flex gap-2">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button onClick={() => setPage(p => Math.min(pages, p + 1))} disabled={page === pages}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
