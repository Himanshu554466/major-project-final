/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Brand accent (indigo/violet). The former "orange" scale is remapped to
        // violet shades so the entire UI is re-themed from this single file.
        primary: { 50: '#eef2ff', 100: '#e0e7ff', 500: '#6366f1', 600: '#4f46e5', 700: '#4338ca' },
        indigo: { 600: '#4f46e5', 700: '#4338ca' },
        orange: {
          50: '#f5f3ff', 100: '#ede9fe', 200: '#ddd6fe', 300: '#c4b5fd',
          400: '#a78bfa', 500: '#7c3aed', 600: '#6d28d9', 700: '#5b21b6',
          800: '#4c1d95', 900: '#3b0764', 950: '#2e1065',
        },
      },
    },
  },
  plugins: [],
}
