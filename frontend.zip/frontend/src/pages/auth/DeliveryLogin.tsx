import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const DeliveryLogin: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      setLoading(true);
      const res = await api.post('/auth/login', { email, password, role: 'delivery_partner' });
      login(res.data.token, res.data.user);
      navigate('/delivery/dashboard');
    } catch (err: unknown) {
      setError((err as { response?: { data?: { message?: string } } })?.response?.data?.message || 'Invalid credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#EAEDED] flex flex-col items-center pt-8 pb-16 px-4">
      {/* Logo */}
      <Link to="/" className="mb-6">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-[#6d28d9] rounded-md flex items-center justify-center">
            <span className="text-white font-black text-lg">E</span>
          </div>
          <span className="font-black text-2xl text-[#1e1b4b] tracking-tight">Ecom<span className="text-[#6d28d9]">merce</span></span>
        </div>
      </Link>

      <div className="w-full max-w-sm bg-white border border-[#ddd] rounded-lg overflow-hidden">
        {/* Portal header — green theme */}
        <div className="bg-[#1a3a2a] px-6 py-4 flex items-center gap-3">
          <div className="w-10 h-10 bg-[#6d28d9] rounded-lg flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0" />
            </svg>
          </div>
          <div>
            <p className="text-white font-bold text-base leading-tight">Delivery Partner Portal</p>
            <p className="text-[#86b89a] text-xs">Manage your deliveries & earnings</p>
          </div>
        </div>

        <div className="p-6">
          <h1 className="text-xl font-medium text-[#0f1111] mb-5">Sign in to deliver</h1>

          {error && (
            <div className="mb-4 p-3 bg-[#fff8f0] border border-[#e77600] rounded text-sm text-[#5b21b6] flex items-start gap-2">
              <svg className="w-4 h-4 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[#0f1111] mb-1">Email address</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30"
                required />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0f1111] mb-1">Password</label>
              <div className="relative">
                <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)}
                  className="w-full px-3 py-2 pr-10 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30"
                  required />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#0066c0] hover:text-[#5b21b6] hover:underline">
                  {showPassword ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-2 bg-[#FFD814] hover:bg-[#7c3aed] border border-[#FCD200] rounded text-sm font-semibold text-[#111] transition-colors disabled:opacity-60">
              {loading ? 'Signing in...' : 'Sign in'}
            </button>
          </form>

          <div className="mt-5 pt-4 border-t border-[#eee]">
            <p className="text-sm text-[#0f1111]">
              New delivery partner?{' '}
              <Link to="/delivery/register" className="text-[#0066c0] hover:text-[#5b21b6] hover:underline font-medium">
                Register here
              </Link>
            </p>
          </div>
        </div>
      </div>

      {/* Earnings info */}
      <div className="w-full max-w-sm mt-4 bg-white border border-[#ddd] rounded-lg p-4">
        <p className="text-xs font-bold text-[#0f1111] mb-3">Why deliver with Ecommerce?</p>
        <div className="space-y-2">
          {['Earn ₹50+ per delivery', 'Flexible working hours', 'Weekly payouts'].map(b => (
            <div key={b} className="flex items-center gap-2 text-xs text-[#555]">
              <svg className="w-3.5 h-3.5 text-[#007600] shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
              {b}
            </div>
          ))}
        </div>
      </div>

      <div className="w-full max-w-sm mt-5 flex items-center gap-3">
        <div className="flex-1 h-px bg-[#ddd]" />
        <span className="text-xs text-[#767676]">Other portals</span>
        <div className="flex-1 h-px bg-[#ddd]" />
      </div>
      <div className="w-full max-w-sm mt-3 grid grid-cols-3 gap-2">
        {[{ to: '/login', label: 'Customer' }, { to: '/seller/login', label: 'Seller' }, { to: '/admin/login', label: 'Admin' }].map(p => (
          <Link key={p.to} to={p.to}
            className="py-2 border border-[#ddd] rounded text-xs text-center text-[#0066c0] hover:bg-[#f0f0f0] hover:text-[#5b21b6] transition-colors bg-white">
            {p.label}
          </Link>
        ))}
      </div>
    </div>
  );
};

export default DeliveryLogin;
