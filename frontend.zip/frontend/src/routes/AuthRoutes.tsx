import { Route } from 'react-router-dom';

import CustomerLogin from '../pages/auth/CustomerLogin';
import CustomerRegister from '../pages/auth/CustomerRegister';
import SellerLogin from '../pages/auth/SellerLogin';
import SellerRegister from '../pages/auth/SellerRegister';
import DeliveryLogin from '../pages/auth/DeliveryLogin';
import DeliveryRegister from '../pages/auth/DeliveryRegister';
import AdminLogin from '../pages/auth/AdminLogin';

const authRoutes = (
  <>
    <Route path="/login" element={<CustomerLogin />} />
    <Route path="/register" element={<CustomerRegister />} />
    <Route path="/seller/login" element={<SellerLogin />} />
    <Route path="/seller/register" element={<SellerRegister />} />
    <Route path="/delivery/login" element={<DeliveryLogin />} />
    <Route path="/delivery/register" element={<DeliveryRegister />} />
    <Route path="/admin/login" element={<AdminLogin />} />
  </>
);

export default authRoutes;
