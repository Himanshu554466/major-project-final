import { Navigate, Route, Routes } from 'react-router-dom';

import AdminRoutes from './AdminRoutes';
import AuthRoutes from './AuthRoutes';
import CustomerRoutes from './CustomerRoutes';
import DeliveryRoutes from './DeliveryRoutes';
import SellerRoutes from './SellerRoutes';

export default function AppRoutes() {
  return (
    <Routes>
      {AuthRoutes}
      {CustomerRoutes}
      {SellerRoutes}
      {DeliveryRoutes}
      {AdminRoutes}

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
