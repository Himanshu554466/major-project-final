import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import api from '../../services/api';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';

interface Variant { id: string; price: number; color?: string; size?: string; stock: number; }
interface ProductImage { id: string; url: string; }
interface Product {
  id: string; title: string; description: string; category: string; brand: string;
  stock: number; deliveryCharge: number; freeDeliveryAbove: number;
  variants: Variant[]; images: ProductImage[];
  tags: { id: string; name: string }[];
  seller: { id: string; shopName: string; city: string; sellerAddress?: string };
}

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(s => (
        <svg key={s} className={`w-4 h-4 ${s <= Math.round(rating) ? 'text-[#6d28d9]' : 'text-[#ddd]'}`} fill="currentColor" viewBox="0 0 20 20">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
    </div>
  );
}

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { isAuthenticated } = useAuth();

  const [product, setProduct] = useState<Product | null>(null);
  const [related, setRelated] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedVariant, setSelectedVariant] = useState<Variant | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const [addingCart, setAddingCart] = useState(false);
  const [addingWishlist, setAddingWishlist] = useState(false);
  const [toast, setToast] = useState<{ msg: string; ok: boolean } | null>(null);
  const [relatedAddingId, setRelatedAddingId] = useState<string | null>(null);

  const showToast = (msg: string, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 2800);
  };

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    setActiveImage(0);
    setQuantity(1);
    api.get(`/customer/products/${id}`)
      .then(res => {
        const p: Product = res.data.product || res.data;
        setProduct(p);
        if (p.variants?.length) setSelectedVariant(p.variants[0]);
        // Fetch related products
        api.get(`/customer/products/${id}/related`)
          .then(r => setRelated(r.data.products || []))
          .catch(() => setRelated([]));
      })
      .catch(() => setError('Product not found.'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleAddToCart = async () => {
    if (!isAuthenticated) { navigate('/login'); return; }
    if (!product) return;
    setAddingCart(true);
    try {
      await addToCart(product.id, selectedVariant?.id, quantity);
      showToast('Added to cart!');
    } catch {
      showToast('Failed to add to cart.', false);
    } finally {
      setAddingCart(false);
    }
  };

  const handleBuyNow = async () => {
    if (!isAuthenticated) { navigate('/login'); return; }
    if (!product) return;
    setAddingCart(true);
    try {
      await addToCart(product.id, selectedVariant?.id, quantity);
      navigate('/checkout');
    } catch {
      showToast('Failed. Please try again.', false);
    } finally {
      setAddingCart(false);
    }
  };

  const handleAddToWishlist = async () => {
    if (!isAuthenticated) { navigate('/login'); return; }
    if (!product) return;
    setAddingWishlist(true);
    try {
      await api.post('/customer/wishlist', { productId: product.id });
      showToast('Added to wishlist!');
    } catch {
      showToast('Already in wishlist.', false);
    } finally {
      setAddingWishlist(false);
    }
  };

  const handleRelatedAddToCart = async (p: Product) => {
    if (!isAuthenticated) { navigate('/login'); return; }
    setRelatedAddingId(p.id);
    try {
      const variantId = p.variants?.[0]?.id;
      await addToCart(p.id, variantId, 1);
      showToast('Added to cart!');
    } catch { /* ignore */ }
    finally { setRelatedAddingId(null); }
  };

  const maxQty = selectedVariant?.stock ?? product?.stock ?? 1;
  const uniqueColors = product?.variants ? [...new Set(product.variants.map(v => v.color).filter(Boolean))] : [];
  const uniqueSizes = product?.variants ? [...new Set(product.variants.map(v => v.size).filter(Boolean))] : [];

  const selectVariant = (color?: string, size?: string) => {
    if (!product) return;
    const match = product.variants.find(v =>
      (color ? v.color === color : v.color === selectedVariant?.color) &&
      (size ? v.size === size : v.size === selectedVariant?.size)
    ) || product.variants.find(v => color ? v.color === color : size ? v.size === size : false);
    if (match) { setSelectedVariant(match); setQuantity(1); }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#EAEDED]">
        <div className="max-w-[1500px] mx-auto px-4 py-6">
          <div className="bg-white border border-[#ddd] rounded-lg p-6 animate-pulse">
            <div className="flex gap-8">
              <div className="w-80 h-80 bg-[#f3f3f3] rounded" />
              <div className="flex-1 space-y-4">
                <div className="h-6 bg-[#f3f3f3] rounded w-3/4" />
                <div className="h-4 bg-[#f3f3f3] rounded w-1/2" />
                <div className="h-10 bg-[#f3f3f3] rounded w-1/3" />
                <div className="h-24 bg-[#f3f3f3] rounded" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-[#EAEDED] flex items-center justify-center">
        <div className="text-center">
          <p className="text-5xl mb-4">😕</p>
          <p className="text-xl font-medium text-[#0f1111] mb-2">{error || 'Product not found'}</p>
          <Link to="/products" className="text-[#0066c0] hover:text-[#5b21b6] hover:underline">← Back to Products</Link>
        </div>
      </div>
    );
  }

  const price = selectedVariant?.price ?? 0;
  const mrp = price ? Math.round(price * 1.3) : 0;
  const discountPct = mrp ? Math.round(((mrp - price) / mrp) * 100) : 0;
  const inStock = (selectedVariant?.stock ?? product.stock) > 0;
  const rating = 4.1 + ((parseInt(product.id) * 7) % 10) / 10 * 0.8;
  const reviewCount = 1200 + (parseInt(product.id) * 37) % 4800;

  return (
    <div className="min-h-screen bg-[#EAEDED]">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-20 right-4 z-50 px-4 py-3 rounded-lg shadow-lg text-sm font-medium transition-all ${
          toast.ok ? 'bg-[#067D62] text-white' : 'bg-[#CC0C39] text-white'
        }`}>
          {toast.msg}
        </div>
      )}

      <div className="max-w-[1500px] mx-auto px-4 py-4">
        {/* Breadcrumb */}
        <nav className="text-xs text-[#0066c0] mb-3 flex items-center gap-1 flex-wrap">
          <Link to="/" className="hover:text-[#5b21b6] hover:underline">Home</Link>
          <span className="text-[#555]">›</span>
          <Link to="/products" className="hover:text-[#5b21b6] hover:underline">Products</Link>
          <span className="text-[#555]">›</span>
          <Link to={`/products?category=${product.category}`} className="hover:text-[#5b21b6] hover:underline">{product.category}</Link>
          <span className="text-[#555]">›</span>
          <span className="text-[#555] line-clamp-1">{product.title}</span>
        </nav>

        {/* Main Product Card */}
        <div className="bg-white border border-[#ddd] rounded-lg p-6 mb-4">
          <div className="flex flex-col md:flex-row gap-8">

            {/* ── Image Gallery ── */}
            <div className="md:w-[380px] flex-shrink-0">
              {/* Thumbnails + Main */}
              <div className="flex gap-3">
                {/* Thumbnails column */}
                {product.images?.length > 1 && (
                  <div className="flex flex-col gap-2 w-14">
                    {product.images.map((img, idx) => (
                      <button key={img.id} onClick={() => setActiveImage(idx)}
                        className={`w-14 h-14 border-2 rounded flex items-center justify-center p-1 transition-colors ${
                          activeImage === idx ? 'border-[#6d28d9]' : 'border-[#ddd] hover:border-[#6d28d9]'
                        }`}>
                        <img src={img.url} alt="" className="max-h-full max-w-full object-contain" />
                      </button>
                    ))}
                  </div>
                )}
                {/* Main image */}
                <div className="flex-1 border border-[#ddd] rounded flex items-center justify-center p-6 min-h-[320px] relative">
                  {product.images?.length > 0 ? (
                    <img src={product.images[activeImage]?.url} alt={product.title}
                      className="max-h-[300px] max-w-full object-contain" />
                  ) : (
                    <span className="text-8xl text-[#ddd]">📦</span>
                  )}
                  {/* Prev/Next arrows */}
                  {product.images?.length > 1 && (
                    <>
                      <button onClick={() => setActiveImage(i => Math.max(0, i - 1))}
                        className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white border border-[#ddd] rounded-full flex items-center justify-center shadow hover:bg-[#f0f0f0] disabled:opacity-30"
                        disabled={activeImage === 0}>
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                        </svg>
                      </button>
                      <button onClick={() => setActiveImage(i => Math.min(product.images.length - 1, i + 1))}
                        className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white border border-[#ddd] rounded-full flex items-center justify-center shadow hover:bg-[#f0f0f0] disabled:opacity-30"
                        disabled={activeImage === product.images.length - 1}>
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                        </svg>
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Wishlist button */}
              <button onClick={handleAddToWishlist} disabled={addingWishlist}
                className="mt-3 w-full py-2 border border-[#888c8c] rounded text-sm bg-white hover:bg-[#f0f0f0] text-[#111] flex items-center justify-center gap-2 transition-colors">
                <svg className="w-4 h-4 text-[#5b21b6]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
                Add to Wish List
              </button>
            </div>

            {/* ── Product Info ── */}
            <div className="flex-1 min-w-0">
              {/* Brand */}
              {product.brand && (
                <Link to={`/products?brand=${encodeURIComponent(product.brand)}`}
                  className="text-sm text-[#0066c0] hover:text-[#5b21b6] hover:underline font-medium">
                  {product.brand}
                </Link>
              )}

              {/* Title */}
              <h1 className="text-xl font-medium text-[#0f1111] mt-1 mb-2 leading-snug">{product.title}</h1>

              {/* Rating */}
              <div className="flex items-center gap-2 mb-3 pb-3 border-b border-[#eee]">
                <Stars rating={rating} />
                <span className="text-sm text-[#0066c0] hover:text-[#5b21b6] cursor-pointer hover:underline">
                  {reviewCount.toLocaleString('en-IN')} ratings
                </span>
              </div>

              {/* Price */}
              <div className="mb-4">
                <div className="flex items-baseline gap-2 flex-wrap">
                  {discountPct > 0 && (
                    <span className="text-[#CC0C39] text-sm font-medium">-{discountPct}%</span>
                  )}
                  <span className="text-3xl font-medium text-[#B12704]">₹{price.toLocaleString('en-IN')}</span>
                </div>
                {mrp > 0 && (
                  <p className="text-sm text-[#565959] mt-0.5">
                    M.R.P.: <span className="line-through">₹{mrp.toLocaleString('en-IN')}</span>
                    {discountPct > 0 && <span className="text-[#CC0C39] ml-1">Save ₹{(mrp - price).toLocaleString('en-IN')}</span>}
                  </p>
                )}
                <p className="text-xs text-[#555] mt-1">Inclusive of all taxes</p>
              </div>

              {/* Delivery */}
              <div className="mb-4 text-sm">
                {product.deliveryCharge === 0 ? (
                  <p className="text-[#007600] font-medium">FREE Delivery</p>
                ) : (
                  <p className="text-[#555]">
                    ₹{product.deliveryCharge} delivery
                    {product.freeDeliveryAbove > 0 && (
                      <span className="text-[#007600]"> · FREE above ₹{product.freeDeliveryAbove}</span>
                    )}
                  </p>
                )}
              </div>

              {/* Color Selector */}
              {uniqueColors.length > 0 && (
                <div className="mb-4">
                  <p className="text-sm font-medium text-[#0f1111] mb-2">
                    Colour: <span className="font-normal">{selectedVariant?.color}</span>
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {uniqueColors.map(color => (
                      <button key={color} onClick={() => selectVariant(color as string, undefined)}
                        className={`px-3 py-1.5 border rounded text-sm transition-colors ${
                          selectedVariant?.color === color
                            ? 'border-[#6d28d9] bg-[#ede9fe] text-[#5b21b6] font-medium'
                            : 'border-[#888c8c] hover:border-[#6d28d9] text-[#0f1111]'
                        }`}>
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Size Selector */}
              {uniqueSizes.length > 0 && (
                <div className="mb-4">
                  <p className="text-sm font-medium text-[#0f1111] mb-2">
                    Size: <span className="font-normal">{selectedVariant?.size}</span>
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {uniqueSizes.map(size => (
                      <button key={size} onClick={() => selectVariant(undefined, size as string)}
                        className={`px-3 py-1.5 border rounded text-sm transition-colors ${
                          selectedVariant?.size === size
                            ? 'border-[#6d28d9] bg-[#ede9fe] text-[#5b21b6] font-medium'
                            : 'border-[#888c8c] hover:border-[#6d28d9] text-[#0f1111]'
                        }`}>
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Stock */}
              <p className={`text-lg font-medium mb-4 ${inStock ? 'text-[#007600]' : 'text-[#CC0C39]'}`}>
                {inStock ? `In stock (${selectedVariant?.stock ?? product.stock} available)` : 'Currently unavailable'}
              </p>

              {/* Quantity */}
              {inStock && (
                <div className="flex items-center gap-3 mb-5">
                  <span className="text-sm font-medium text-[#0f1111]">Qty:</span>
                  <div className="flex items-center border border-[#888c8c] rounded overflow-hidden">
                    <button onClick={() => setQuantity(q => Math.max(1, q - 1))}
                      className="px-3 py-1.5 bg-[#f0f0f0] hover:bg-[#e0e0e0] text-[#111] font-bold border-r border-[#888c8c]">−</button>
                    <span className="px-4 py-1.5 text-sm font-semibold text-[#111] bg-white min-w-[3rem] text-center">{quantity}</span>
                    <button onClick={() => setQuantity(q => Math.min(maxQty, q + 1))} disabled={quantity >= maxQty}
                      className="px-3 py-1.5 bg-[#f0f0f0] hover:bg-[#e0e0e0] text-[#111] font-bold border-l border-[#888c8c] disabled:opacity-40">+</button>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 max-w-sm">
                <button onClick={handleAddToCart} disabled={addingCart || !inStock}
                  className="flex-1 py-2.5 bg-[#FFD814] hover:bg-[#7c3aed] border border-[#FCD200] rounded-full text-sm font-semibold text-[#111] transition-colors disabled:opacity-50">
                  {addingCart ? 'Adding...' : 'Add to Cart'}
                </button>
                <button onClick={handleBuyNow} disabled={addingCart || !inStock}
                  className="flex-1 py-2.5 bg-[#6d28d9] hover:bg-[#5b21b6] border border-[#5b21b6] rounded-full text-sm font-semibold text-[#111] transition-colors disabled:opacity-50">
                  Buy Now
                </button>
              </div>

              {/* Seller */}
              {product.seller?.shopName && (
                <div className="mt-5 pt-4 border-t border-[#eee] text-sm text-[#555]">
                  <p>Sold by: <span className="text-[#0066c0] font-medium">{product.seller.shopName}</span>
                    {product.seller.city && <span> · {product.seller.city}</span>}
                  </p>
                </div>
              )}

              {/* Tags */}
              {product.tags?.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {product.tags.map(tag => (
                    <Link key={tag.id} to={`/products?search=${encodeURIComponent(tag.name)}`}
                      className="text-xs bg-[#f0f0f0] hover:bg-[#e0e0e0] text-[#555] px-2.5 py-1 rounded-full transition-colors">
                      {tag.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Product Description */}
        <div className="bg-white border border-[#ddd] rounded-lg p-6 mb-4">
          <h2 className="text-lg font-bold text-[#0f1111] mb-3">About this item</h2>
          <p className="text-sm text-[#0f1111] leading-relaxed whitespace-pre-line">{product.description || 'No description available.'}</p>
        </div>

        {/* ── Customers Also Viewed ── */}
        {related.length > 0 && (
          <div className="bg-white border border-[#ddd] rounded-lg p-6">
            <h2 className="text-lg font-bold text-[#0f1111] mb-4">Customers who viewed this also viewed</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {related.slice(0, 6).map(p => {
                const minPrice = p.variants?.length ? Math.min(...p.variants.map(v => v.price)) : 0;
                const mrp2 = minPrice ? Math.round(minPrice * 1.3) : 0;
                const disc = mrp2 ? Math.round(((mrp2 - minPrice) / mrp2) * 100) : 0;
                const img = p.images?.[0]?.url;
                const inStk = p.variants?.some(v => v.stock > 0) ?? false;
                const rat = 4.1 + ((parseInt(p.id) * 7) % 10) / 10 * 0.8;

                return (
                  <div key={p.id} className="group border border-[#ddd] rounded-lg overflow-hidden hover:shadow-md transition-shadow flex flex-col">
                    {disc > 0 && (
                      <div className="absolute top-2 left-2 z-10 bg-[#CC0C39] text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                        -{disc}%
                      </div>
                    )}
                    <Link to={`/products/${p.id}`} className="block relative">
                      <div className="aspect-square bg-white flex items-center justify-center p-3 border-b border-[#f0f0f0]">
                        {img ? (
                          <img src={img} alt={p.title}
                            className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-300" />
                        ) : (
                          <span className="text-4xl text-[#ddd]">📦</span>
                        )}
                      </div>
                    </Link>
                    <div className="p-2.5 flex flex-col flex-1">
                      {p.brand && <p className="text-[#0066c0] text-xs truncate font-medium mb-0.5">{p.brand}</p>}
                      <Link to={`/products/${p.id}`}>
                        <p className="text-[#0f1111] text-xs leading-snug line-clamp-2 hover:text-[#5b21b6] mb-1">{p.title}</p>
                      </Link>
                      <div className="flex items-center gap-1 mb-1">
                        <Stars rating={rat} />
                      </div>
                      {minPrice > 0 && (
                        <p className="text-sm font-bold text-[#B12704] mb-2">₹{minPrice.toLocaleString('en-IN')}</p>
                      )}
                      <div className="mt-auto">
                        {inStk ? (
                          <button onClick={() => handleRelatedAddToCart(p)} disabled={relatedAddingId === p.id}
                            className="w-full py-1.5 text-xs font-semibold rounded border bg-[#FFD814] hover:bg-[#7c3aed] border-[#FCD200] text-[#111] transition-colors disabled:opacity-60">
                            {relatedAddingId === p.id ? '✓' : 'Add to Cart'}
                          </button>
                        ) : (
                          <p className="text-xs text-[#CC0C39] font-medium text-center">Out of stock</p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
