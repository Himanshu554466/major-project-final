import { useEffect, useState, useCallback } from "react";
import {
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  Loader2,
  AlertCircle,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import API from "../../services/api";

interface Complaint {
  id: number;
  message: string;
  status: string;
  priority: string;
  createdAt: string;
  customer?: { email: string };
  Order?: { id: number };
}

interface ComplaintsResponse {
  complaints: Complaint[];
  total: number;
}

const STATUS_OPTIONS = ["open", "in_progress", "resolved"];
const PRIORITY_OPTIONS = ["low", "medium", "high", "urgent"];

const STATUS_COLORS: Record<string, string> = {
  open: "bg-red-100 text-red-700",
  in_progress: "bg-yellow-100 text-yellow-700",
  resolved: "bg-green-100 text-green-700",
};

const PRIORITY_COLORS: Record<string, string> = {
  low: "bg-gray-100 text-gray-600",
  medium: "bg-blue-100 text-blue-700",
  high: "bg-orange-100 text-orange-700",
  urgent: "bg-red-100 text-red-700",
};

const STATUS_FILTERS = [
  { value: "", label: "All" },
  { value: "open", label: "Open" },
  { value: "in_progress", label: "In Progress" },
  { value: "resolved", label: "Resolved" },
];

const PRIORITY_FILTERS = [
  { value: "", label: "All Priorities" },
  { value: "low", label: "Low" },
  { value: "medium", label: "Medium" },
  { value: "high", label: "High" },
  { value: "urgent", label: "Urgent" },
];

export default function AdminComplaints() {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState("");
  const [priorityFilter, setPriorityFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [updateLoading, setUpdateLoading] = useState<number | null>(null);
  const limit = 15;

  const fetchComplaints = useCallback(() => {
    setLoading(true);
    setError("");
    const params = new URLSearchParams({
      page: String(page),
      limit: String(limit),
      ...(statusFilter ? { status: statusFilter } : {}),
      ...(priorityFilter ? { priority: priorityFilter } : {}),
    });
    API.get<ComplaintsResponse>(`/admin/complaints?${params}`)
      .then((res) => {
        setComplaints(res.data.complaints ?? []);
        setTotal(res.data.total ?? 0);
      })
      .catch(() => setError("Failed to load complaints."))
      .finally(() => setLoading(false));
  }, [page, statusFilter, priorityFilter]);

  useEffect(() => {
    fetchComplaints();
  }, [fetchComplaints]);

  const handleUpdate = async (
    complaintId: number,
    field: "status" | "priority",
    value: string
  ) => {
    setUpdateLoading(complaintId);
    try {
      await API.put(`/admin/complaints/${complaintId}`, { [field]: value });
      setComplaints((prev) =>
        prev.map((c) => (c.id === complaintId ? { ...c, [field]: value } : c))
      );
    } catch {
      // silently fail
    } finally {
      setUpdateLoading(null);
    }
  };

  const totalPages = Math.ceil(total / limit);

  return (
    <div className="max-w-6xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-gray-700" />
          Complaints
        </h1>
        <p className="text-sm text-gray-400 mt-0.5">Manage customer complaints</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-5">
        <div className="flex gap-1 bg-gray-100 rounded-xl p-1">
          {STATUS_FILTERS.map((f) => (
            <button
              key={f.value}
              onClick={() => {
                setStatusFilter(f.value);
                setPage(1);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                statusFilter === f.value
                  ? "bg-white text-gray-800 shadow-sm"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <select
          value={priorityFilter}
          onChange={(e) => {
            setPriorityFilter(e.target.value);
            setPage(1);
          }}
          className="text-sm border border-gray-200 rounded-lg px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-400"
        >
          {PRIORITY_FILTERS.map((f) => (
            <option key={f.value} value={f.value}>
              {f.label}
            </option>
          ))}
        </select>
      </div>

      {/* Content */}
      {loading ? (
        <div className="flex items-center justify-center h-48">
          <Loader2 className="w-8 h-8 animate-spin text-gray-500" />
        </div>
      ) : error ? (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-2 text-red-700 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {error}
        </div>
      ) : complaints.length === 0 ? (
        <div className="text-center py-16 bg-white border border-gray-200 rounded-xl">
          <MessageSquare className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="text-sm text-gray-400">No complaints found</p>
        </div>
      ) : (
        <div className="space-y-2">
          {complaints.map((complaint) => {
            const isExpanded = expandedId === complaint.id;
            return (
              <div
                key={complaint.id}
                className="bg-white border border-gray-200 rounded-xl overflow-hidden"
              >
                {/* Row */}
                <div
                  className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => setExpandedId(isExpanded ? null : complaint.id)}
                >
                  <div className="flex-1 grid grid-cols-2 md:grid-cols-5 gap-3 items-center text-sm min-w-0">
                    <span className="font-medium text-gray-800">#{complaint.id}</span>
                    <span className="text-gray-600 truncate">
                      {complaint.customer?.email || "—"}
                    </span>
                    <span className="text-gray-500 hidden md:block">
                      {complaint.Order ? `Order #${complaint.Order.id}` : "—"}
                    </span>
                    <div className="hidden md:flex flex-wrap gap-1">
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                          PRIORITY_COLORS[complaint.priority] ||
                          "bg-gray-100 text-gray-600"
                        }`}
                      >
                        {complaint.priority}
                      </span>
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                          STATUS_COLORS[complaint.status] ||
                          "bg-gray-100 text-gray-600"
                        }`}
                      >
                        {complaint.status.replace("_", " ")}
                      </span>
                    </div>
                    <span className="text-gray-400 text-xs hidden md:block">
                      {new Date(complaint.createdAt).toLocaleDateString("en-IN", {
                        day: "numeric",
                        month: "short",
                        year: "numeric",
                      })}
                    </span>
                  </div>

                  {/* Message preview */}
                  <p className="text-xs text-gray-400 truncate max-w-[200px] hidden lg:block">
                    {complaint.message}
                  </p>

                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-gray-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-gray-400 shrink-0" />
                  )}
                </div>

                {/* Expanded */}
                {isExpanded && (
                  <div className="border-t border-gray-100 px-4 py-4 bg-gray-50 space-y-4">
                    {/* Full message */}
                    <div>
                      <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                        Full Message
                      </p>
                      <p className="text-sm text-gray-700 bg-white border border-gray-100 rounded-lg p-3 leading-relaxed">
                        {complaint.message}
                      </p>
                    </div>

                    {/* Inline update controls */}
                    <div className="flex flex-wrap gap-4 items-end">
                      <div>
                        <label className="block text-xs font-medium text-gray-500 mb-1">
                          Status
                        </label>
                        <div className="flex items-center gap-2">
                          <select
                            value={complaint.status}
                            onChange={(e) =>
                              handleUpdate(complaint.id, "status", e.target.value)
                            }
                            disabled={updateLoading === complaint.id}
                            className="text-sm border border-gray-200 rounded-lg px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-gray-400"
                          >
                            {STATUS_OPTIONS.map((s) => (
                              <option key={s} value={s}>
                                {s.replace("_", " ")}
                              </option>
                            ))}
                          </select>
                          {updateLoading === complaint.id && (
                            <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
                          )}
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-gray-500 mb-1">
                          Priority
                        </label>
                        <select
                          value={complaint.priority}
                          onChange={(e) =>
                            handleUpdate(complaint.id, "priority", e.target.value)
                          }
                          disabled={updateLoading === complaint.id}
                          className="text-sm border border-gray-200 rounded-lg px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-gray-400"
                        >
                          {PRIORITY_OPTIONS.map((p) => (
                            <option key={p} value={p}>
                              {p}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="text-xs text-gray-400">
                        Submitted:{" "}
                        {new Date(complaint.createdAt).toLocaleString("en-IN")}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-5">
          <p className="text-sm text-gray-500">
            Page {page} of {totalPages} ({total} total)
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
