/**
 * Axios instance for all Ecommerce API calls.
 * Attaches auth token, handles 401 redirects, and reports errors to Rollbar.
 */
import axios, { AxiosError } from 'axios';
import rollbar from './rollbar';
import { API_BASE_URL } from '../config';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'ngrok-skip-browser-warning': 'true',
  },
});

// Attach JWT token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Human-readable messages for common HTTP status codes
const HTTP_ERROR_MESSAGES: Record<number, string> = {
  400: 'The request contained invalid data. Please check your input and try again.',
  401: 'Your session has expired. Please sign in again.',
  403: 'You do not have permission to perform this action.',
  404: 'The requested resource could not be found.',
  409: 'This action conflicts with existing data. Please refresh and try again.',
  422: 'The submitted data could not be processed. Please review and correct any errors.',
  429: 'Too many requests. Please wait a moment before trying again.',
  500: 'An internal server error occurred. Our team has been notified.',
  502: 'The server is temporarily unavailable. Please try again shortly.',
  503: 'The service is currently under maintenance. Please check back soon.',
};

api.interceptors.response.use(
  (res) => res,
  (err: AxiosError) => {
    const status = err.response?.status;

    // Session expired — clear storage and redirect to login
    if (status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
      return Promise.reject(err);
    }

    // Attach a clean, human-readable message to the error
    const serverMessage =
      (err.response?.data as { message?: string })?.message ?? '';
    const friendlyMessage =
      serverMessage || (status ? HTTP_ERROR_MESSAGES[status] : null) ||
      'An unexpected error occurred. Please try again.';

    // Enrich the error object so callers can display it directly
    (err as AxiosError & { friendlyMessage: string }).friendlyMessage =
      friendlyMessage;

    // Report 5xx errors to Rollbar (client errors are expected, not bugs)
    if (status && status >= 500) {
      rollbar.error('API server error', {
        url: err.config?.url,
        method: err.config?.method,
        status,
        message: serverMessage,
      });
    }

    return Promise.reject(err);
  },
);

export default api;
