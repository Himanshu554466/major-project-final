import { useEffect, useState, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import {
  LayoutDashboard,
  Package,
  CheckCircle2,
  XCircle,
  IndianRupee,
  ToggleLeft,
  ToggleRight,
  ChevronRight,
  MapPin,
  User,
  Loader2,
} from "lucide-react";
import { io, Socket } from "socket.io-client";
import API from "../../services/api";
import { useAuth } from "../../context/AuthContext";
import { SOCKET_URL } from "../../config";

interface DashboardStats {
  totalAssigned: number;
  totalDelivered: number;
  totalFailed: number;
  totalEarnings: number;
}

interface PendingShipment {
  id: number;
  status: string;
  dropAddress: string;
  dropCity: string;
  customerName: string;
  earnings: number;
}

interface DashboardData {
  stats: DashboardStats;
  pendingShipments: PendingShipment[];
}

const STATUS_LABELS: Record<string, string> = {
  ASSIGNED: "Assigned",
  ACCEPTED: "Accepted",
  PICKED_UP: "Picked Up",
  IN_TRANSIT: "In Transit",
  OUT_FOR_DELIVERY: "Out for Delivery",
  DELIVERED: "Delivered",
  FAILED: "Failed",
};

const STATUS_COLORS: Record<string, string> = {
  ASSIGNED: "bg-yellow-100 text-yellow-700",
  ACCEPTED: "bg-blue-100 text-blue-700",
  PICKED_UP: "bg-indigo-100 text-indigo-700",
  IN_TRANSIT: "bg-purple-100 text-purple-700",
  OUT_FOR_DELIVERY: "bg-orange-100 text-orange-700",
  DELIVERED: "bg-green-100 text-green-700",
  FAILED: "bg-red-100 text-red-700",
};

const NEXT_ACTION: Record<string, { label: string; status: string }> = {
  ASSIGNED: { label: "Accept Shipment", status: "ACCEPTED" },
  ACCEPTED: { label: "Mark Picked Up", status: "PICKED_UP" },
  PICKED_UP: { label: "In Transit", status: "IN_TRANSIT" },
  IN_TRANSIT: { label: "Out for Delivery", status: "OUT_FOR_DELIVERY" },
};

export default function DeliveryDashboard() {
  const { user } = useAuth();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [isActive, setIsActive] = useState(false);
  const [togglingAvailability, setTogglingAvailability] = useState(false);
  const [actionLoading, setActionLoading] = useState<number | null>(null);
  const socketRef = useRef<Socket | null>(null);
  const navigate = useNavigate();

  const fetchDashboard = () => {
    setLoading(true);
    Promise.all([
      API.get<DashboardData>("/delivery/dashboard"),
      API.get<{ partner: { isActive: boolean } }>("/delivery/profile"),
    ])
      .then(([dashRes, profileRes]) => {
        setData(dashRes.data);
        setIsActive(profileRes.data.partner?.isActive ?? false);
      })
      .catch(() => setError("Failed to load dashboard data."))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  // Socket — auto-refresh dashboard when order status changes
  useEffect(() => {
    if (!user?.id) return;
    const socket = io(SOCKET_URL, {
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
    });
    socketRef.current = socket;
    socket.on("connect", () => socket.emit("partner:join", user.id));
    socket.on("order:status:changed", () => fetchDashboard());
    socket.on("delivery:assignment_taken", () => fetchDashboard());
    return () => { socket.disconnect(); };
  }, [user?.id]);

  const toggleAvailability = async () => {
    setTogglingAvailability(true);
    try {
      await API.put("/delivery/availability", { isActive: !isActive });
      setIsActive((prev) => !prev);
    } catch {
      // silently fail
    } finally {
      setTogglingAvailability(false);
    }
  };

  const handleStatusAction = async (shipmentId: number, status: string) => {
    setActionLoading(shipmentId);
    try {
      await API.put(`/delivery/shipments/${shipmentId}/status`, { status });
      fetchDashboard();
    } catch {
      // silently fail
    } finally {
      setActionLoading(null);
    }
  };

  const statCards = data
    ? [
        {
          label: "Total Assigned",
          value: data.stats.totalAssigned,
          icon: <Package className="w-5 h-5" />,
          color: "bg-yellow-50 text-yellow-700",
        },
        {
          label: "Delivered",
          value: data.stats.totalDelivered,
          icon: <CheckCircle2 className="w-5 h-5" />,
          color: "bg-green-50 text-green-700",
        },
        {
          label: "Failed",
          value: data.stats.totalFailed,
          icon: <XCircle className="w-5 h-5" />,
          color: "bg-red-50 text-red-700",
        },
        {
          label: "Total Earnings",
          value: `₹${(data.stats.totalEarnings || 0).toLocaleString("en-IN")}`,
          icon: <IndianRupee className="w-5 h-5" />,
          color: "bg-green-50 text-green-700",
        },
      ]
    : [];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-green-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto py-8 px-4">
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-red-700 text-sm">{error}</div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
            <LayoutDashboard className="w-5 h-5 text-green-700" />
            Delivery Dashboard
          </h1>
          <p className="text-sm text-gray-400 mt-0.5">Your delivery overview</p>
        </div>

        {/* Online/Offline Toggle */}
        <button
          onClick={toggleAvailability}
          disabled={togglingAvailability}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
            isActive
              ? "bg-green-100 text-green-700 hover:bg-green-200"
              : "bg-gray-100 text-gray-600 hover:bg-gray-200"
          }`}
        >
          {togglingAvailability ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : isActive ? (
            <ToggleRight className="w-5 h-5" />
          ) : (
            <ToggleLeft className="w-5 h-5" />
          )}
          {isActive ? "Online" : "Offline"}
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {statCards.map((card) => (
          <div
            key={card.label}
            className="bg-white border border-gray-200 rounded-xl px-4 py-5"
          >
            <div className={`w-9 h-9 rounded-lg ${card.color} flex items-center justify-center mb-3`}>
              {card.icon}
            </div>
            <p className="text-2xl font-bold text-gray-900">{card.value}</p>
            <p className="text-xs text-gray-500 mt-0.5">{card.label}</p>
          </div>
        ))}
      </div>

      {/* Active Shipments */}
      <div className="bg-white border border-gray-200 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-semibold text-gray-700">
            Active Shipments
            {data?.pendingShipments?.length ? (
              <span className="ml-2 bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full font-medium">
                {data.pendingShipments.length}
              </span>
            ) : null}
          </h2>
          <Link
            to="/delivery/shipments"
            className="text-xs text-green-700 hover:underline flex items-center gap-1"
          >
            View all <ChevronRight className="w-3 h-3" />
          </Link>
        </div>

        {!data?.pendingShipments?.length ? (
          <div className="text-center py-10">
            <CheckCircle2 className="w-10 h-10 text-green-300 mx-auto mb-2" />
            <p className="text-sm text-gray-400">No active shipments</p>
          </div>
        ) : (
          <div className="space-y-3">
            {data.pendingShipments.map((shipment) => {
              const nextAction = NEXT_ACTION[shipment.status];
              return (
                <div
                  key={shipment.id}
                  className="border border-gray-100 rounded-xl p-4 hover:border-green-200 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <User className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                        <span className="text-sm font-medium text-gray-900 truncate">
                          {shipment.customerName}
                        </span>
                        <span
                          className={`text-xs px-2 py-0.5 rounded-full font-medium shrink-0 ${
                            STATUS_COLORS[shipment.status] || "bg-gray-100 text-gray-600"
                          }`}
                        >
                          {STATUS_LABELS[shipment.status] || shipment.status}
                        </span>
                      </div>
                      <div className="flex items-start gap-1.5 text-xs text-gray-500">
                        <MapPin className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                        <span className="truncate">
                          {shipment.dropAddress}, {shipment.dropCity}
                        </span>
                      </div>
                      <p className="text-xs text-green-700 font-medium mt-1">
                        ₹{(shipment.earnings || 0).toLocaleString("en-IN")}
                      </p>
                    </div>

                    <div className="flex flex-col gap-2 shrink-0">
                      {nextAction && (
                        <button
                          onClick={() => handleStatusAction(shipment.id, nextAction.status)}
                          disabled={actionLoading === shipment.id}
                          className="text-xs px-3 py-1.5 bg-green-700 text-white rounded-lg hover:bg-green-800 disabled:opacity-50 flex items-center gap-1"
                        >
                          {actionLoading === shipment.id && (
                            <Loader2 className="w-3 h-3 animate-spin" />
                          )}
                          {nextAction.label}
                        </button>
                      )}
                      {shipment.status === "OUT_FOR_DELIVERY" && (
                        <button
                          onClick={() => navigate(`/delivery/shipments/${shipment.id}`)}
                          className="text-xs px-3 py-1.5 bg-green-700 text-white rounded-lg hover:bg-green-800"
                        >
                          Update
                        </button>
                      )}
                      <button
                        onClick={() => navigate(`/delivery/shipments/${shipment.id}`)}
                        className="text-xs px-3 py-1.5 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50"
                      >
                        Details
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Quick Links */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6">
        {[
          { label: "Shipments", path: "/delivery/shipments", icon: <Package className="w-4 h-4" /> },
          { label: "History", path: "/delivery/history", icon: <CheckCircle2 className="w-4 h-4" /> },
          { label: "Earnings", path: "/delivery/earnings", icon: <IndianRupee className="w-4 h-4" /> },
          { label: "Profile", path: "/delivery/profile", icon: <User className="w-4 h-4" /> },
        ].map((link) => (
          <Link
            key={link.path}
            to={link.path}
            className="flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-4 py-3 text-sm font-medium text-gray-700 hover:border-green-300 hover:text-green-700 transition-colors"
          >
            <span className="text-green-700">{link.icon}</span>
            {link.label}
          </Link>
        ))}
      </div>
    </div>
  );
}
