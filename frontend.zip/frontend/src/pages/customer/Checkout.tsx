import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  MapPin, Package, CreditCard, CheckCircle, Plus, ChevronRight,
  Truck, Loader2, AlertCircle
} from 'lucide-react';
import api from '../../services/api';
import { useCart } from '../../context/CartContext';

interface Address {
  id: string;
  name: string;
  phone: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
  isDefault: boolean;
}

const STEPS = [
  { label: 'Address', icon: MapPin },
  { label: 'Review', icon: Package },
  { label: 'Payment', icon: CreditCard },
];

const EMPTY_ADDR: Omit<Address, 'id' | 'isDefault'> & { isDefault: boolean } = {
  name: '', phone: '', line1: '', line2: '', city: '',
  state: '', pincode: '', country: 'India', isDefault: false,
};

export default function Checkout() {
  const navigate = useNavigate();
  const { cartItems, cartTotal, clearCart } = useCart();

  const [step, setStep] = useState(0);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [selectedAddressId, setSelectedAddressId] = useState<string>('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newAddr, setNewAddr] = useState({ ...EMPTY_ADDR });
  const [savingAddr, setSavingAddr] = useState(false);
  const [addrError, setAddrError] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'razorpay'>('cod');
  const [placing, setPlacing] = useState(false);
  const [orderError, setOrderError] = useState('');
  const [loadingAddresses, setLoadingAddresses] = useState(true);

  const deliveryCharge = (() => {
    if (cartItems.length === 0) return 0;
    let charge = 0;
    for (const item of cartItems) {
      const itemCharge = (item.product as { deliveryCharge?: number }).deliveryCharge ?? 0;
      const freeAbove = (item.product as { freeDeliveryAbove?: number }).freeDeliveryAbove ?? 499;
      if (cartTotal < freeAbove && itemCharge > charge) {
        charge = itemCharge;
      }
    }
    if (charge === 0 && cartTotal < 499) {
      const hasAnyCharge = cartItems.some(i => ((i.product as { deliveryCharge?: number }).deliveryCharge ?? 0) > 0);
      if (!hasAnyCharge) charge = 49;
    }
    return charge;
  })();
  const total = cartTotal + deliveryCharge;

  useEffect(() => {
    api.get('/customer/addresses')
      .then(res => {
        const list: Address[] = res.data.addresses || res.data || [];
        setAddresses(list);
        const def = list.find(a => a.isDefault) || list[0];
        if (def) setSelectedAddressId(def.id);
      })
      .catch(() => {})
      .finally(() => setLoadingAddresses(false));
  }, []);

  useEffect(() => {
    if (cartItems.length === 0) navigate('/cart');
  }, [cartItems, navigate]);

  const handleSaveAddress = async () => {
    if (!newAddr.name || !newAddr.phone || !newAddr.line1 || !newAddr.city || !newAddr.pincode) {
      setAddrError('Please fill all required fields.');
      return;
    }
    setSavingAddr(true);
    setAddrError('');
    try {
      const res = await api.post('/customer/addresses', newAddr);
      const saved: Address = res.data.address || res.data;
      setAddresses(prev => [...prev, saved]);
      setSelectedAddressId(saved.id);
      setShowAddForm(false);
      setNewAddr({ ...EMPTY_ADDR });
    } catch {
      setAddrError('Failed to save address. Please try again.');
    } finally {
      setSavingAddr(false);
    }
  };

  const handlePlaceOrder = async () => {
    if (!selectedAddressId) { setOrderError('Please select a delivery address.'); return; }
    setPlacing(true);
    setOrderError('');
    try {
      const items = cartItems.map(item => ({
        productId: item.product.id ?? (item.product as any)._id,
        variantId: item.variant?.id ?? (item.variant as any)?._id,
        quantity: item.quantity,
      }));

      // Place the order first (always COD initially, then upgrade if Razorpay)
      const orderRes = await api.post('/customer/orders', {
        addressId: selectedAddressId,
        items,
        paymentMethod,
      });

      const createdOrders = orderRes.data.orders || [];
      const firstOrderId = createdOrders[0]?.id;

      if (paymentMethod === 'razorpay' && firstOrderId) {
        // Check if Razorpay is configured
        const keyRes = await api.get('/payment/key');
        if (!keyRes.data.configured) {
          setOrderError('Online payment is not configured yet. Please use Cash on Delivery or contact support.');
          setPlacing(false);
          return;
        }

        // Create Razorpay order
        const payRes = await api.post('/payment/create-order', {
          amount: total,
          orderId: firstOrderId,
        });

        const { razorpayOrderId, amount: rzpAmount, currency, keyId } = payRes.data;

        // Load Razorpay script if not loaded
        if (!(window as any).Razorpay) {
          await new Promise<void>((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://checkout.razorpay.com/v1/checkout.js';
            script.onload = () => resolve();
            script.onerror = () => reject(new Error('Failed to load Razorpay'));
            document.body.appendChild(script);
          });
        }

        // Open Razorpay checkout
        await new Promise<void>((resolve, reject) => {
          const rzp = new (window as any).Razorpay({
            key: keyId,
            amount: rzpAmount,
            currency,
            name: 'Ecommerce',
            description: `Order #${String(firstOrderId).padStart(6, '0')}`,
            order_id: razorpayOrderId,
            handler: async (response: { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }) => {
              try {
                await api.post('/payment/verify', {
                  razorpayOrderId: response.razorpay_order_id,
                  razorpayPaymentId: response.razorpay_payment_id,
                  razorpaySignature: response.razorpay_signature,
                  orderId: firstOrderId,
                });
                resolve();
              } catch {
                reject(new Error('Payment verification failed'));
              }
            },
            prefill: { name: '', email: '', contact: '' },
            theme: { color: '#6d28d9' },
            modal: {
              ondismiss: () => reject(new Error('Payment cancelled by user')),
            },
          });
          rzp.open();
        });
      }

      clearCart();
      navigate('/orders', { state: { success: true } });
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message
        || (err as Error)?.message
        || 'Failed to place order. Please try again.';
      setOrderError(msg);
    } finally {
      setPlacing(false);
    }
  };

  const selectedAddress = addresses.find(a => a.id === selectedAddressId);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Checkout</h1>

        {/* Step Indicator */}
        <div className="flex items-center mb-8">
          {STEPS.map((s, idx) => (
            <React.Fragment key={s.label}>
              <div className="flex items-center gap-2">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm transition-colors ${
                  idx < step ? 'bg-green-500 text-white' :
                  idx === step ? 'bg-orange-500 text-white' :
                  'bg-gray-200 text-gray-500'
                }`}>
                  {idx < step ? <CheckCircle className="w-5 h-5" /> : idx + 1}
                </div>
                <span className={`text-sm font-medium hidden sm:block ${idx === step ? 'text-orange-600' : 'text-gray-500'}`}>
                  {s.label}
                </span>
              </div>
              {idx < STEPS.length - 1 && (
                <div className={`flex-1 h-0.5 mx-3 ${idx < step ? 'bg-green-400' : 'bg-gray-200'}`} />
              )}
            </React.Fragment>
          ))}
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Main Content */}
          <div className="flex-1">
            {/* Step 0: Address */}
            {step === 0 && (
              <div className="bg-white rounded-xl shadow-sm p-5">
                <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-orange-500" /> Delivery Address
                </h2>

                {loadingAddresses ? (
                  <div className="flex items-center gap-2 text-gray-400 py-4">
                    <Loader2 className="w-5 h-5 animate-spin" /> Loading addresses...
                  </div>
                ) : (
                  <div className="space-y-3">
                    {addresses.map(addr => (
                      <label
                        key={addr.id}
                        className={`flex items-start gap-3 p-4 rounded-xl border-2 cursor-pointer transition-colors ${
                          selectedAddressId === addr.id
                            ? 'border-orange-500 bg-orange-50'
                            : 'border-gray-200 hover:border-orange-200'
                        }`}
                      >
                        <input
                          type="radio"
                          name="address"
                          value={addr.id}
                          checked={selectedAddressId === addr.id}
                          onChange={() => setSelectedAddressId(addr.id)}
                          className="mt-1 accent-orange-500"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-gray-800">{addr.name}</span>
                            {addr.isDefault && (
                              <span className="text-xs bg-orange-100 text-orange-600 px-2 py-0.5 rounded-full font-medium">Default</span>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 mt-0.5">{addr.phone}</p>
                          <p className="text-sm text-gray-600">
                            {addr.line1}{addr.line2 ? `, ${addr.line2}` : ''}, {addr.city}, {addr.state} - {addr.pincode}
                          </p>
                          <p className="text-sm text-gray-500">{addr.country}</p>
                        </div>
                      </label>
                    ))}

                    {/* Add New Address */}
                    {!showAddForm ? (
                      <button
                        onClick={() => setShowAddForm(true)}
                        className="w-full flex items-center justify-center gap-2 border-2 border-dashed border-gray-300 hover:border-orange-400 rounded-xl py-4 text-gray-500 hover:text-orange-500 transition-colors"
                      >
                        <Plus className="w-5 h-5" /> Add New Address
                      </button>
                    ) : (
                      <div className="border-2 border-orange-200 rounded-xl p-4 space-y-3">
                        <h3 className="font-semibold text-gray-800">New Address</h3>
                        {addrError && (
                          <p className="text-sm text-red-500 flex items-center gap-1">
                            <AlertCircle className="w-4 h-4" /> {addrError}
                          </p>
                        )}
                        <div className="grid grid-cols-2 gap-3">
                          {[
                            { key: 'name', label: 'Full Name *', col: 1 },
                            { key: 'phone', label: 'Phone *', col: 1 },
                            { key: 'line1', label: 'Address Line 1 *', col: 2 },
                            { key: 'line2', label: 'Address Line 2', col: 2 },
                            { key: 'city', label: 'City *', col: 1 },
                            { key: 'state', label: 'State *', col: 1 },
                            { key: 'pincode', label: 'Pincode *', col: 1 },
                            { key: 'country', label: 'Country *', col: 1 },
                          ].map(field => (
                            <input
                              key={field.key}
                              type="text"
                              placeholder={field.label}
                              value={(newAddr as Record<string, unknown>)[field.key] as string}
                              onChange={e => setNewAddr(prev => ({ ...prev, [field.key]: e.target.value }))}
                              className={`border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-orange-400 ${field.col === 2 ? 'col-span-2' : ''}`}
                            />
                          ))}
                        </div>
                        <label className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={newAddr.isDefault}
                            onChange={e => setNewAddr(prev => ({ ...prev, isDefault: e.target.checked }))}
                            className="accent-orange-500"
                          />
                          Set as default address
                        </label>
                        <div className="flex gap-2">
                          <button
                            onClick={handleSaveAddress}
                            disabled={savingAddr}
                            className="flex-1 bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300 text-white font-semibold py-2 rounded-lg text-sm transition-colors"
                          >
                            {savingAddr ? 'Saving...' : 'Save Address'}
                          </button>
                          <button
                            onClick={() => { setShowAddForm(false); setAddrError(''); }}
                            className="px-4 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <button
                  onClick={() => { if (selectedAddressId) setStep(1); }}
                  disabled={!selectedAddressId}
                  className="mt-5 w-full bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300 text-white font-semibold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
                >
                  Continue to Review <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Step 1: Review */}
            {step === 1 && (
              <div className="bg-white rounded-xl shadow-sm p-5">
                <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <Package className="w-5 h-5 text-orange-500" /> Order Review
                </h2>

                {/* Delivery Address Summary */}
                {selectedAddress && (
                  <div className="bg-orange-50 rounded-xl p-4 mb-4 flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-800">{selectedAddress.name} · {selectedAddress.phone}</p>
                      <p className="text-sm text-gray-600">
                        {selectedAddress.line1}{selectedAddress.line2 ? `, ${selectedAddress.line2}` : ''}, {selectedAddress.city}, {selectedAddress.state} - {selectedAddress.pincode}
                      </p>
                    </div>
                    <button onClick={() => setStep(0)} className="ml-auto text-xs text-orange-500 hover:text-orange-600 font-medium">Change</button>
                  </div>
                )}

                {/* Items */}
                <div className="space-y-3">
                  {cartItems.map(item => {
                    const price = item.variant?.price ?? item.product?.price ?? 0;
                    const variantLabel = [item.variant?.color, item.variant?.size].filter(Boolean).join(', ');
                    const imageUrl = item.product?.images?.[0]?.url ?? item.product?.images?.[0];
                    return (
                      <div key={item.id ?? item._id} className="flex gap-3 py-3 border-b border-gray-100 last:border-0">
                        <div className="w-14 h-14 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                          {imageUrl ? (
                            <img src={imageUrl} alt={item.product.title} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Package className="w-6 h-6 text-gray-300" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-gray-800 line-clamp-1">{item.product.title}</p>
                          {variantLabel && <p className="text-xs text-gray-500">{variantLabel}</p>}
                          <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                        </div>
                        <p className="text-sm font-bold text-gray-900">₹{(price * item.quantity).toLocaleString()}</p>
                      </div>
                    );
                  })}
                </div>

                <div className="flex gap-3 mt-5">
                  <button onClick={() => setStep(0)} className="flex-1 border border-gray-200 text-gray-600 font-semibold py-3 rounded-xl hover:bg-gray-50 transition-colors">
                    Back
                  </button>
                  <button
                    onClick={() => setStep(2)}
                    className="flex-1 bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
                  >
                    Continue to Payment <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Payment */}
            {step === 2 && (
              <div className="bg-white rounded-xl shadow-sm p-5">
                <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-orange-500" /> Payment Method
                </h2>

                <div className="space-y-3">
                  {/* Cash on Delivery */}
                  <label onClick={() => setPaymentMethod('cod')}
                    className={`flex items-center gap-4 p-4 border-2 rounded-xl cursor-pointer transition-colors ${
                      paymentMethod === 'cod' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-orange-200'
                    }`}>
                    <input type="radio" checked={paymentMethod === 'cod'} onChange={() => setPaymentMethod('cod')} className="accent-orange-500" />
                    <div>
                      <p className="font-semibold text-gray-800">Cash on Delivery</p>
                      <p className="text-sm text-gray-500">Pay when your order arrives</p>
                    </div>
                    <Truck className="w-6 h-6 text-orange-500 ml-auto" />
                  </label>

                  {/* Razorpay */}
                  <label onClick={() => setPaymentMethod('razorpay')}
                    className={`flex items-center gap-4 p-4 border-2 rounded-xl cursor-pointer transition-colors ${
                      paymentMethod === 'razorpay' ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-200'
                    }`}>
                    <input type="radio" checked={paymentMethod === 'razorpay'} onChange={() => setPaymentMethod('razorpay')} className="accent-blue-500" />
                    <div>
                      <p className="font-semibold text-gray-800">Pay Online</p>
                      <p className="text-sm text-gray-500">UPI · Cards · Net Banking · Wallets</p>
                    </div>
                    <div className="ml-auto flex items-center gap-1.5">
                      <span className="text-xs font-bold text-blue-600 bg-blue-100 px-2 py-0.5 rounded">🔒 SECURE</span>
                    </div>
                  </label>
                </div>

                {orderError && (
                  <p className="mt-3 text-sm text-red-500 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" /> {orderError}
                  </p>
                )}

                <div className="flex gap-3 mt-5">
                  <button onClick={() => setStep(1)} className="flex-1 border border-gray-200 text-gray-600 font-semibold py-3 rounded-xl hover:bg-gray-50 transition-colors">
                    Back
                  </button>
                  <button
                    onClick={handlePlaceOrder}
                    disabled={placing}
                    className="flex-1 bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300 text-white font-semibold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
                  >
                    {placing ? <><Loader2 className="w-4 h-4 animate-spin" /> {paymentMethod === 'razorpay' ? 'Opening Payment...' : 'Placing...'}</> : paymentMethod === 'razorpay' ? 'Pay Now' : 'Place Order'}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:w-72 flex-shrink-0">
            <div className="bg-white rounded-xl shadow-sm p-5 sticky top-4">
              <h2 className="text-base font-bold text-gray-800 mb-4">Price Details</h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-gray-600">
                  <span>Items ({cartItems.reduce((s, i) => s + i.quantity, 0)})</span>
                  <span>₹{cartTotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Delivery</span>
                  {deliveryCharge === 0 ? (
                    <span className="text-green-600 font-medium">FREE</span>
                  ) : (
                    <span>₹{deliveryCharge}</span>
                  )}
                </div>
                <div className="border-t border-gray-100 pt-2 flex justify-between font-bold text-gray-900">
                  <span>Total Amount</span>
                  <span>₹{total.toLocaleString()}</span>
                </div>
              </div>
              {deliveryCharge === 0 && (
                <p className="mt-3 text-xs text-green-600 bg-green-50 rounded-lg px-3 py-2">
                  🎉 You're saving on delivery!
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
