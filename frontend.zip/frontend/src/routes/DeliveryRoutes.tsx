import { Route } from 'react-router-dom';

import DeliveryLayout from '../components/layouts/DeliveryLayout';
import DeliveryDashboard from '../pages/delivery/Dashboard';
import DeliveryShipments from '../pages/delivery/Shipments';
import ShipmentDetail from '../pages/delivery/ShipmentDetail';
import DeliveryHistory from '../pages/delivery/History';
import DeliveryEarnings from '../pages/delivery/Earnings';
import DeliveryProfile from '../pages/delivery/Profile';

import ProtectedRoute from './ProtectedRoute';

const deliveryRoutes = (
  <Route
    element={(
      <ProtectedRoute allowedRoles={['delivery_partner', 'admin']} redirectTo="/delivery/login">
        <DeliveryLayout />
      </ProtectedRoute>
    )}
  >
    <Route path="/delivery/dashboard" element={<DeliveryDashboard />} />
    <Route path="/delivery/shipments" element={<DeliveryShipments />} />
    <Route path="/delivery/shipments/:id" element={<ShipmentDetail />} />
    <Route path="/delivery/history" element={<DeliveryHistory />} />
    <Route path="/delivery/earnings" element={<DeliveryEarnings />} />
    <Route path="/delivery/profile" element={<DeliveryProfile />} />
  </Route>
);

export default deliveryRoutes;
