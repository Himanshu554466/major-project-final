import { useEffect, useState, useCallback } from "react";
import { useParams, useSearchParams, useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  User,
  Phone,
  MapPin,
  Package,
  IndianRupee,
  CheckCircle2,
  Circle,
  Loader2,
  AlertCircle,
  ClipboardList,
} from "lucide-react";
import API from "../../services/api";

interface TrackingEvent {
  status: string;
  message: string;
  timestamp: string;
  location?: string;
}

interface Shipment {
  id: number;
  status: string;
  isReturn?: boolean;
  returnReason?: string;
  dropAddress: string;
  dropCity: string;
  dropPincode: string;
  customerName: string;
  customerPhone: string;
  earnings: number;
  Order: {
    id: number;
    totalAmount: number;
    customer: {
      email: string;
      username: string;
      phone: string;
    };
  };
  trackingEvents: TrackingEvent[];
}

// ── Forward delivery flow ─────────────────────────────────────────────────
const STATUS_FLOW = [
  "ASSIGNED", "ACCEPTED", "PICKED_UP", "IN_TRANSIT", "OUT_FOR_DELIVERY", "DELIVERED",
];

const STATUS_LABELS: Record<string, string> = {
  ASSIGNED: "Assigned",
  ACCEPTED: "Accepted",
  PICKED_UP: "Picked Up",
  IN_TRANSIT: "In Transit",
  OUT_FOR_DELIVERY: "Out for Delivery",
  DELIVERED: "Delivered",
  FAILED: "Failed",
};

// ── Return pickup flow ────────────────────────────────────────────────────
const RETURN_STATUS_FLOW = [
  "ASSIGNED", "ACCEPTED", "PICKED_UP", "IN_TRANSIT", "OUT_FOR_DELIVERY", "DELIVERED",
];

const RETURN_STATUS_LABELS: Record<string, string> = {
  ASSIGNED:         "Pickup Assigned",
  ACCEPTED:         "Pickup Accepted",
  PICKED_UP:        "Item Picked Up from Customer",
  IN_TRANSIT:       "In Transit to Seller",
  OUT_FOR_DELIVERY: "Arriving at Seller",
  DELIVERED:        "Delivered to Seller",
  FAILED:           "Pickup Failed",
};

const STATUS_COLORS: Record<string, string> = {
  ASSIGNED: "bg-yellow-100 text-yellow-700",
  ACCEPTED: "bg-blue-100 text-blue-700",
  PICKED_UP: "bg-indigo-100 text-indigo-700",
  IN_TRANSIT: "bg-purple-100 text-purple-700",
  OUT_FOR_DELIVERY: "bg-orange-100 text-orange-700",
  DELIVERED: "bg-green-100 text-green-700",
  FAILED: "bg-red-100 text-red-700",
};

const NEXT_ACTION: Record<string, { label: string; status: string }> = {
  ASSIGNED: { label: "Accept Shipment", status: "ACCEPTED" },
  ACCEPTED: { label: "Mark Picked Up", status: "PICKED_UP" },
  PICKED_UP: { label: "Mark In Transit", status: "IN_TRANSIT" },
  IN_TRANSIT: { label: "Out for Delivery", status: "OUT_FOR_DELIVERY" },
};

const RETURN_NEXT_ACTION: Record<string, { label: string; status: string }> = {
  ASSIGNED: { label: "Accept Pickup", status: "ACCEPTED" },
  ACCEPTED: { label: "Picked Up from Customer", status: "PICKED_UP" },
  PICKED_UP: { label: "In Transit to Seller", status: "IN_TRANSIT" },
  IN_TRANSIT: { label: "Arriving at Seller", status: "OUT_FOR_DELIVERY" },
};

const FAIL_REASONS = [
  { value: "customer_not_available", label: "Customer Not Available" },
  { value: "wrong_address", label: "Wrong Address" },
  { value: "refused_delivery", label: "Refused Delivery" },
  { value: "other", label: "Other" },
];

export default function ShipmentDetail() {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [shipment, setShipment] = useState<Shipment | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [actionLoading, setActionLoading] = useState(false);

  // Deliver form
  const [showDeliverForm, setShowDeliverForm] = useState(
    searchParams.get("action") === "deliver"
  );
  const [deliverNotes, setDeliverNotes] = useState("");
  const [deliverProof, setDeliverProof] = useState<File | null>(null);
  const [deliverSuccess, setDeliverSuccess] = useState(false);

  // Fail form
  const [showFailForm, setShowFailForm] = useState(
    searchParams.get("action") === "fail"
  );
  const [failReason, setFailReason] = useState("customer_not_available");
  const [failNotes, setFailNotes] = useState("");

  const fetchShipment = useCallback(() => {
    setLoading(true);
    API.get<{ shipment: Shipment } | Shipment>(`/delivery/shipments/${id}`)
      .then((res) => {
        const data = res.data as any;
        const s = data.shipment ?? data;
        // Sequelize may return Order as 'Order' or 'order' depending on alias
        if (s && !s.Order && s.order) s.Order = s.order;
        setShipment(s);
      })
      .catch(() => setError("Failed to load shipment details."))
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    fetchShipment();
  }, [fetchShipment]);

  const handleStatusUpdate = async (status: string) => {
    setActionLoading(true);
    try {
      await API.put(`/delivery/shipments/${id}/status`, { status });
      fetchShipment();
    } catch {
      // silently fail
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeliver = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionLoading(true);
    try {
      const formData = new FormData();
      formData.append("notes", deliverNotes);
      if (deliverProof) formData.append("proof", deliverProof);
      await API.post(`/delivery/shipments/${id}/delivered`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setDeliverSuccess(true);
      fetchShipment();
    } catch {
      // silently fail
    } finally {
      setActionLoading(false);
    }
  };

  const handleFail = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionLoading(true);
    try {
      await API.post(`/delivery/shipments/${id}/failed`, {
        reason: failReason,
        notes: failNotes,
      });
      fetchShipment();
      setShowFailForm(false);
    } catch {
      // silently fail
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-green-600" />
      </div>
    );
  }

  if (error || !shipment) {
    return (
      <div className="max-w-2xl mx-auto py-8 px-4">
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-2 text-red-700 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {error || "Shipment not found."}
        </div>
      </div>
    );
  }

  // Use return-specific labels when it's a return shipment
  const activeFlow = shipment.isReturn ? RETURN_STATUS_FLOW : STATUS_FLOW;
  const activeLabels = shipment.isReturn ? RETURN_STATUS_LABELS : STATUS_LABELS;

  const currentStatusIndex = activeFlow.indexOf(shipment.status);
  const nextAction = shipment.isReturn
    ? RETURN_NEXT_ACTION[shipment.status]
    : NEXT_ACTION[shipment.status];
  const isOutForDelivery = shipment.status === "OUT_FOR_DELIVERY";
  const isTerminal = shipment.status === "DELIVERED" || shipment.status === "FAILED";

  return (
    <div className="max-w-2xl mx-auto py-8 px-4">
      {/* Back */}
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-700 mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </button>

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
            <Package className="w-5 h-5 text-green-700" />
            Shipment #{shipment.id}
            {shipment.isReturn && (
              <span className="text-xs bg-pink-100 text-pink-700 px-2 py-0.5 rounded-full font-medium">↩ RETURN PICKUP</span>
            )}
          </h1>
          <span className={`inline-block mt-1 text-xs px-2.5 py-0.5 rounded-full font-medium ${
            STATUS_COLORS[shipment.status] || "bg-gray-100 text-gray-600"
          }`}>
            {activeLabels[shipment.status] || shipment.status}
          </span>
        </div>
        <div className="flex items-center gap-1 text-green-700">
          <IndianRupee className="w-4 h-4" />
          <span className="text-xl font-bold">{(shipment.earnings || 0).toLocaleString("en-IN")}</span>
        </div>
      </div>

      {/* Return info banner */}
      {shipment.isReturn && shipment.returnReason && (
        <div className="bg-pink-50 border border-pink-200 rounded-xl px-4 py-3 mb-4 text-sm text-pink-700">
          <span className="font-semibold">Return Pickup</span> — Reason: {shipment.returnReason}
        </div>
      )}

      {/* Customer Info */}
      <div className="bg-white border border-gray-200 rounded-xl p-5 mb-4">
        <h2 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
          <User className="w-4 h-4 text-green-700" />
          Customer Information
        </h2>
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <User className="w-3.5 h-3.5 text-gray-400" />
            <span className="text-sm text-gray-800">{shipment.customerName}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="w-3.5 h-3.5 text-gray-400" />
            <a
              href={`tel:${shipment.customerPhone}`}
              className="text-sm text-green-700 hover:underline"
            >
              {shipment.customerPhone}
            </a>
          </div>
          <div className="flex items-start gap-2">
            <MapPin className="w-3.5 h-3.5 text-gray-400 mt-0.5" />
            <span className="text-sm text-gray-600">
              {shipment.dropAddress}, {shipment.dropCity} - {shipment.dropPincode}
            </span>
          </div>
        </div>
      </div>

      {/* Order Info */}
      {shipment.Order && (
        <div className="bg-white border border-gray-200 rounded-xl p-5 mb-4">
          <h2 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
            <ClipboardList className="w-4 h-4 text-green-700" />
            Order Information
          </h2>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <p className="text-xs text-gray-400">Order ID</p>
              <p className="font-medium text-gray-800">#{shipment.Order.id}</p>
            </div>
            <div>
              <p className="text-xs text-gray-400">Order Total</p>
              <p className="font-medium text-gray-800">
                ₹{(shipment.Order.totalAmount || 0).toLocaleString("en-IN")}
              </p>
            </div>
            {shipment.Order.customer && (
              <>
                <div>
                  <p className="text-xs text-gray-400">Customer Email</p>
                  <p className="font-medium text-gray-800 truncate">
                    {shipment.Order.customer.email}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Username</p>
                  <p className="font-medium text-gray-800">
                    {shipment.Order.customer.username}
                  </p>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Tracking Timeline */}
      <div className="bg-white border border-gray-200 rounded-xl p-5 mb-4">
        <h2 className="text-sm font-semibold text-gray-700 mb-4">Tracking Timeline</h2>

        {/* Status flow stepper */}
        <div className="space-y-0 mb-4">
          {activeFlow.map((status, idx) => {
            const isPast = idx < currentStatusIndex;
            const isCurrent = idx === currentStatusIndex;
            const isFuture = idx > currentStatusIndex;
            return (
              <div key={status} className="flex items-start gap-3">
                <div className="flex flex-col items-center">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
                    isPast || isCurrent ? "bg-green-700 text-white" : "bg-gray-100 text-gray-400"
                  }`}>
                    {isPast ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : isCurrent ? (
                      <Circle className="w-4 h-4 fill-white" />
                    ) : (
                      <Circle className="w-4 h-4" />
                    )}
                  </div>
                  {idx < activeFlow.length - 1 && (
                    <div className={`w-0.5 h-6 ${isPast ? "bg-green-700" : "bg-gray-200"}`} />
                  )}
                </div>
                <div className="pb-4">
                  <p className={`text-sm font-medium ${
                    isCurrent ? "text-green-700" : isFuture ? "text-gray-400" : "text-gray-700"
                  }`}>
                    {activeLabels[status]}
                  </p>
                </div>
              </div>
            );
          })}
          {shipment.status === "FAILED" && (
            <div className="flex items-start gap-3">
              <div className="w-7 h-7 rounded-full bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                <AlertCircle className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-medium text-red-600">Failed</p>
              </div>
            </div>
          )}
        </div>

        {/* Tracking events */}
        {shipment.trackingEvents?.length > 0 && (
          <div className="border-t border-gray-100 pt-4">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
              Event Log
            </p>
            <div className="space-y-3">
              {[...shipment.trackingEvents].reverse().map((event, idx) => (
                <div key={idx} className="flex gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1.5 shrink-0" />
                  <div>
                    <p className="text-xs font-medium text-gray-700">
                      {activeLabels[event.status] || event.status}
                    </p>
                    {event.message && (
                      <p className="text-xs text-gray-500">{event.message}</p>
                    )}
                    {event.location && (
                      <p className="text-xs text-gray-400">{event.location}</p>
                    )}
                    <p className="text-xs text-gray-400 mt-0.5">
                      {new Date(event.timestamp).toLocaleString("en-IN")}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      {!isTerminal && (
        <div className="bg-white border border-gray-200 rounded-xl p-5 mb-4">
          <h2 className="text-sm font-semibold text-gray-700 mb-4">Update Status</h2>

          {nextAction && !isOutForDelivery && (
            <button
              onClick={() => handleStatusUpdate(nextAction.status)}
              disabled={actionLoading}
              className="w-full py-2.5 bg-green-700 text-white rounded-xl text-sm font-medium hover:bg-green-800 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {actionLoading && <Loader2 className="w-4 h-4 animate-spin" />}
              {nextAction.label}
            </button>
          )}

          {isOutForDelivery && (
            <div className="flex gap-3">
              <button
                onClick={() => { setShowDeliverForm(true); setShowFailForm(false); }}
                className="flex-1 py-2.5 bg-green-700 text-white rounded-xl text-sm font-medium hover:bg-green-800"
              >
                {shipment.isReturn ? 'Delivered to Seller ✓' : 'Mark Delivered'}
              </button>
              <button
                onClick={() => { setShowFailForm(true); setShowDeliverForm(false); }}
                className="flex-1 py-2.5 bg-red-600 text-white rounded-xl text-sm font-medium hover:bg-red-700"
              >
                {shipment.isReturn ? 'Pickup Failed' : 'Report Failed'}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Deliver Form */}
      {showDeliverForm && !deliverSuccess && (
        <div className="bg-white border border-green-200 rounded-xl p-5 mb-4">
          <h2 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-700" />
            {shipment.isReturn ? 'Confirm Return Delivered to Seller' : 'Confirm Delivery'}
          </h2>
          <form onSubmit={handleDeliver} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">
                Notes (optional)
              </label>
              <textarea
                value={deliverNotes}
                onChange={(e) => setDeliverNotes(e.target.value)}
                rows={3}
                placeholder="Add delivery notes..."
                className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500 resize-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">
                Proof of Delivery (optional)
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => setDeliverProof(e.target.files?.[0] ?? null)}
                className="w-full text-sm text-gray-600 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-medium file:bg-green-50 file:text-green-700 hover:file:bg-green-100"
              />
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                disabled={actionLoading}
                className="flex-1 py-2.5 bg-green-700 text-white rounded-xl text-sm font-medium hover:bg-green-800 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {actionLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                Confirm Delivered
              </button>
              <button
                type="button"
                onClick={() => setShowDeliverForm(false)}
                className="px-4 py-2.5 border border-gray-200 text-gray-600 rounded-xl text-sm hover:bg-gray-50"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {deliverSuccess && (
        <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-center gap-2 text-green-700 text-sm mb-4">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          Delivery confirmed successfully!
        </div>
      )}

      {/* Fail Form */}
      {showFailForm && (
        <div className="bg-white border border-red-200 rounded-xl p-5 mb-4">
          <h2 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600" />
            Report Failed Delivery
          </h2>
          <form onSubmit={handleFail} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">
                Reason <span className="text-red-500">*</span>
              </label>
              <select
                value={failReason}
                onChange={(e) => setFailReason(e.target.value)}
                required
                className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-400"
              >
                {FAIL_REASONS.map((r) => (
                  <option key={r.value} value={r.value}>
                    {r.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 mb-1">
                Notes (optional)
              </label>
              <textarea
                value={failNotes}
                onChange={(e) => setFailNotes(e.target.value)}
                rows={3}
                placeholder="Additional details..."
                className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-400 resize-none"
              />
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                disabled={actionLoading}
                className="flex-1 py-2.5 bg-red-600 text-white rounded-xl text-sm font-medium hover:bg-red-700 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {actionLoading && <Loader2 className="w-4 h-4 animate-spin" />}
                Report Failed
              </button>
              <button
                type="button"
                onClick={() => setShowFailForm(false)}
                className="px-4 py-2.5 border border-gray-200 text-gray-600 rounded-xl text-sm hover:bg-gray-50"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
