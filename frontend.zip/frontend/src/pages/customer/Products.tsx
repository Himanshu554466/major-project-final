import React, { useEffect, useState, useCallback } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import api from '../../services/api';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';

interface Variant { id: string; price: number; color?: string; size?: string; stock: number; }
interface ProductImage { id: string; url: string; }
interface Product {
  id: string; title: string; description: string; category: string; brand: string;
  stock: number; deliveryCharge: number; freeDeliveryAbove: number;
  variants: Variant[]; images: ProductImage[];
  tags: { id: string; name: string }[];
  seller: { id: string; shopName: string; city: string };
}

const CATEGORIES = [
  'Electronics', 'Fashion', 'Home & Kitchen', 'Sports & Outdoors', 'Books',
  'Groceries', 'Beauty & Personal Care', 'Toys & Games', 'Automotive',
  'Health & Wellness', 'Furniture', 'Appliances', 'Jewelry', 'Pet Supplies', 'Office Supplies',
];

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(s => (
        <svg key={s} className={`w-3.5 h-3.5 ${s <= Math.round(rating) ? 'text-[#6d28d9]' : 'text-[#ddd]'}`} fill="currentColor" viewBox="0 0 20 20">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
    </div>
  );
}

export default function Products() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { isAuthenticated } = useAuth();

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [addingId, setAddingId] = useState<string | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const search   = searchParams.get('search')   || '';
  const category = searchParams.get('category') || '';
  const brand    = searchParams.get('brand')    || '';
  const sort     = searchParams.get('sort')     || 'newest';
  const minPrice = searchParams.get('minPrice') || '';
  const maxPrice = searchParams.get('maxPrice') || '';

  const [localMin, setLocalMin] = useState(minPrice);
  const [localMax, setLocalMax] = useState(maxPrice);
  useEffect(() => { setLocalMin(minPrice); setLocalMax(maxPrice); }, [minPrice, maxPrice]);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params: Record<string, string | number> = { page, limit: 20 };
      if (search)    params.search   = search;
      if (category)  params.category = category;
      if (brand)     params.brand    = brand;
      if (minPrice)  params.minPrice = minPrice;
      if (maxPrice)  params.maxPrice = maxPrice;
      const res = await api.get('/customer/products', { params });
      setProducts(res.data.products || []);
      setTotal(res.data.total ?? 0);
    } catch {
      setProducts([]); setTotal(0);
    } finally {
      setLoading(false);
    }
  }, [search, category, brand, minPrice, maxPrice, page]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const setParam = (key: string, value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value); else next.delete(key);
    setSearchParams(next); setPage(1);
  };

  const applyPriceFilter = () => {
    const next = new URLSearchParams(searchParams);
    if (localMin) next.set('minPrice', localMin); else next.delete('minPrice');
    if (localMax) next.set('maxPrice', localMax); else next.delete('maxPrice');
    setSearchParams(next); setPage(1);
  };

  const clearFilters = () => {
    setSearchParams({}); setLocalMin(''); setLocalMax(''); setPage(1);
  };

  const handleAddToCart = async (product: Product) => {
    if (!isAuthenticated) { navigate('/login'); return; }
    setAddingId(product.id);
    try {
      const variantId = product.variants?.[0]?.id;
      await addToCart(product.id, variantId, 1);
    } catch { /* ignore */ }
    finally { setAddingId(null); }
  };

  const hasFilters = category || brand || minPrice || maxPrice;
  const totalPages = Math.ceil(total / 20);

  const Skeleton = () => (
    <div className="bg-white border border-[#ddd] rounded-lg animate-pulse">
      <div className="aspect-square bg-[#f3f3f3] rounded-t-lg" />
      <div className="p-3 space-y-2">
        <div className="h-3 bg-[#f3f3f3] rounded w-1/2" />
        <div className="h-4 bg-[#f3f3f3] rounded" />
        <div className="h-4 bg-[#f3f3f3] rounded w-3/4" />
        <div className="h-8 bg-[#f3f3f3] rounded mt-2" />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#EAEDED]">
      <div className="max-w-[1500px] mx-auto px-4 py-5">

        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-medium text-[#0f1111]">
              {search ? `Results for "${search}"` : category ? category : brand ? `Brand: ${brand}` : 'All Products'}
            </h1>
            <p className="text-sm text-[#555]">{total.toLocaleString('en-IN')} results</p>
          </div>
          <button onClick={() => setFiltersOpen(!filtersOpen)}
            className="flex items-center gap-2 px-3 py-1.5 border border-[#888c8c] rounded text-sm bg-white hover:bg-[#f0f0f0] md:hidden">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
            </svg>
            Filters {hasFilters && <span className="w-2 h-2 bg-[#6d28d9] rounded-full" />}
          </button>
        </div>

        <div className="flex gap-5">
          {/* Sidebar */}
          <aside className={`w-60 shrink-0 ${filtersOpen ? 'block' : 'hidden'} md:block`}>
            <div className="bg-white border border-[#ddd] rounded-lg overflow-hidden sticky top-24">
              <div className="px-4 py-3 border-b border-[#eee] flex items-center justify-between">
                <h3 className="text-base font-bold text-[#0f1111]">Filters</h3>
                {hasFilters && (
                  <button onClick={clearFilters} className="text-xs text-[#0066c0] hover:text-[#5b21b6] hover:underline">Clear all</button>
                )}
              </div>
              <div className="p-4 space-y-5">

                {/* Sort */}
                <div>
                  <p className="text-sm font-bold text-[#0f1111] mb-2.5">Sort by</p>
                  <div className="space-y-2">
                    {[
                      { value: 'newest', label: 'Newest Arrivals' },
                      { value: 'price_asc', label: 'Price: Low to High' },
                      { value: 'price_desc', label: 'Price: High to Low' },
                    ].map(s => (
                      <label key={s.value} className="flex items-center gap-2.5 cursor-pointer group">
                        <input type="radio" name="sort" value={s.value} checked={sort === s.value}
                          onChange={() => setParam('sort', s.value)}
                          className="accent-[#6d28d9] w-4 h-4" />
                        <span className="text-sm text-[#0f1111] group-hover:text-[#5b21b6]">{s.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="border-t border-[#eee]" />

                {/* Category */}
                <div>
                  <p className="text-sm font-bold text-[#0f1111] mb-2.5">Category</p>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto">
                    {CATEGORIES.map(c => (
                      <label key={c} className="flex items-center gap-2.5 cursor-pointer group">
                        <input type="checkbox" checked={category === c}
                          onChange={() => setParam('category', category === c ? '' : c)}
                          className="accent-[#6d28d9] w-4 h-4" />
                        <span className={`text-sm group-hover:text-[#5b21b6] ${category === c ? 'text-[#5b21b6] font-semibold' : 'text-[#0f1111]'}`}>{c}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="border-t border-[#eee]" />

                {/* Price Range */}
                <div>
                  <p className="text-sm font-bold text-[#0f1111] mb-2.5">Price Range</p>
                  <div className="flex items-center gap-2 mb-3">
                    <input type="number" placeholder="Min ₹" value={localMin}
                      onChange={e => setLocalMin(e.target.value)}
                      className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#6d28d9] focus:ring-1 focus:ring-[#6d28d9]" />
                    <span className="text-[#555] text-sm shrink-0">–</span>
                    <input type="number" placeholder="Max ₹" value={localMax}
                      onChange={e => setLocalMax(e.target.value)}
                      className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#6d28d9] focus:ring-1 focus:ring-[#6d28d9]" />
                  </div>
                  <button onClick={applyPriceFilter}
                    className="w-full py-2 bg-[#FFD814] hover:bg-[#7c3aed] border border-[#FCD200] rounded text-sm font-semibold text-[#111] transition-colors">
                    Apply
                  </button>
                </div>
              </div>
            </div>
          </aside>

          {/* Products Grid */}
          <div className="flex-1 min-w-0">
            {/* Active filter tags */}
            {(category || brand || minPrice || maxPrice) && (
              <div className="flex flex-wrap gap-2 mb-3">
                {category && (
                  <span className="flex items-center gap-1 text-xs bg-white border border-[#ddd] px-3 py-1 rounded-full">
                    {category}
                    <button onClick={() => setParam('category', '')} className="ml-1 text-[#555] hover:text-[#CC0C39]">×</button>
                  </span>
                )}
                {brand && (
                  <span className="flex items-center gap-1 text-xs bg-white border border-[#ddd] px-3 py-1 rounded-full">
                    Brand: {brand}
                    <button onClick={() => setParam('brand', '')} className="ml-1 text-[#555] hover:text-[#CC0C39]">×</button>
                  </span>
                )}
                {(minPrice || maxPrice) && (
                  <span className="flex items-center gap-1 text-xs bg-white border border-[#ddd] px-3 py-1 rounded-full">
                    ₹{minPrice || '0'} – ₹{maxPrice || '∞'}
                    <button onClick={() => { setParam('minPrice', ''); setParam('maxPrice', ''); setLocalMin(''); setLocalMax(''); }} className="ml-1 text-[#555] hover:text-[#CC0C39]">×</button>
                  </span>
                )}
              </div>
            )}

            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {[...Array(12)].map((_, i) => <Skeleton key={i} />)}
              </div>
            ) : products.length === 0 ? (
              <div className="bg-white border border-[#ddd] rounded-lg p-12 text-center">
                <p className="text-5xl mb-4">🔍</p>
                <p className="text-xl font-medium text-[#0f1111] mb-1">No results found</p>
                <p className="text-sm text-[#555] mb-4">Try different search terms or remove filters</p>
                <button onClick={clearFilters}
                  className="px-6 py-2 bg-[#FFD814] border border-[#FCD200] rounded text-sm font-semibold text-[#111]">
                  Clear Filters
                </button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {products.map(product => {
                    const minPrice = product.variants?.length ? Math.min(...product.variants.map(v => v.price)) : 0;
                    const mrp = minPrice ? Math.round(minPrice * 1.3) : 0;
                    const discountPct = mrp ? Math.round(((mrp - minPrice) / mrp) * 100) : 0;
                    const inStock = product.variants?.some(v => v.stock > 0) ?? false;
                    const image = product.images?.[0]?.url;
                    const rating = 4.1 + ((parseInt(product.id) * 7) % 10) / 10 * 0.8;
                    const reviewCount = 1200 + (parseInt(product.id) * 37) % 4800;

                    return (
                      <div key={product.id} className="group bg-white border border-[#ddd] rounded-lg hover:shadow-lg transition-shadow duration-200 relative overflow-hidden flex flex-col">
                        {discountPct > 0 && inStock && (
                          <div className="absolute top-2.5 left-2.5 z-10 bg-[#CC0C39] text-white text-[11px] font-bold px-2 py-0.5 rounded">
                            -{discountPct}%
                          </div>
                        )}
                        <Link to={`/products/${product.id}`} className="block">
                          <div className="aspect-square bg-white flex items-center justify-center p-4 border-b border-[#f0f0f0] overflow-hidden">
                            {image ? (
                              <img src={image} alt={product.title}
                                className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-300" />
                            ) : (
                              <span className="text-5xl text-[#ddd]">📦</span>
                            )}
                            {!inStock && (
                              <div className="absolute inset-0 bg-white/80 flex items-center justify-center">
                                <span className="text-xs font-bold text-[#CC0C39] bg-white px-3 py-1.5 border border-[#CC0C39] rounded">OUT OF STOCK</span>
                              </div>
                            )}
                          </div>
                        </Link>
                        <div className="p-3.5 flex flex-col flex-1">
                          {product.brand && <p className="text-[#0066c0] text-xs mb-0.5 truncate font-medium">{product.brand}</p>}
                          <Link to={`/products/${product.id}`}>
                            <p className="text-[#0f1111] text-sm leading-snug line-clamp-2 min-h-[2.5rem] mb-1.5 hover:text-[#5b21b6]">{product.title}</p>
                          </Link>
                          <div className="mb-2 flex items-center gap-1.5">
                            <Stars rating={rating} />
                            <span className="text-xs text-[#0066c0]">({reviewCount.toLocaleString('en-IN')})</span>
                          </div>
                          {minPrice > 0 && (
                            <div className="mb-1">
                              <span className="text-xl font-bold text-[#B12704]">₹{minPrice.toLocaleString('en-IN')}</span>
                              {mrp > 0 && <p className="text-xs text-[#565959]">M.R.P: <span className="line-through">₹{mrp.toLocaleString('en-IN')}</span></p>}
                            </div>
                          )}
                          <p className="text-[#007600] text-xs mb-3">
                            {product.deliveryCharge === 0 ? 'FREE Delivery' : `₹${product.deliveryCharge} delivery`}
                          </p>
                          <div className="mt-auto">
                            {inStock ? (
                              <button onClick={() => handleAddToCart(product)} disabled={addingId === product.id}
                                className="w-full py-2 text-sm font-semibold rounded border transition-all bg-[#FFD814] hover:bg-[#7c3aed] border-[#FCD200] text-[#111] disabled:opacity-60">
                                {addingId === product.id ? '✓ Adding...' : 'Add to Cart'}
                              </button>
                            ) : (
                              <button disabled className="w-full py-2 text-sm font-semibold rounded border bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed">
                                Out of Stock
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-center gap-2 mt-6">
                    <button disabled={page === 1} onClick={() => setPage(p => p - 1)}
                      className="px-4 py-2 border border-[#888c8c] rounded text-sm bg-white hover:bg-[#f0f0f0] disabled:opacity-40">
                      ← Previous
                    </button>
                    <span className="text-sm text-[#555] px-3">Page {page} of {totalPages}</span>
                    <button disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}
                      className="px-4 py-2 border border-[#888c8c] rounded text-sm bg-white hover:bg-[#f0f0f0] disabled:opacity-40">
                      Next →
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
