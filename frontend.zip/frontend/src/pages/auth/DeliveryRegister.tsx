import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../../services/api';

const DeliveryRegister: React.FC = () => {
  const [form, setForm] = useState({
    fullName: '', email: '', password: '', confirmPassword: '',
    deliveryPhone: '', deliveryCity: '', deliveryPincode: '',
    vehicleType: '', vehicleNumber: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    // Validate phone number - only allow digits, +, and spaces
    if (name === 'deliveryPhone') {
      const cleaned = value.replace(/[^\d+\s]/g, '');
      setForm({ ...form, [name]: cleaned });
      return;
    }
    
    // Validate pincode - only allow digits
    if (name === 'deliveryPincode') {
      const cleaned = value.replace(/\D/g, '');
      setForm({ ...form, [name]: cleaned });
      return;
    }
    
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const { fullName, email, password, confirmPassword, deliveryPhone, deliveryCity, deliveryPincode, vehicleType, vehicleNumber } = form;
    if (!fullName || !email || !password || !confirmPassword || !deliveryPhone || !deliveryCity || !deliveryPincode || !vehicleType || !vehicleNumber) {
      setError('Please fill in all fields.'); return;
    }
    if (password !== confirmPassword) { setError('Passwords do not match.'); return; }
    if (password.length < 6) { setError('Password must be at least 6 characters.'); return; }
    try {
      setLoading(true);
      await api.post('/auth/register', { email, password, fullName, role: 'delivery_partner', deliveryPhone, deliveryCity, deliveryPincode, vehicleType, vehicleNumber });
      navigate('/delivery/login');
    } catch (err: unknown) {
      setError((err as { response?: { data?: { message?: string } } })?.response?.data?.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#EAEDED] flex flex-col items-center pt-8 pb-16 px-4">
      {/* Logo */}
      <Link to="/" className="mb-6">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-[#6d28d9] rounded-md flex items-center justify-center">
            <span className="text-white font-black text-lg">E</span>
          </div>
          <span className="font-black text-2xl text-[#1e1b4b] tracking-tight">Ecom<span className="text-[#6d28d9]">merce</span></span>
        </div>
      </Link>

      <div className="w-full max-w-sm bg-white border border-[#ddd] rounded-lg overflow-hidden">
        {/* Portal header */}
        <div className="bg-[#1a3a2a] px-6 py-4 flex items-center gap-3">
          <div className="w-10 h-10 bg-[#6d28d9] rounded-lg flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0" />
            </svg>
          </div>
          <div>
            <p className="text-white font-bold text-base leading-tight">Become a Delivery Partner</p>
            <p className="text-[#86b89a] text-xs">Earn on your own schedule</p>
          </div>
        </div>

        <div className="p-6">
          <h1 className="text-xl font-medium text-[#0f1111] mb-5">Create partner account</h1>

          {error && (
            <div className="mb-4 p-3 bg-[#fff8f0] border border-[#e77600] rounded text-sm text-[#5b21b6] flex items-start gap-2">
              <svg className="w-4 h-4 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-[#0f1111] mb-1">Full name <span className="text-[#CC0C39]">*</span></label>
              <input type="text" name="fullName" value={form.fullName} onChange={handleChange}
                placeholder="Your full name"
                className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0f1111] mb-1">Email address <span className="text-[#CC0C39]">*</span></label>
              <input type="email" name="email" value={form.email} onChange={handleChange}
                className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0f1111] mb-1">Phone number <span className="text-[#CC0C39]">*</span></label>
              <input 
                type="tel" 
                name="deliveryPhone" 
                value={form.deliveryPhone} 
                onChange={handleChange}
                placeholder="+91 XXXXX XXXXX"
                pattern="[\d+\s]*"
                title="Please enter only numbers"
                maxLength={15}
                className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30" 
                required 
              />
              <p className="text-xs text-[#555] mt-1">Enter numbers only</p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-sm font-medium text-[#0f1111] mb-1">City <span className="text-[#CC0C39]">*</span></label>
                <input type="text" name="deliveryCity" value={form.deliveryCity} onChange={handleChange}
                  placeholder="City"
                  className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0f1111] mb-1">Pincode <span className="text-[#CC0C39]">*</span></label>
                <input 
                  type="text" 
                  name="deliveryPincode" 
                  value={form.deliveryPincode} 
                  onChange={handleChange}
                  placeholder="560001"
                  pattern="\d*"
                  title="Please enter only numbers"
                  maxLength={6}
                  className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30" 
                  required 
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-sm font-medium text-[#0f1111] mb-1">Vehicle type <span className="text-[#CC0C39]">*</span></label>
                <select name="vehicleType" value={form.vehicleType} onChange={handleChange}
                  className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30 bg-white" required>
                  <option value="">Select</option>
                  <option value="bike">Bike</option>
                  <option value="scooter">Scooter</option>
                  <option value="car">Car</option>
                  <option value="van">Van</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0f1111] mb-1">Vehicle no. <span className="text-[#CC0C39]">*</span></label>
                <input type="text" name="vehicleNumber" value={form.vehicleNumber} onChange={handleChange}
                  placeholder="MH12AB1234"
                  className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30 uppercase" required />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0f1111] mb-1">Password <span className="text-[#CC0C39]">*</span></label>
              <div className="relative">
                <input type={showPassword ? 'text' : 'password'} name="password" value={form.password} onChange={handleChange}
                  placeholder="At least 6 characters"
                  className="w-full px-3 py-2 pr-10 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30" required />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#0066c0] hover:text-[#5b21b6] hover:underline">
                  {showPassword ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0f1111] mb-1">Confirm password <span className="text-[#CC0C39]">*</span></label>
              <div className="relative">
                <input type={showConfirm ? 'text' : 'password'} name="confirmPassword" value={form.confirmPassword} onChange={handleChange}
                  placeholder="Re-enter password"
                  className={`w-full px-3 py-2 pr-10 border rounded text-sm focus:outline-none focus:ring-2 focus:ring-[#e77600]/30 ${
                    form.confirmPassword && form.password !== form.confirmPassword ? 'border-[#CC0C39] focus:border-[#CC0C39]' : 'border-[#888c8c] focus:border-[#e77600]'
                  }`} required />
                <button type="button" onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#0066c0] hover:text-[#5b21b6] hover:underline">
                  {showConfirm ? 'Hide' : 'Show'}
                </button>
              </div>
              {form.confirmPassword && form.password !== form.confirmPassword && (
                <p className="text-xs text-[#CC0C39] mt-1">Passwords do not match</p>
              )}
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-2 bg-[#FFD814] hover:bg-[#7c3aed] border border-[#FCD200] rounded text-sm font-semibold text-[#111] transition-colors disabled:opacity-60 mt-1">
              {loading ? 'Registering...' : 'Register as delivery partner'}
            </button>
          </form>

          <div className="mt-4 pt-4 border-t border-[#eee]">
            <p className="text-sm text-[#0f1111]">
              Already a partner?{' '}
              <Link to="/delivery/login" className="text-[#0066c0] hover:text-[#5b21b6] hover:underline font-medium">Sign in</Link>
            </p>
          </div>
        </div>
      </div>

      <div className="w-full max-w-sm mt-5 flex items-center gap-3">
        <div className="flex-1 h-px bg-[#ddd]" />
        <span className="text-xs text-[#767676]">Other portals</span>
        <div className="flex-1 h-px bg-[#ddd]" />
      </div>
      <div className="w-full max-w-sm mt-3 grid grid-cols-3 gap-2">
        {[{ to: '/login', label: 'Customer' }, { to: '/seller/login', label: 'Seller' }, { to: '/admin/login', label: 'Admin' }].map(p => (
          <Link key={p.to} to={p.to}
            className="py-2 border border-[#ddd] rounded text-xs text-center text-[#0066c0] hover:bg-[#f0f0f0] hover:text-[#5b21b6] transition-colors bg-white">
            {p.label}
          </Link>
        ))}
      </div>
    </div>
  );
};

export default DeliveryRegister;
