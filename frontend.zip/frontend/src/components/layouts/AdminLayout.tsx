import React, { useState, useEffect } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Users, Package, ShoppingBag,
  Truck, MessageSquare, LogOut, Menu, Shield, RotateCcw,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const AdminLayout: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [pendingRefunds, setPendingRefunds] = useState(0);

  useEffect(() => {
    api.get('/admin/refunds/stats')
      .then(res => setPendingRefunds(res.data.pending || 0))
      .catch(() => {});
    const interval = setInterval(() => {
      api.get('/admin/refunds/stats')
        .then(res => setPendingRefunds(res.data.pending || 0))
        .catch(() => {});
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => { logout(); navigate('/admin/login'); };

  const NAV = [
    { to: '/admin/dashboard',  icon: LayoutDashboard, label: 'Dashboard', badge: 0 },
    { to: '/admin/users',      icon: Users,           label: 'Users', badge: 0 },
    { to: '/admin/products',   icon: Package,         label: 'Products', badge: 0 },
    { to: '/admin/orders',     icon: ShoppingBag,     label: 'Orders', badge: 0 },
    { to: '/admin/shipments',  icon: Truck,           label: 'Shipments', badge: 0 },
    { to: '/admin/refunds',    icon: RotateCcw,       label: 'Refunds', badge: pendingRefunds },
    { to: '/admin/complaints', icon: MessageSquare,   label: 'Complaints', badge: 0 },
  ];

  const Sidebar = () => (
    <div className="flex flex-col h-full w-64 bg-gray-900 text-white">
      <div className="flex items-center gap-3 px-6 py-5 border-b border-gray-700">
        <div className="w-9 h-9 bg-orange-500 rounded-xl flex items-center justify-center">
          <Shield size={18} className="text-white" />
        </div>
        <div>
          <p className="font-bold text-sm">Ecommerce</p>
          <p className="text-gray-400 text-xs">Admin Portal</p>
        </div>
      </div>
      <div className="px-4 py-3 border-b border-gray-700">
        <p className="text-xs text-gray-500">Admin</p>
        <p className="text-sm font-semibold truncate">{user?.email}</p>
      </div>
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {NAV.map(({ to, icon: Icon, label, badge }) => (
          <NavLink
            key={to}
            to={to}
            onClick={() => setOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                isActive ? 'bg-gray-700 text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white'
              }`
            }
          >
            <Icon size={18} />
            {label}
            {badge > 0 && (
              <span className="ml-auto min-w-[18px] h-[18px] bg-yellow-400 text-gray-900 text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                {badge}
              </span>
            )}
          </NavLink>
        ))}
      </nav>
      <div className="px-3 py-4 border-t border-gray-700">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm text-gray-400 hover:bg-gray-800 hover:text-white transition-colors"
        >
          <LogOut size={18} />
          Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-100 overflow-hidden">
      <div className="hidden md:flex flex-shrink-0"><Sidebar /></div>
      {open && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <Sidebar />
          <div className="flex-1 bg-black/50" onClick={() => setOpen(false)} />
        </div>
      )}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="md:hidden flex items-center justify-between px-4 py-3 bg-gray-900 text-white">
          <button onClick={() => setOpen(true)}><Menu size={22} /></button>
          <span className="font-bold text-sm">Admin Portal</span>
          <div className="w-6" />
        </div>
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
