import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  Package, MapPin, CreditCard, Truck, CheckCircle, XCircle,
  Clock, ChevronRight, AlertCircle, Loader2, RotateCcw, RefreshCw,
} from 'lucide-react';
import api from '../../services/api';

interface TrackingEvent {
  status: string;
  message: string;
  timestamp: string;
  location?: string;
  actorRole?: string;
}

interface Shipment {
  id: string;
  status: string;
  isReturn?: boolean;
  returnReason?: string;
  deliveryPartner?: { fullName: string; deliveryPhone: string };
  trackingEvents: TrackingEvent[];
}

interface OrderItem {
  id: string;
  quantity: number;
  price: number;
  product: { title: string; images: { id: string; url: string }[] };
  variant?: { color?: string; size?: string };
}

interface Order {
  id: string;
  status: string;
  totalAmount: number;
  paymentMethod: string;
  paymentStatus: string;
  returnReason?: string;
  createdAt: string;
  items: OrderItem[];
  shipment?: Shipment;
  returnShipment?: Shipment | null;
  address: { name: string; phone: string; line1: string; line2?: string; city: string; state?: string; pincode: string };
}

const STATUS_BADGE: Record<string, string> = {
  placed: 'bg-blue-100 text-blue-700',
  confirmed: 'bg-indigo-100 text-indigo-700',
  preparing: 'bg-yellow-100 text-yellow-700',
  packed: 'bg-orange-100 text-orange-700',
  shipped: 'bg-purple-100 text-purple-700',
  out_for_delivery: 'bg-cyan-100 text-cyan-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
  rejected: 'bg-red-100 text-red-700',
  return_requested: 'bg-pink-100 text-pink-700',
  return_approved: 'bg-orange-100 text-orange-700',
  returned: 'bg-teal-100 text-teal-700',
  refund_initiated: 'bg-yellow-100 text-yellow-700',
  refund_completed: 'bg-green-100 text-green-700',
};

// Forward delivery timeline
const FORWARD_TIMELINE = [
  { key: 'placed',           label: 'Order Placed' },
  { key: 'confirmed',        label: 'Confirmed' },
  { key: 'preparing',        label: 'Preparing' },
  { key: 'packed',           label: 'Packed' },
  { key: 'shipped',          label: 'Shipped' },
  { key: 'out_for_delivery', label: 'Out for Delivery' },
  { key: 'delivered',        label: 'Delivered' },
];

// ── Customer Return Timeline (simplified — no internal logistics) ─────────
const CUSTOMER_RETURN_TIMELINE = [
  { key: 'return_requested', label: 'Return Requested' },
  { key: 'return_approved',  label: 'Return Approved' },
  { key: 'PACKED',           label: 'Pickup Scheduled' },
  { key: 'OUT_FOR_PICKUP',   label: 'Out for Pickup' },
  { key: 'PICKED_UP',        label: 'Item Picked Up' },
  { key: 'refund_initiated', label: 'Refund Initiated' },
  { key: 'refund_completed', label: 'Refund Completed' },
];

// Map return shipment status → customer return step key
const RETURN_SHIP_TO_CUSTOMER_STEP: Record<string, string> = {
  PACKED:           'PACKED',
  ASSIGNED:         'PACKED',
  ACCEPTED:         'PACKED',
  OUT_FOR_DELIVERY: 'OUT_FOR_PICKUP',
  PICKED_UP:        'PICKED_UP',
  IN_TRANSIT:       'PICKED_UP',
  DELIVERED:        'PICKED_UP', // item at seller — refund next
};

export default function OrderDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [cancelling, setCancelling] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelError, setCancelError] = useState('');
  const [actionMsg, setActionMsg] = useState('');

  const fetchOrder = useCallback(() => {
    if (!id) return;
    api.get(`/customer/orders/${id}`)
      .then(res => setOrder(res.data.order || res.data))
      .catch(() => setError('Order not found.'))
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => { fetchOrder(); }, [fetchOrder]);

  const handleCancel = async () => {
    if (!cancelReason.trim()) { setCancelError('Please provide a reason.'); return; }
    setCancelling(true);
    setCancelError('');
    try {
      await api.post(`/customer/orders/${id}/cancel`, { reason: cancelReason });
      setOrder(prev => prev ? { ...prev, status: 'cancelled' } : prev);
      setShowCancelModal(false);
      setActionMsg('Order cancelled successfully.');
      setTimeout(() => setActionMsg(''), 3000);
    } catch {
      setCancelError('Failed to cancel order. Please try again.');
    } finally {
      setCancelling(false);
    }
  };

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleString('en-IN', {
      day: 'numeric', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });

  // Determine which step is active in forward timeline
  const forwardStepIdx = order
    ? FORWARD_TIMELINE.findIndex(s => s.key === order.status)
    : -1;

  // Determine which step is active in return timeline (customer-simplified)
  const getReturnStepIdx = () => {
    if (!order) return -1;
    const KEYS = CUSTOMER_RETURN_TIMELINE.map(s => s.key);
    const returnShipStatus = order.returnShipment?.status?.toUpperCase();
    const mappedShipStatus = returnShipStatus ? RETURN_SHIP_TO_CUSTOMER_STEP[returnShipStatus] : null;
    const orderStatusIdx = KEYS.indexOf(order.status);
    const shipIdx = mappedShipStatus ? KEYS.indexOf(mappedShipStatus) : -1;
    // If return shipment delivered → check order for refund status
    if (returnShipStatus === 'DELIVERED') {
      if (order.status === 'refund_completed') return KEYS.indexOf('refund_completed');
      if (order.status === 'refund_initiated') return KEYS.indexOf('refund_initiated');
      return KEYS.indexOf('PICKED_UP');
    }
    return Math.max(orderStatusIdx, shipIdx);
  };

  const returnStepIdx = getReturnStepIdx();

  const isReturnFlow = order && (
    ['return_requested', 'return_approved', 'returned', 'refund_initiated', 'refund_completed'].includes(order.status)
    || !!order.returnShipment
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
        <p className="text-xl font-semibold text-gray-700">{error || 'Order not found'}</p>
        <Link to="/orders" className="mt-4 inline-block text-orange-500 hover:text-orange-600 font-medium">
          ← Back to Orders
        </Link>
      </div>
    );
  }

  // All tracking events merged (forward + return), sorted newest first
  const allTrackingEvents: (TrackingEvent & { isReturn?: boolean })[] = [
    ...(order.shipment?.trackingEvents || []).map(e => ({ ...e, isReturn: false })),
    ...(order.returnShipment?.trackingEvents || []).map(e => ({ ...e, isReturn: true })),
  ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <button onClick={() => navigate('/orders')} className="text-gray-500 hover:text-orange-500 transition-colors">
            <ChevronRight className="w-5 h-5 rotate-180" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-gray-800">Order #{String(order.id).padStart(6, '0')}</h1>
            <p className="text-sm text-gray-500">Placed on {formatDate(order.createdAt)}</p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <button onClick={fetchOrder} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600">
              <RefreshCw className="w-4 h-4" />
            </button>
            <span className={`flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-full capitalize ${STATUS_BADGE[order.status] || 'bg-gray-100 text-gray-600'}`}>
              {order.status.replace(/_/g, ' ')}
            </span>
          </div>
        </div>

        {actionMsg && (
          <div className="mb-4 bg-green-50 border border-green-200 text-green-700 rounded-xl px-4 py-3 flex items-center gap-2">
            <CheckCircle className="w-5 h-5" /> {actionMsg}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Left Column */}
          <div className="lg:col-span-2 space-y-5">

            {/* ── Forward Order Timeline — always shown (shows delivery as completed) ── */}
            {order.status !== 'cancelled' && order.status !== 'rejected' && (
              <div className="bg-white rounded-xl shadow-sm p-5">
                <h2 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <Truck className="w-5 h-5 text-orange-500" /> Order Progress
                  {isReturnFlow && (
                    <span className="ml-auto text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">✓ Delivered</span>
                  )}
                </h2>
                <div className="relative">
                  {FORWARD_TIMELINE.map((step, idx) => {
                    // In return flow, show all steps as done (order was delivered)
                    const effectiveIdx = isReturnFlow
                      ? FORWARD_TIMELINE.length - 1  // all steps done
                      : forwardStepIdx;
                    const done = idx <= effectiveIdx;
                    const active = !isReturnFlow && idx === forwardStepIdx;
                    return (
                      <div key={step.key} className="flex items-start gap-3 pb-4 last:pb-0">
                        <div className="flex flex-col items-center">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                            done ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-400'
                          } ${active ? 'ring-2 ring-orange-300' : ''}`}>
                            {done ? <CheckCircle className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                          </div>
                          {idx < FORWARD_TIMELINE.length - 1 && (
                            <div className={`w-0.5 h-6 mt-1 ${done && idx < effectiveIdx ? 'bg-orange-400' : 'bg-gray-200'}`} />
                          )}
                        </div>
                        <div className="pt-1">
                          <p className={`text-sm font-medium ${done ? 'text-gray-800' : 'text-gray-400'}`}>{step.label}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ── Return Progress Timeline (Customer — simplified) ── */}
            {isReturnFlow && (
              <div className="bg-white rounded-xl shadow-sm p-5 border-l-4 border-pink-400">
                <h2 className="font-bold text-gray-800 mb-1 flex items-center gap-2">
                  <RotateCcw className="w-5 h-5 text-pink-500" /> Return Progress
                </h2>
                {order.returnReason && (
                  <p className="text-xs text-pink-600 mb-4 bg-pink-50 rounded-lg px-3 py-2">
                    Reason: {order.returnReason}
                  </p>
                )}
                <div className="relative">
                  {CUSTOMER_RETURN_TIMELINE.map((step, idx) => {
                    const done = idx <= returnStepIdx;
                    const active = idx === returnStepIdx;
                    return (
                      <div key={step.key} className="flex items-start gap-3 pb-4 last:pb-0">
                        <div className="flex flex-col items-center">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                            done ? 'bg-pink-500 text-white' : 'bg-gray-100 text-gray-400'
                          } ${active ? 'ring-2 ring-pink-300' : ''}`}>
                            {done ? <CheckCircle className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                          </div>
                          {idx < CUSTOMER_RETURN_TIMELINE.length - 1 && (
                            <div className={`w-0.5 h-6 mt-1 ${done && idx < returnStepIdx ? 'bg-pink-400' : 'bg-gray-200'}`} />
                          )}
                        </div>
                        <div className="pt-1">
                          <p className={`text-sm font-medium ${done ? 'text-gray-800' : 'text-gray-400'}`}>{step.label}</p>
                          {/* Show pickup partner when out for pickup */}
                          {active && step.key === 'OUT_FOR_PICKUP' && order.returnShipment?.deliveryPartner && (
                            <p className="text-xs text-pink-600 mt-0.5">
                              🛵 {order.returnShipment.deliveryPartner.fullName} · {order.returnShipment.deliveryPartner.deliveryPhone}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Refund info */}
                {order.status === 'refund_completed' && (
                  <div className="mt-4 bg-green-50 border border-green-200 rounded-xl p-3 flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-semibold text-green-700">Refund Processed</p>
                      <p className="text-xs text-green-600">₹{order.totalAmount.toLocaleString()} will be credited within 5–7 business days.</p>
                    </div>
                  </div>
                )}
                {order.status === 'refund_initiated' && (
                  <div className="mt-4 bg-yellow-50 border border-yellow-200 rounded-xl p-3 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-yellow-600 flex-shrink-0" />
                    <p className="text-sm text-yellow-700">
                      Refund of ₹{order.totalAmount.toLocaleString()} is being processed. Allow 5–7 business days.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Items */}
            <div className="bg-white rounded-xl shadow-sm p-5">
              <h2 className="font-bold text-gray-800 mb-4">Items Ordered</h2>
              <div className="space-y-4">
                {order.items.map(item => {
                  const imageUrl = item.product?.images?.[0]?.url;
                  const variantLabel = [item.variant?.color, item.variant?.size].filter(Boolean).join(', ');
                  return (
                    <div key={item.id} className="flex gap-4 py-3 border-b border-gray-100 last:border-0">
                      <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                        {imageUrl ? (
                          <img src={imageUrl} alt={item.product.title} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Package className="w-7 h-7 text-gray-300" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-gray-800 line-clamp-2">{item.product.title}</p>
                        {variantLabel && <p className="text-xs text-gray-500 mt-0.5">{variantLabel}</p>}
                        <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="text-sm font-bold text-gray-900">₹{(item.price * item.quantity).toLocaleString()}</p>
                        <p className="text-xs text-gray-400">₹{item.price} each</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* All Tracking Events — customer-friendly labels */}
            {allTrackingEvents.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm p-5">
                <h2 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <Truck className="w-5 h-5 text-orange-500" /> Tracking History
                </h2>
                <div className="space-y-0">
                  {allTrackingEvents.map((event, idx) => {
                    // Customer-friendly label for return events
                    const label = event.isReturn ? ({
                      PACKED:           'Pickup Scheduled',
                      ASSIGNED:         'Pickup Partner Assigned',
                      ACCEPTED:         'Partner Accepted Pickup',
                      OUT_FOR_DELIVERY: 'Out for Pickup',
                      PICKED_UP:        'Item Picked Up from You',
                      IN_TRANSIT:       'Item on the Way Back',
                      DELIVERED:        'Item Returned to Seller',
                      DECLINED:         'Pickup Declined — Rescheduling',
                    } as Record<string, string>)[event.status.toUpperCase()] || event.status.replace(/_/g, ' ')
                    : event.status.replace(/_/g, ' ');

                    return (
                      <div key={idx} className="flex gap-3">
                        <div className="flex flex-col items-center">
                          <div className={`w-3 h-3 rounded-full flex-shrink-0 mt-1.5 ${
                            idx === 0 ? event.isReturn ? 'bg-pink-500' : 'bg-orange-500' : 'bg-gray-300'
                          }`} />
                          {idx < allTrackingEvents.length - 1 && (
                            <div className="w-0.5 flex-1 bg-gray-200 my-1 min-h-[1.5rem]" />
                          )}
                        </div>
                        <div className="pb-4">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-semibold text-gray-800 capitalize">{label}</p>
                            {event.isReturn && (
                              <span className="text-[10px] bg-pink-100 text-pink-600 px-1.5 py-0.5 rounded-full font-medium">RETURN</span>
                            )}
                          </div>
                          <p className="text-xs text-gray-600">{event.message}</p>
                          {event.location && <p className="text-xs text-gray-400">{event.location}</p>}
                          <p className="text-xs text-gray-400 mt-0.5">{formatDate(event.timestamp)}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Right Column */}
          <div className="space-y-5">
            {/* Delivery Address */}
            <div className="bg-white rounded-xl shadow-sm p-5">
              <h2 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-orange-500" /> Delivery Address
              </h2>
              <p className="font-semibold text-gray-800">{order.address.name}</p>
              <p className="text-sm text-gray-600">{order.address.phone}</p>
              <p className="text-sm text-gray-600 mt-1">
                {order.address.line1}{order.address.line2 ? `, ${order.address.line2}` : ''}
              </p>
              <p className="text-sm text-gray-600">{order.address.city} - {order.address.pincode}</p>
            </div>

            {/* Return Shipment Partner (if assigned) */}
            {isReturnFlow && order.returnShipment?.deliveryPartner && (
              <div className="bg-white rounded-xl shadow-sm p-5 border border-pink-200">
                <h2 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                  <RotateCcw className="w-4 h-4 text-pink-500" /> Return Pickup Partner
                </h2>
                <p className="font-semibold text-gray-800">{order.returnShipment.deliveryPartner.fullName}</p>
                <p className="text-sm text-gray-600">{order.returnShipment.deliveryPartner.deliveryPhone}</p>
                <p className="text-xs text-pink-600 mt-1 capitalize">
                  Status: {order.returnShipment.status.replace(/_/g, ' ')}
                </p>
              </div>
            )}

            {/* Payment Info */}
            <div className="bg-white rounded-xl shadow-sm p-5">
              <h2 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-orange-500" /> Payment
              </h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-gray-600">
                  <span>Method</span>
                  <span className="font-medium capitalize">{order.paymentMethod?.replace(/_/g, ' ')}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Status</span>
                  <span className={`font-medium capitalize ${
                    order.paymentStatus === 'paid' ? 'text-green-600' :
                    order.paymentStatus === 'refunded' ? 'text-teal-600' :
                    'text-yellow-600'
                  }`}>
                    {order.paymentStatus}
                  </span>
                </div>
                <div className="flex justify-between font-bold text-gray-900 border-t border-gray-100 pt-2">
                  <span>Total</span>
                  <span>₹{order.totalAmount.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2">
              {['placed', 'confirmed'].includes(order.status) && (
                <button onClick={() => setShowCancelModal(true)}
                  className="w-full flex items-center justify-center gap-2 border-2 border-red-200 text-red-500 hover:bg-red-50 font-semibold py-2.5 rounded-xl transition-colors text-sm">
                  <XCircle className="w-4 h-4" /> Cancel Order
                </button>
              )}
              {['placed', 'confirmed', 'preparing', 'packed', 'shipped', 'out_for_delivery'].includes(order.status) && (
                <button onClick={() => navigate(`/orders/${order.id}/track`)}
                  className="w-full flex items-center justify-center gap-2 bg-indigo-500 hover:bg-indigo-600 text-white font-semibold py-2.5 rounded-xl transition-colors text-sm">
                  <Truck className="w-4 h-4" /> Track Live
                </button>
              )}
              {isReturnFlow && order.returnShipment && (
                <button onClick={() => navigate(`/orders/${order.id}/track`)}
                  className="w-full flex items-center justify-center gap-2 bg-pink-500 hover:bg-pink-600 text-white font-semibold py-2.5 rounded-xl transition-colors text-sm">
                  <RotateCcw className="w-4 h-4" /> Track Return
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Cancel Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 px-4">
          <div className="bg-white rounded-2xl shadow-xl p-6 w-full max-w-md">
            <h3 className="text-lg font-bold text-gray-800 mb-2">Cancel Order</h3>
            <p className="text-sm text-gray-500 mb-4">Please provide a reason for cancellation.</p>
            <textarea value={cancelReason} onChange={e => setCancelReason(e.target.value)}
              placeholder="Reason for cancellation..." rows={3}
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-red-400 resize-none" />
            {cancelError && (
              <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> {cancelError}
              </p>
            )}
            <div className="flex gap-3 mt-4">
              <button onClick={() => { setShowCancelModal(false); setCancelReason(''); setCancelError(''); }}
                className="flex-1 border border-gray-200 text-gray-600 font-semibold py-2.5 rounded-xl hover:bg-gray-50 text-sm">
                Keep Order
              </button>
              <button onClick={handleCancel} disabled={cancelling}
                className="flex-1 bg-red-500 hover:bg-red-600 disabled:bg-red-300 text-white font-semibold py-2.5 rounded-xl text-sm flex items-center justify-center gap-2">
                {cancelling ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                {cancelling ? 'Cancelling...' : 'Cancel Order'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
