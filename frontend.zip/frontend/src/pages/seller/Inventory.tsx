import React, { useEffect, useState, useCallback } from 'react';
import { AlertTriangle, Check, X, Package, ClipboardList } from 'lucide-react';
import api from '../../services/api';

interface ProductVariant {
  id: string;
  color: string;
  size: string;
  stock: number;
  price: number;
}

interface InventoryProduct {
  id: string;
  title: string;
  stock: number;
  lowStock: number;
  category: string;
  images: { id: string; url: string }[];
  variants: ProductVariant[];
}

interface InventoryLog {
  id: string;
  productId: string;
  productTitle: string;
  change: number;
  reason: string;
  createdAt: string;
}

interface EditingState {
  productId: string;
  variantId?: string;
  value: string;
}

const Inventory: React.FC = () => {
  const [products, setProducts] = useState<InventoryProduct[]>([]);
  const [logs, setLogs] = useState<InventoryLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [logsLoading, setLogsLoading] = useState(true);
  const [editing, setEditing] = useState<EditingState | null>(null);
  const [saving, setSaving] = useState(false);

  const fetchInventory = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get('/seller/products', { params: { limit: 100 } });
      setProducts(res.data.products ?? []);
    } catch {
      setProducts([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchLogs = useCallback(async () => {
    setLogsLoading(true);
    try {
      const res = await api.get('/seller/inventory/logs');
      setLogs(res.data.logs ?? res.data ?? []);
    } catch {
      setLogs([]);
    } finally {
      setLogsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchInventory();
    fetchLogs();
  }, [fetchInventory, fetchLogs]);

  const startEditing = (productId: string, currentStock: number, variantId?: string) => {
    setEditing({ productId, variantId, value: String(currentStock) });
  };

  const cancelEditing = () => setEditing(null);

  const saveStock = async () => {
    if (!editing) return;
    const newStock = parseInt(editing.value, 10);
    if (isNaN(newStock) || newStock < 0) {
      alert('Please enter a valid stock number.');
      return;
    }
    setSaving(true);
    try {
      const payload = editing.variantId
        ? { variantId: editing.variantId, variantStock: newStock }
        : { stock: newStock };
      await api.put(`/seller/inventory/${editing.productId}`, payload);

      // Update local state
      setProducts((prev) =>
        prev.map((p) => {
          if (p.id !== editing.productId) return p;
          if (editing.variantId) {
            return {
              ...p,
              variants: p.variants.map((v) =>
                v.id === editing.variantId ? { ...v, stock: newStock } : v
              ),
            };
          }
          return { ...p, stock: newStock };
        })
      );
      setEditing(null);
      fetchLogs();
    } catch {
      alert('Failed to update stock.');
    } finally {
      setSaving(false);
    }
  };

  const isLowStock = (stock: number, threshold: number) => stock <= threshold;

  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Inventory</h1>
        <p className="text-gray-500 text-sm mt-1">
          Monitor and update your product stock levels
        </p>
      </div>

      {/* Products Stock Table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100">
          <h2 className="text-base font-semibold text-gray-800 flex items-center gap-2">
            <Package className="w-4 h-4 text-indigo-600" />
            Stock Levels
          </h2>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-48">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
          </div>
        ) : products.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-gray-400">
            <Package className="w-10 h-10 mb-2" />
            <p>No products found</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {products.map((product) => {
              const low = isLowStock(product.stock, product.lowStock);
              const isEditingBase =
                editing?.productId === product.id && !editing.variantId;

              return (
                <div key={product.id} className="px-6 py-4">
                  {/* Product Row */}
                  <div className="flex items-center gap-4">
                    {product.images?.[0]?.url ? (
                      <img
                        src={product.images[0].url}
                        alt={product.title}
                        className="w-12 h-12 rounded-lg object-cover border border-gray-200 flex-shrink-0"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center flex-shrink-0">
                        <Package className="w-5 h-5 text-gray-400" />
                      </div>
                    )}

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-semibold text-gray-800 truncate">
                          {product.title}
                        </p>
                        {low && (
                          <span className="flex items-center gap-1 text-xs text-orange-600 bg-orange-50 px-2 py-0.5 rounded-full">
                            <AlertTriangle className="w-3 h-3" />
                            Low Stock
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-500 mt-0.5">{product.category}</p>
                    </div>

                    {/* Base Stock Edit */}
                    {product.variants.length === 0 && (
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-500">Stock:</span>
                        {isEditingBase ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="0"
                              value={editing!.value}
                              onChange={(e) =>
                                setEditing((prev) =>
                                  prev ? { ...prev, value: e.target.value } : null
                                )
                              }
                              className="w-20 border border-indigo-400 rounded-lg px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              autoFocus
                            />
                            <button
                              onClick={saveStock}
                              disabled={saving}
                              className="p-1.5 bg-green-50 text-green-600 hover:bg-green-100 rounded-lg transition-colors disabled:opacity-50"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              onClick={cancelEditing}
                              className="p-1.5 bg-gray-50 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => startEditing(product.id, product.stock)}
                            className={`px-3 py-1 rounded-lg text-sm font-semibold border transition-colors hover:border-indigo-400 hover:bg-indigo-50 ${
                              low
                                ? 'text-red-600 border-red-200 bg-red-50'
                                : 'text-gray-700 border-gray-200 bg-white'
                            }`}
                          >
                            {product.stock}
                          </button>
                        )}
                        <span className="text-xs text-gray-400">/ {product.lowStock} min</span>
                      </div>
                    )}

                    {product.variants.length > 0 && (
                      <span className="text-xs text-gray-500">
                        {product.variants.length} variant{product.variants.length !== 1 ? 's' : ''}
                      </span>
                    )}
                  </div>

                  {/* Variants */}
                  {product.variants.length > 0 && (
                    <div className="mt-3 ml-16 space-y-2">
                      {product.variants.map((variant) => {
                        const variantLow = isLowStock(variant.stock, product.lowStock);
                        const isEditingVariant =
                          editing?.productId === product.id &&
                          editing.variantId === variant.id;

                        return (
                          <div
                            key={variant.id}
                            className={`flex items-center justify-between gap-3 px-3 py-2 rounded-lg border text-sm ${
                              variantLow
                                ? 'border-red-200 bg-red-50'
                                : 'border-gray-100 bg-gray-50'
                            }`}
                          >
                            <div className="flex items-center gap-3 flex-1 min-w-0">
                              <span className="text-gray-600 truncate">
                                {[variant.color, variant.size].filter(Boolean).join(' / ') ||
                                  'Default'}
                              </span>
                              <span className="text-gray-400 text-xs">
                                ₹{variant.price?.toLocaleString('en-IN')}
                              </span>
                              {variantLow && (
                                <span className="flex items-center gap-1 text-xs text-orange-600">
                                  <AlertTriangle className="w-3 h-3" />
                                  Low
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-gray-500">Stock:</span>
                              {isEditingVariant ? (
                                <div className="flex items-center gap-1">
                                  <input
                                    type="number"
                                    min="0"
                                    value={editing!.value}
                                    onChange={(e) =>
                                      setEditing((prev) =>
                                        prev ? { ...prev, value: e.target.value } : null
                                      )
                                    }
                                    className="w-20 border border-indigo-400 rounded-lg px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                    autoFocus
                                  />
                                  <button
                                    onClick={saveStock}
                                    disabled={saving}
                                    className="p-1.5 bg-green-50 text-green-600 hover:bg-green-100 rounded-lg transition-colors disabled:opacity-50"
                                  >
                                    <Check className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={cancelEditing}
                                    className="p-1.5 bg-gray-50 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                </div>
                              ) : (
                                <button
                                  onClick={() =>
                                    startEditing(product.id, variant.stock, variant.id)
                                  }
                                  className={`px-3 py-1 rounded-lg text-sm font-semibold border transition-colors hover:border-indigo-400 hover:bg-indigo-50 ${
                                    variantLow
                                      ? 'text-red-600 border-red-200 bg-white'
                                      : 'text-gray-700 border-gray-200 bg-white'
                                  }`}
                                >
                                  {variant.stock}
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Inventory Logs */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100">
          <h2 className="text-base font-semibold text-gray-800 flex items-center gap-2">
            <ClipboardList className="w-4 h-4 text-indigo-600" />
            Inventory Logs
          </h2>
        </div>

        {logsLoading ? (
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-indigo-600" />
          </div>
        ) : logs.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-gray-400">
            <ClipboardList className="w-8 h-8 mb-2" />
            <p className="text-sm">No inventory logs yet</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 text-gray-500 text-xs uppercase border-b border-gray-100">
                  <th className="px-6 py-3 text-left">Product</th>
                  <th className="px-6 py-3 text-left">Change</th>
                  <th className="px-6 py-3 text-left">Reason</th>
                  <th className="px-6 py-3 text-left">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {logs.map((log) => (
                  <tr key={log.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-3 text-gray-700">{log.productTitle}</td>
                    <td className="px-6 py-3">
                      <span
                        className={`font-semibold ${
                          log.change > 0 ? 'text-green-600' : 'text-red-600'
                        }`}
                      >
                        {log.change > 0 ? `+${log.change}` : log.change}
                      </span>
                    </td>
                    <td className="px-6 py-3 text-gray-500 capitalize">{log.reason || '—'}</td>
                    <td className="px-6 py-3 text-gray-500 text-xs">
                      {new Date(log.createdAt).toLocaleString('en-IN')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Inventory;
