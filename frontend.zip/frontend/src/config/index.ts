const rawApiUrl = (import.meta.env.VITE_API_URL as string | undefined)?.trim();
const rawRollbarToken = (import.meta.env.VITE_ROLLBAR_TOKEN as string | undefined)?.trim();

export const API_URL = rawApiUrl || 'http://localhost:5000';
export const SOCKET_URL = API_URL;
export const API_BASE_URL = rawApiUrl ? `${rawApiUrl}/api` : '/api';

export const ROLLBAR_TOKEN =
  rawRollbarToken && rawRollbarToken !== 'undefined' && rawRollbarToken !== 'your_rollbar_client_token_here'
    ? rawRollbarToken
    : undefined;

export const APP_MODE = import.meta.env.MODE ?? 'development';
export const IS_DEV = import.meta.env.DEV;
