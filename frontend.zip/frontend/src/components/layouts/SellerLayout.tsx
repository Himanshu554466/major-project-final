import React, { useState, useEffect, useRef } from 'react';
import { Outlet, NavLink, useNavigate, Link } from 'react-router-dom';
import {
  LayoutDashboard, Package, ShoppingBag,
  Warehouse, User, LogOut, Menu, Store, Bell, X,
  AlertTriangle, ShoppingCart, Truck, RotateCcw,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const NAV = [
  { to: '/seller/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/seller/products',  icon: Package,         label: 'Products' },
  { to: '/seller/orders',    icon: ShoppingBag,     label: 'Orders' },
  { to: '/seller/refunds',   icon: RotateCcw,       label: 'Refunds' },
  { to: '/seller/inventory', icon: Warehouse,       label: 'Inventory' },
  { to: '/seller/profile',   icon: User,            label: 'Profile' },
];

interface Notification {
  id: string;
  type: 'new_order' | 'low_stock' | 'delivery_update';
  title: string;
  message: string;
  orderId?: number;
  productId?: string;
  time: string;
  read: boolean;
}

// ── Notification Bell ────────────────────────────────────────────────────────
const SEEN_KEY   = 'seller_notif_seen';    // comma-separated seen IDs
const CLEAR_KEY  = 'seller_notif_cleared'; // comma-separated cleared IDs

function loadSet(key: string): Set<string> {
  try {
    const raw = localStorage.getItem(key);
    return raw ? new Set(raw.split(',').filter(Boolean)) : new Set();
  } catch { return new Set(); }
}

function saveSet(key: string, set: Set<string>) {
  try {
    // Keep only last 200 IDs to avoid unbounded growth
    const arr = Array.from(set).slice(-200);
    localStorage.setItem(key, arr.join(','));
  } catch {}
}

function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unread, setUnread] = useState(0);
  const [loading, setLoading] = useState(false);
  // Persist seen + cleared IDs across reloads
  const [seenIds, setSeenIds] = useState<Set<string>>(() => loadSet(SEEN_KEY));
  const [clearedIds, setClearedIds] = useState<Set<string>>(() => loadSet(CLEAR_KEY));
  const ref = useRef<HTMLDivElement>(null);

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const res = await api.get('/seller/notifications');
      const all: Notification[] = res.data.notifications || [];
      // Hide notifications that were explicitly cleared
      const visible = all.filter(n => !clearedIds.has(n.id));
      setNotifications(visible);
      // Unread = visible but not yet seen
      setUnread(visible.filter(n => !seenIds.has(n.id)).length);
    } catch { /* ignore */ }
    finally { setLoading(false); }
  };

  const markAllSeen = () => {
    const newSeen = new Set([...seenIds, ...notifications.map(n => n.id)]);
    setSeenIds(newSeen);
    saveSet(SEEN_KEY, newSeen);
    setUnread(0);
  };

  const clearAll = () => {
    // Add all current notification IDs to cleared set — they won't show again
    const newCleared = new Set([...clearedIds, ...notifications.map(n => n.id)]);
    setClearedIds(newCleared);
    saveSet(CLEAR_KEY, newCleared);
    // Also mark all as seen
    const newSeen = new Set([...seenIds, ...notifications.map(n => n.id)]);
    setSeenIds(newSeen);
    saveSet(SEEN_KEY, newSeen);
    setNotifications([]);
    setUnread(0);
    setOpen(false);
  };

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000);
    return () => clearInterval(interval);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clearedIds]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const getIcon = (type: string) => {
    if (type === 'new_order') return <ShoppingCart className="w-4 h-4 text-blue-500" />;
    if (type === 'low_stock') return <AlertTriangle className="w-4 h-4 text-orange-500" />;
    return <Truck className="w-4 h-4 text-green-500" />;
  };

  const formatTime = (iso: string) => {
    const diff = Date.now() - new Date(iso).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  };

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => { setOpen(!open); if (!open) fetchNotifications(); }}
        className="relative p-2 rounded-xl text-indigo-200 hover:bg-indigo-800 hover:text-white transition-colors">
        <Bell size={18} />
        {unread > 0 && (
          <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1">
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-80 bg-white border border-gray-200 rounded-xl shadow-2xl z-50 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100 bg-gray-50">
            <h3 className="text-sm font-bold text-gray-800">Notifications</h3>
            <div className="flex items-center gap-2">
              {notifications.length > 0 && (
                <>
                  <button onClick={markAllSeen} className="text-xs text-indigo-600 hover:underline">
                    Mark all seen
                  </button>
                  <span className="text-gray-300">|</span>
                  <button onClick={clearAll} className="text-xs text-red-500 hover:underline">
                    Clear all
                  </button>
                  <span className="text-gray-300">|</span>
                </>
              )}
              <button onClick={fetchNotifications} className="text-xs text-indigo-600 hover:underline">
                {loading ? 'Refreshing...' : 'Refresh'}
              </button>
              <button onClick={() => setOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X size={14} />
              </button>
            </div>
          </div>

          <div className="max-h-80 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="px-4 py-8 text-center text-gray-400">
                <Bell className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm">No notifications</p>
              </div>
            ) : (
              notifications.map(n => (
                <div key={n.id} className="px-4 py-3 border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5 shrink-0">{getIcon(n.type)}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-gray-800">{n.title}</p>
                      <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{n.message}</p>
                      <p className="text-[10px] text-gray-400 mt-1">{formatTime(n.time)}</p>
                    </div>
                    {n.orderId && (
                      <Link to="/seller/orders" onClick={() => setOpen(false)}
                        className="text-[10px] text-indigo-600 hover:underline shrink-0 mt-0.5">
                        View
                      </Link>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="px-4 py-2.5 border-t border-gray-100 bg-gray-50">
            <Link to="/seller/orders" onClick={() => setOpen(false)}
              className="text-xs text-indigo-600 hover:underline font-medium">
              View all orders →
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Layout ───────────────────────────────────────────────────────────────────
const SellerLayout: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [pendingRefunds, setPendingRefunds] = useState(0);

  // Poll for pending refunds count
  useEffect(() => {
    const fetchRefundCount = () => {
      api.get('/seller/orders?status=returned&limit=1')
        .then(res => setPendingRefunds(res.data.total || 0))
        .catch(() => {});
    };
    fetchRefundCount();
    const interval = setInterval(fetchRefundCount, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => { logout(); navigate('/seller/login'); };

  const Sidebar = ({ mobile = false }: { mobile?: boolean }) => (
    <div className={`flex flex-col h-full bg-indigo-900 text-white ${mobile ? 'w-64' : 'w-64'}`}>
      <div className="flex items-center gap-3 px-6 py-5 border-b border-indigo-700">
        <div className="w-9 h-9 bg-orange-500 rounded-xl flex items-center justify-center">
          <Store size={18} className="text-white" />
        </div>
        <div>
          <p className="font-bold text-sm">Ecommerce</p>
          <p className="text-indigo-300 text-xs">Seller Portal</p>
        </div>
      </div>
      <div className="px-4 py-3 border-b border-indigo-700">
        <p className="text-xs text-indigo-400">Logged in as</p>
        <p className="text-sm font-semibold truncate">{user?.shopName || user?.email}</p>
      </div>
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {NAV.map(({ to, icon: Icon, label }) => (
          <NavLink key={to} to={to} onClick={() => setOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                isActive ? 'bg-indigo-700 text-white' : 'text-indigo-200 hover:bg-indigo-800 hover:text-white'
              }`
            }>
            <Icon size={18} />
            {label}
            {to === '/seller/refunds' && pendingRefunds > 0 && (
              <span className="ml-auto min-w-[18px] h-[18px] bg-yellow-400 text-gray-900 text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                {pendingRefunds}
              </span>
            )}
          </NavLink>
        ))}
      </nav>
      <div className="px-3 py-4 border-t border-indigo-700">
        <button onClick={handleLogout}
          className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm text-indigo-200 hover:bg-indigo-800 hover:text-white transition-colors">
          <LogOut size={18} />
          Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-100 overflow-hidden">
      {/* Desktop sidebar */}
      <div className="hidden md:flex flex-shrink-0"><Sidebar /></div>

      {/* Mobile sidebar overlay */}
      {open && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div className="flex-shrink-0"><Sidebar mobile /></div>
          <div className="flex-1 bg-black/50" onClick={() => setOpen(false)} />
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar with notification bell */}
        <div className="flex items-center justify-between px-4 py-3 bg-indigo-900 text-white md:bg-white md:border-b md:border-gray-200 md:text-gray-800">
          <button onClick={() => setOpen(true)} className="md:hidden"><Menu size={22} /></button>
          <span className="font-bold text-sm md:hidden">Seller Portal</span>
          <div className="hidden md:flex items-center gap-2 text-sm text-gray-500">
            <span>Welcome, <strong className="text-gray-800">{user?.shopName || user?.username}</strong></span>
          </div>
          {/* Notification bell — visible on both mobile and desktop */}
          <div className="flex items-center gap-2">
            <NotificationBell />
          </div>
        </div>
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default SellerLayout;
