import React, { useEffect, useState, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Search, Plus, Edit2, ChevronLeft, ChevronRight,
  Package, Eye, EyeOff, RefreshCw, Clock, CheckCircle, XCircle,
  AlertCircle, Trash2, X, Tag, Truck, IndianRupee,
} from 'lucide-react';
import api from '../../services/api';

const CATEGORIES = [
  'Electronics', 'Fashion', 'Home & Kitchen', 'Sports & Outdoors', 'Books',
  'Groceries', 'Beauty & Personal Care', 'Toys & Games', 'Automotive',
  'Health & Wellness', 'Furniture', 'Appliances', 'Jewelry', 'Pet Supplies',
  'Office Supplies', 'Garden & Outdoor', 'Baby & Kids', 'Music & Instruments',
  'Art & Crafts', 'Mobile & Tablets', 'Computers & Laptops', 'Cameras & Photography',
  'Watches', 'Footwear', 'Bags & Luggage', 'Stationery', 'Gaming',
  'Fitness Equipment', 'Home Decor', 'Kitchen Appliances',
];

interface ProductImage { id: string; url: string; }
interface ProductVariant { id: string; price: number; color: string; size: string; stock: number; }
interface ProductTag { id: string; name: string; }

interface Product {
  id: string;
  title: string;
  description?: string;
  category: string;
  brand: string;
  stock: number;
  lowStock?: number;
  deliveryCharge?: number;
  freeDeliveryAbove?: number;
  metaTitle?: string;
  metaDescription?: string;
  status: string;
  approvalStatus: string;
  rejectionReason?: string;
  isActive: boolean;
  isVisible: boolean;
  createdAt: string;
  variants: ProductVariant[];
  images: ProductImage[];
  tags?: ProductTag[];
}

interface ProductsResponse {
  products: Product[];
  total: number;
  page: number;
  pages: number;
}

// ── Badge helpers ────────────────────────────────────────────────────────────

const APPROVAL_BADGE: Record<string, string> = {
  approved: 'bg-green-100 text-green-700',
  pending:  'bg-yellow-100 text-yellow-700',
  rejected: 'bg-red-100 text-red-700',
};

const APPROVAL_ICON: Record<string, React.ReactNode> = {
  approved: <CheckCircle className="w-3.5 h-3.5" />,
  pending:  <Clock className="w-3.5 h-3.5" />,
  rejected: <XCircle className="w-3.5 h-3.5" />,
};

// ── Product Detail Modal ─────────────────────────────────────────────────────
function ProductDetailModal({ product, onClose, onEdit }: { product: Product; onClose: () => void; onEdit: () => void }) {
  const [imgIdx, setImgIdx] = useState(0);

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <h2 className="text-lg font-bold text-gray-900 truncate pr-4">{product.title}</h2>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-gray-100 text-gray-500 flex-shrink-0">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Images */}
          <div>
            <div className="w-full aspect-square bg-gray-50 rounded-xl overflow-hidden border border-gray-200 mb-3">
              {product.images?.length > 0 ? (
                <img src={product.images[imgIdx]?.url} alt={product.title}
                  className="w-full h-full object-contain" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="w-16 h-16 text-gray-200" />
                </div>
              )}
            </div>
            {product.images?.length > 1 && (
              <div className="flex gap-2 flex-wrap">
                {product.images.map((img, i) => (
                  <button key={img.id} onClick={() => setImgIdx(i)}
                    className={`w-14 h-14 rounded-lg overflow-hidden border-2 transition-colors ${i === imgIdx ? 'border-indigo-500' : 'border-gray-200'}`}>
                    <img src={img.url} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details */}
          <div className="space-y-4">
            {/* Status badges */}
            <div className="flex flex-wrap gap-2">
              <span className={`text-xs px-2.5 py-1 rounded-full font-medium capitalize ${
                product.approvalStatus === 'approved' ? 'bg-green-100 text-green-700' :
                product.approvalStatus === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                'bg-red-100 text-red-700'
              }`}>{product.approvalStatus}</span>
              <span className={`text-xs px-2.5 py-1 rounded-full font-medium capitalize ${
                product.status === 'published' ? 'bg-green-100 text-green-700' :
                product.status === 'archived' ? 'bg-red-100 text-red-700' :
                'bg-gray-100 text-gray-600'
              }`}>{product.status}</span>
            </div>

            {/* Basic info */}
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Category</span>
                <span className="font-medium text-gray-800">{product.category || '—'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Brand</span>
                <span className="font-medium text-gray-800">{product.brand || '—'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Base Stock</span>
                <span className={`font-medium ${product.stock <= (product.lowStock ?? 5) ? 'text-red-600' : 'text-gray-800'}`}>
                  {product.stock} units {product.stock <= (product.lowStock ?? 5) ? '⚠️ Low' : ''}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Low Stock Alert</span>
                <span className="font-medium text-gray-800">{product.lowStock ?? 5} units</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500 flex items-center gap-1"><Truck className="w-3.5 h-3.5" /> Delivery Charge</span>
                <span className="font-medium text-gray-800">
                  {product.deliveryCharge ? `₹${product.deliveryCharge}` : 'FREE'}
                  {product.freeDeliveryAbove ? ` (free above ₹${product.freeDeliveryAbove})` : ''}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Added On</span>
                <span className="font-medium text-gray-800">
                  {new Date(product.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                </span>
              </div>
            </div>

            {/* Description */}
            {product.description && (
              <div>
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Description</p>
                <p className="text-sm text-gray-700 leading-relaxed">{product.description}</p>
              </div>
            )}

            {/* Tags */}
            {product.tags && product.tags.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5" /> Tags
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {product.tags.map(t => (
                    <span key={t.id} className="text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full">{t.name}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Variants */}
        {product.variants?.length > 0 && (
          <div className="px-6 pb-4">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Variants ({product.variants.length})
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-sm border border-gray-100 rounded-xl overflow-hidden">
                <thead>
                  <tr className="bg-gray-50 text-xs text-gray-500 uppercase">
                    <th className="px-3 py-2 text-left">Color</th>
                    <th className="px-3 py-2 text-left">Size</th>
                    <th className="px-3 py-2 text-right">Price</th>
                    <th className="px-3 py-2 text-right">Stock</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {product.variants.map(v => (
                    <tr key={v.id} className="hover:bg-gray-50">
                      <td className="px-3 py-2 text-gray-700">{v.color || '—'}</td>
                      <td className="px-3 py-2 text-gray-700">{v.size || '—'}</td>
                      <td className="px-3 py-2 text-right font-semibold text-gray-900">
                        <span className="flex items-center justify-end gap-0.5">
                          <IndianRupee className="w-3 h-3" />{v.price?.toLocaleString('en-IN')}
                        </span>
                      </td>
                      <td className={`px-3 py-2 text-right font-medium ${v.stock <= (product.lowStock ?? 5) ? 'text-red-600' : 'text-gray-700'}`}>
                        {v.stock}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Rejection reason */}
        {product.approvalStatus === 'rejected' && product.rejectionReason && (
          <div className="mx-6 mb-4 p-3 bg-red-50 border border-red-200 rounded-xl">
            <p className="text-xs font-semibold text-red-700 mb-1">Rejection Reason</p>
            <p className="text-sm text-red-600">{product.rejectionReason}</p>
          </div>
        )}

        {/* Footer actions */}
        <div className="flex gap-3 px-6 py-4 border-t border-gray-100 bg-gray-50 rounded-b-2xl">
          <button onClick={onEdit}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-xl transition-colors">
            <Edit2 className="w-4 h-4" /> Edit Product
          </button>
          <button onClick={onClose}
            className="px-4 py-2 border border-gray-200 text-gray-600 text-sm rounded-xl hover:bg-gray-100 transition-colors">
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Component ────────────────────────────────────────────────────────────────

const Products: React.FC = () => {
  const navigate = useNavigate();
  const [products, setProducts]   = useState<Product[]>([]);
  const [total, setTotal]         = useState(0);
  const [pages, setPages]         = useState(1);
  const [page, setPage]           = useState(1);
  const [search, setSearch]       = useState('');
  const [status, setStatus]       = useState('');
  const [category, setCategory]   = useState('');
  const [loading, setLoading]     = useState(true);
  const [actionId, setActionId]   = useState<string | null>(null);
  const [toast, setToast]         = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [detailProduct, setDetailProduct] = useState<Product | null>(null);

  const limit = 10;

  const showToast = (type: 'success' | 'error', msg: string) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 3500);
  };

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params: Record<string, string | number> = { page, limit };
      if (search)   params.search   = search;
      if (status)   params.status   = status;
      if (category) params.category = category;
      const res = await api.get<ProductsResponse>('/seller/products', { params });
      setProducts(res.data.products ?? []);
      setTotal(res.data.total ?? 0);
      setPages(res.data.pages ?? 1);
    } catch {
      setProducts([]);
    } finally {
      setLoading(false);
    }
  }, [page, search, status, category]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  // Toggle published ↔ draft (only for approved products)
  const handleToggleVisibility = async (product: Product) => {
    setActionId(product.id);
    try {
      const res = await api.put(`/seller/products/${product.id}/visibility`);
      showToast('success', res.data.message);
      fetchProducts();
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message
        || 'Failed to update visibility.';
      showToast('error', msg);
    } finally {
      setActionId(null);
    }
  };

  // Resubmit rejected product for admin review
  const handleResubmit = async (product: Product) => {
    setActionId(product.id);
    try {
      const res = await api.put(`/seller/products/${product.id}/resubmit`);
      showToast('success', res.data.message);
      fetchProducts();
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message
        || 'Failed to resubmit.';
      showToast('error', msg);
    } finally {
      setActionId(null);
    }
  };

  // Permanent delete
  const handleDelete = async (product: Product) => {
    if (!window.confirm(`⚠️ PERMANENTLY DELETE "${product.title}"?\n\nThis cannot be undone. All images, variants and data will be lost.`)) return;
    setActionId(product.id);
    try {
      await api.delete(`/seller/products/${product.id}?permanent=true`);
      showToast('success', 'Product permanently deleted.');
      fetchProducts();
    } catch {
      showToast('error', 'Failed to delete product.');
    } finally {
      setActionId(null);
    }
  };

  return (
    <div className="p-6 space-y-6">

      {/* Product Detail Modal */}
      {detailProduct && (
        <ProductDetailModal
          product={detailProduct}
          onClose={() => setDetailProduct(null)}
          onEdit={() => { setDetailProduct(null); navigate(`/seller/products/${detailProduct.id}/edit`); }}
        />
      )}

      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-sm font-medium transition-all ${
          toast.type === 'success'
            ? 'bg-green-600 text-white'
            : 'bg-red-600 text-white'
        }`}>
          {toast.type === 'success'
            ? <CheckCircle className="w-4 h-4" />
            : <AlertCircle className="w-4 h-4" />}
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Products</h1>
          <p className="text-gray-500 text-sm mt-1">{total} products total</p>
        </div>
        <Link
          to="/seller/products/new"
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2.5 rounded-xl text-sm font-medium transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add New Product
        </Link>
      </div>

      {/* How publishing works — info banner */}
      <div className="bg-indigo-50 border border-indigo-200 rounded-xl px-4 py-3 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-indigo-500 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-indigo-800">
          <strong>How publishing works:</strong> After you add a product, it goes to admin for review.
          Once <span className="font-semibold text-green-700">Approved</span>, you can toggle it
          <span className="font-semibold"> Live / Hidden</span> anytime.
          <span className="text-red-700 font-semibold"> Rejected</span> products can be edited and resubmitted.
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4">
        <form
          onSubmit={(e) => { e.preventDefault(); setPage(1); fetchProducts(); }}
          className="flex flex-wrap gap-3"
        >
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search products..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
          <select
            value={status}
            onChange={(e) => { setStatus(e.target.value); setPage(1); }}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Statuses</option>
            <option value="pending">Pending Review</option>
            <option value="published">Published (Live)</option>
            <option value="draft">Draft (Hidden)</option>
            <option value="archived">Archived</option>
          </select>
          <select
            value={category}
            onChange={(e) => { setCategory(e.target.value); setPage(1); }}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Categories</option>
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <button
            type="submit"
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
          >
            Search
          </button>
        </form>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
          </div>
        ) : products.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-gray-400">
            <Package className="w-10 h-10 mb-2" />
            <p className="font-medium">No products found</p>
            <Link to="/seller/products/new" className="mt-3 text-sm text-indigo-600 hover:underline">
              + Add your first product
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 text-gray-500 text-xs uppercase border-b border-gray-100">
                  <th className="px-4 py-3 text-left">Product</th>
                  <th className="px-4 py-3 text-left">Category</th>
                  <th className="px-4 py-3 text-left">Variants</th>
                  <th className="px-4 py-3 text-left">Stock</th>
                  <th className="px-4 py-3 text-left">Approval</th>
                  <th className="px-4 py-3 text-left">Visibility</th>
                  <th className="px-4 py-3 text-left">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {products.map((product) => {
                  const isApproved  = product.approvalStatus === 'approved';
                  const isRejected  = product.approvalStatus === 'rejected';
                  const isPending   = product.approvalStatus === 'pending';
                  const isPublished = product.status === 'published';
                  const busy        = actionId === product.id;

                  return (
                    <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                      {/* Product */}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setDetailProduct(product)}>
                          {product.images?.[0]?.url ? (
                            <img
                              src={product.images[0].url}
                              alt={product.title}
                              className="w-10 h-10 rounded-lg object-cover border border-gray-200 flex-shrink-0"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded-lg bg-gray-100 flex items-center justify-center flex-shrink-0">
                              <Package className="w-5 h-5 text-gray-400" />
                            </div>
                          )}
                          <div className="min-w-0">
                            <p className="font-medium text-indigo-700 hover:text-indigo-900 truncate max-w-[160px] cursor-pointer">{product.title}</p>
                            <p className="text-xs text-gray-400">{product.brand || '—'}</p>
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="px-4 py-3 text-gray-600 text-xs">{product.category || '—'}</td>

                      {/* Variants */}
                      <td className="px-4 py-3 text-gray-600">{product.variants?.length ?? 0}</td>

                      {/* Stock */}
                      <td className="px-4 py-3 text-gray-600">{product.stock}</td>

                      {/* Approval status */}
                      <td className="px-4 py-3">
                        <div className="space-y-1">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium capitalize ${
                            APPROVAL_BADGE[product.approvalStatus] ?? 'bg-gray-100 text-gray-600'
                          }`}>
                            {APPROVAL_ICON[product.approvalStatus]}
                            {product.approvalStatus}
                          </span>
                          {isRejected && product.rejectionReason && (
                            <p className="text-xs text-red-500 max-w-[160px] truncate" title={product.rejectionReason}>
                              ↳ {product.rejectionReason}
                            </p>
                          )}
                          {isPending && (
                            <p className="text-xs text-yellow-600">Awaiting admin review</p>
                          )}
                        </div>
                      </td>

                      {/* Visibility / publish toggle */}
                      <td className="px-4 py-3">
                        {isApproved ? (
                          <button
                            onClick={() => handleToggleVisibility(product)}
                            disabled={busy}
                            title={
                              product.status === 'archived' 
                                ? 'Click to unarchive and make live' 
                                : isPublished 
                                ? 'Click to hide from store' 
                                : 'Click to make live'
                            }
                            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors disabled:opacity-50 ${
                              product.status === 'archived'
                                ? 'bg-red-100 text-red-700 hover:bg-red-200'
                                : isPublished
                                ? 'bg-green-100 text-green-700 hover:bg-green-200'
                                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                            }`}
                          >
                            {busy ? (
                              <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                            ) : product.status === 'archived' ? (
                              <EyeOff className="w-3.5 h-3.5" />
                            ) : isPublished ? (
                              <Eye className="w-3.5 h-3.5" />
                            ) : (
                              <EyeOff className="w-3.5 h-3.5" />
                            )}
                            {product.status === 'archived' ? 'Archived' : isPublished ? 'Live' : 'Hidden'}
                          </button>
                        ) : (
                          <span className="text-xs text-gray-400 italic">
                            {isPending ? 'Pending approval' : 'Not approved'}
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          {/* Edit */}
                          <button
                            onClick={() => navigate(`/seller/products/${product.id}/edit`)}
                            className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                            title="Edit product"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          {/* Resubmit (rejected only) */}
                          {isRejected && (
                            <button
                              onClick={() => handleResubmit(product)}
                              disabled={busy}
                              className="p-1.5 text-orange-500 hover:bg-orange-50 rounded-lg transition-colors disabled:opacity-50"
                              title="Resubmit for review"
                            >
                              {busy
                                ? <div className="w-4 h-4 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
                                : <RefreshCw className="w-4 h-4" />
                              }
                            </button>
                          )}

                          {/* Permanent Delete */}
                          <button
                            onClick={() => handleDelete(product)}
                            disabled={busy}
                            className="p-1.5 text-red-700 hover:bg-red-100 rounded-lg transition-colors disabled:opacity-50"
                            title="Permanently delete product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {pages > 1 && (
          <div className="flex items-center justify-between px-6 py-4 border-t border-gray-100">
            <p className="text-sm text-gray-500">Page {page} of {pages} ({total} total)</p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-40 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setPage((p) => Math.min(pages, p + 1))}
                disabled={page === pages}
                className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-40 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Products;
