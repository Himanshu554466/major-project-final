import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Plus, Trash2, ChevronRight, ChevronLeft, Upload, X, Tag } from 'lucide-react';
import api from '../../services/api';

const CATEGORIES = [
  'Electronics', 'Fashion', 'Home & Kitchen', 'Sports & Outdoors', 'Books',
  'Groceries', 'Beauty & Personal Care', 'Toys & Games', 'Automotive',
  'Health & Wellness', 'Furniture', 'Appliances', 'Jewelry', 'Pet Supplies',
  'Office Supplies', 'Garden & Outdoor', 'Baby & Kids', 'Music & Instruments',
  'Art & Crafts', 'Mobile & Tablets', 'Computers & Laptops', 'Cameras & Photography',
  'Watches', 'Footwear', 'Bags & Luggage', 'Stationery', 'Gaming',
  'Fitness Equipment', 'Home Decor', 'Kitchen Appliances',
];

const BRANDS_BY_CATEGORY: Record<string, string[]> = {
  Electronics: ['Apple', 'Samsung', 'Sony', 'LG', 'OnePlus', 'Xiaomi', 'Boat', 'JBL'],
  Fashion: ['Nike', 'Adidas', 'Puma', "Levi's", 'H&M', 'Zara', 'Allen Solly', 'Peter England'],
  'Home & Kitchen': ['Prestige', 'Philips', 'Bajaj', 'Havells', 'Pigeon', 'Butterfly'],
  'Sports & Outdoors': ['Nike', 'Adidas', 'Puma', 'Decathlon', 'Cosco', 'Nivia'],
  Books: ['Penguin', 'HarperCollins', 'Scholastic', 'Oxford'],
};

interface ExistingImage {
  id: string;
  url: string;
}

interface ExistingVariant {
  id: string;
  price: number;
  color: string;
  size: string;
  stock: number;
}

interface ExistingTag {
  id: string;
  name: string;
}

interface ProductDetail {
  id: string;
  title: string;
  description: string;
  category: string;
  brand: string;
  stock: number;
  lowStock: number;
  deliveryCharge: number;
  freeDeliveryAbove: number;
  status: string;
  approvalStatus: string;
  variants: ExistingVariant[];
  images: ExistingImage[];
  tags: ExistingTag[];
}

interface Variant {
  id?: string;
  color: string;
  size: string;
  price: string;
  stock: string;
}

interface FormData {
  title: string;
  description: string;
  category: string;
  brand: string;
  stock: string;
  lowStock: string;
  deliveryCharge: string;
  freeDeliveryAbove: string;
  tags: string;
}

const EditProduct: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [deletingImageId, setDeletingImageId] = useState<string | null>(null);

  const [form, setForm] = useState<FormData>({
    title: '',
    description: '',
    category: '',
    brand: '',
    stock: '',
    lowStock: '',
    deliveryCharge: '',
    freeDeliveryAbove: '',
    tags: '',
  });

  const [variants, setVariants] = useState<Variant[]>([]);
  const [existingImages, setExistingImages] = useState<ExistingImage[]>([]);
  const [newImages, setNewImages] = useState<File[]>([]);
  const [newImagePreviews, setNewImagePreviews] = useState<string[]>([]);

  const brandSuggestions = form.category
    ? BRANDS_BY_CATEGORY[form.category] ?? ['Generic', 'Other']
    : [];

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await api.get<{ product: ProductDetail } | ProductDetail>(`/seller/products/${id}`);
        const p = (res.data as { product: ProductDetail }).product ?? (res.data as ProductDetail);
        setForm({
          title: p.title,
          description: p.description,
          category: p.category,
          brand: p.brand,
          stock: String(p.stock),
          lowStock: String(p.lowStock),
          deliveryCharge: String(p.deliveryCharge),
          freeDeliveryAbove: String(p.freeDeliveryAbove),
          tags: p.tags?.map((t) => t.name).join(', ') ?? '',
        });
        setVariants(
          p.variants?.map((v) => ({
            id: v.id,
            color: v.color,
            size: v.size,
            price: String(v.price),
            stock: String(v.stock),
          })) ?? [{ color: '', size: '', price: '', stock: '' }]
        );
        setExistingImages(p.images ?? []);
      } catch {
        setError('Failed to load product details.');
      } finally {
        setLoading(false);
      }
    };
    if (id) fetchProduct();
  }, [id]);

  const handleFormChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleVariantChange = (index: number, field: keyof Omit<Variant, 'id'>, value: string) => {
    setVariants((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const addVariant = () =>
    setVariants((prev) => [...prev, { color: '', size: '', price: '', stock: '' }]);

  const removeVariant = (index: number) =>
    setVariants((prev) => prev.filter((_, i) => i !== index));

  const handleNewImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    setNewImages((prev) => [...prev, ...files]);
    const previews = files.map((f) => URL.createObjectURL(f));
    setNewImagePreviews((prev) => [...prev, ...previews]);
  };

  const removeNewImage = (index: number) => {
    setNewImages((prev) => prev.filter((_, i) => i !== index));
    setNewImagePreviews((prev) => {
      URL.revokeObjectURL(prev[index]);
      return prev.filter((_, i) => i !== index);
    });
  };

  const handleDeleteExistingImage = async (imageId: string) => {
    if (!window.confirm('Delete this image?')) return;
    setDeletingImageId(imageId);
    try {
      await api.delete(`/seller/products/${id}/images/${imageId}`);
      setExistingImages((prev) => prev.filter((img) => img.id !== imageId));
    } catch {
      alert('Failed to delete image.');
    } finally {
      setDeletingImageId(null);
    }
  };

  const validateStep = (): boolean => {
    if (step === 1) {
      if (!form.title.trim()) { setError('Product title is required.'); return false; }
      if (!form.category) { setError('Please select a category.'); return false; }
    }
    if (step === 2) {
      for (const v of variants) {
        if (!v.price) { setError('All variants must have a price.'); return false; }
      }
    }
    setError('');
    return true;
  };

  const handleNext = () => {
    if (validateStep()) setStep((s) => s + 1);
  };

  const handleBack = () => {
    setError('');
    setStep((s) => s - 1);
  };

  // Only called on step 3 via the Submit button
  const handleSubmit = async () => {
    setError('');
    setSubmitting(true);

    try {
      const fd = new FormData();
      fd.append('title', form.title);
      fd.append('description', form.description);
      fd.append('category', form.category);
      fd.append('brand', form.brand);
      fd.append('stock', form.stock || '0');
      fd.append('lowStock', form.lowStock || '0');
      fd.append('deliveryCharge', form.deliveryCharge || '0');
      fd.append('freeDeliveryAbove', form.freeDeliveryAbove || '0');

      const tagsArray = form.tags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);
      fd.append('tags', JSON.stringify(tagsArray));

      const validVariants = variants.filter((v) => v.price);
      fd.append('variants', JSON.stringify(validVariants));

      newImages.forEach((img) => fd.append('images', img));

      await api.put(`/seller/products/${id}`, fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      navigate('/seller/products');
    } catch (err: unknown) {
      const msg =
        (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
      setError(msg || 'Failed to update product. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const steps = ['Basic Info', 'Variants & Pricing', 'Images & Details'];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600" />
      </div>
    );
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Edit Product</h1>
        <p className="text-gray-500 text-sm mt-1">Update your product details</p>
      </div>

      {/* Step Indicator */}
      <div className="flex items-center mb-8">
        {steps.map((label, i) => {
          const num = i + 1;
          const active = step === num;
          const done = step > num;
          return (
            <React.Fragment key={label}>
              <div className="flex items-center gap-2">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${
                    done
                      ? 'bg-indigo-600 text-white'
                      : active
                      ? 'bg-indigo-600 text-white ring-4 ring-indigo-100'
                      : 'bg-gray-200 text-gray-500'
                  }`}
                >
                  {done ? '✓' : num}
                </div>
                <span
                  className={`text-sm font-medium hidden sm:block ${
                    active ? 'text-indigo-600' : done ? 'text-gray-700' : 'text-gray-400'
                  }`}
                >
                  {label}
                </span>
              </div>
              {i < steps.length - 1 && (
                <div
                  className={`flex-1 h-0.5 mx-3 ${done ? 'bg-indigo-600' : 'bg-gray-200'}`}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>

      <div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-5">
          {/* Step 1 */}
          {step === 1 && (
            <>
              <h2 className="text-base font-semibold text-gray-800 mb-4">Basic Information</h2>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Product Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="title"
                  value={form.title}
                  onChange={handleFormChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  name="description"
                  value={form.description}
                  onChange={handleFormChange}
                  rows={4}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  name="category"
                  value={form.category}
                  onChange={handleFormChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">Select a category</option>
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Brand</label>
                {brandSuggestions.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {brandSuggestions.map((b) => (
                      <button
                        key={b}
                        type="button"
                        onClick={() => setForm((prev) => ({ ...prev, brand: b }))}
                        className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                          form.brand === b
                            ? 'bg-indigo-600 text-white border-indigo-600'
                            : 'bg-white text-gray-600 border-gray-300 hover:border-indigo-400'
                        }`}
                      >
                        {b}
                      </button>
                    ))}
                  </div>
                )}
                <input
                  type="text"
                  name="brand"
                  value={form.brand}
                  onChange={handleFormChange}
                  placeholder="Or type brand name manually"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </>
          )}

          {/* Step 2 */}
          {step === 2 && (
            <>
              <h2 className="text-base font-semibold text-gray-800 mb-4">Variants & Pricing</h2>
              <div>
                <div className="flex items-center justify-between mb-3">
                  <label className="text-sm font-medium text-gray-700">Variants</label>
                  <button
                    type="button"
                    onClick={addVariant}
                    className="flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 font-medium"
                  >
                    <Plus className="w-4 h-4" />
                    Add Variant
                  </button>
                </div>

                {/* Column Headers */}
                <div className="hidden sm:grid grid-cols-4 gap-3 px-4 pb-2 text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  <div>Color</div>
                  <div>Size</div>
                  <div>Price (₹)</div>
                  <div>Stock</div>
                </div>

                <div className="space-y-3">
                  {variants.map((variant, index) => (
                    <div
                      key={index}
                      className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-gray-50 rounded-lg border border-gray-200"
                    >
                      <div>
                        <label className="block sm:hidden text-xs font-medium text-gray-600 mb-1">Color</label>
                        <input
                          type="text"
                          placeholder="e.g. Red, Blue"
                          value={variant.color}
                          onChange={(e) => handleVariantChange(index, 'color', e.target.value)}
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block sm:hidden text-xs font-medium text-gray-600 mb-1">Size</label>
                        <input
                          type="text"
                          placeholder="e.g. M, L, XL"
                          value={variant.size}
                          onChange={(e) => handleVariantChange(index, 'size', e.target.value)}
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                      <div>
                        <label className="block sm:hidden text-xs font-medium text-gray-600 mb-1">Price (₹)</label>
                        <input
                          type="number"
                          placeholder="0"
                          value={variant.price}
                          onChange={(e) => handleVariantChange(index, 'price', e.target.value)}
                          min="0"
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                      </div>
                      <div className="flex gap-2">
                        <div className="flex-1">
                          <label className="block sm:hidden text-xs font-medium text-gray-600 mb-1">Stock</label>
                          <input
                            type="number"
                            placeholder="0"
                            value={variant.stock}
                            onChange={(e) => handleVariantChange(index, 'stock', e.target.value)}
                            min="0"
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          />
                        </div>
                        {variants.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeVariant(index)}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors self-end"
                            title="Remove variant"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Step 3 */}
          {step === 3 && (
            <>
              <h2 className="text-base font-semibold text-gray-800 mb-4">Images & Details</h2>

              {/* Existing Images */}
              {existingImages.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Current Images
                  </label>
                  <div className="flex flex-wrap gap-3">
                    {existingImages.map((img) => (
                      <div key={img.id} className="relative">
                        <img
                          src={img.url}
                          alt="product"
                          className="w-20 h-20 object-cover rounded-lg border border-gray-200"
                        />
                        <button
                          type="button"
                          onClick={() => handleDeleteExistingImage(img.id)}
                          disabled={deletingImageId === img.id}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600 disabled:opacity-50"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* New Images */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Add More Images
                </label>
                <label className="flex flex-col items-center justify-center w-full h-28 border-2 border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-indigo-400 hover:bg-indigo-50 transition-colors">
                  <Upload className="w-6 h-6 text-gray-400 mb-1" />
                  <span className="text-sm text-gray-500">Click to upload</span>
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleNewImageChange}
                    className="hidden"
                  />
                </label>
                {newImagePreviews.length > 0 && (
                  <div className="flex flex-wrap gap-3 mt-3">
                    {newImagePreviews.map((src, i) => (
                      <div key={i} className="relative">
                        <img
                          src={src}
                          alt={`new-${i}`}
                          className="w-20 h-20 object-cover rounded-lg border border-gray-200"
                        />
                        <button
                          type="button"
                          onClick={() => removeNewImage(i)}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Tags */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <span className="flex items-center gap-1">
                    <Tag className="w-4 h-4" /> Tags
                  </span>
                </label>
                <input
                  type="text"
                  name="tags"
                  value={form.tags}
                  onChange={handleFormChange}
                  placeholder="e.g. wireless, bluetooth (comma separated)"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Delivery & Stock */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Delivery Charge (₹)
                  </label>
                  <input
                    type="number"
                    name="deliveryCharge"
                    value={form.deliveryCharge}
                    onChange={handleFormChange}
                    min="0"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Free Delivery Above (₹)
                  </label>
                  <input
                    type="number"
                    name="freeDeliveryAbove"
                    value={form.freeDeliveryAbove}
                    onChange={handleFormChange}
                    min="0"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Low Stock Threshold
                  </label>
                  <input
                    type="number"
                    name="lowStock"
                    value={form.lowStock}
                    onChange={handleFormChange}
                    min="0"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3">
              {error}
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-6">
          <button
            type="button"
            onClick={step === 1 ? () => navigate('/seller/products') : handleBack}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            {step === 1 ? 'Cancel' : 'Back'}
          </button>

          {step < 3 ? (
            <button
              type="button"
              onClick={handleNext}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors"
            >
              Next
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmit}
              disabled={submitting}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-60"
            >
              {submitting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                  Saving...
                </>
              ) : (
                'Save Changes'
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default EditProduct;
