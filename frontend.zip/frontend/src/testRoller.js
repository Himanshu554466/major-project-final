import Rollbar from 'rollbar';
import { ROLLBAR_TOKEN } from './config';

const rollbar = new Rollbar({
  accessToken: ROLLBAR_TOKEN,
  captureUncaught: true,
  captureUnhandledRejections: true,
});

export default rollbar;