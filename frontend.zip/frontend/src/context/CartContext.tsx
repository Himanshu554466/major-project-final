import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import api from '../services/api';
import { useAuth } from './AuthContext';

interface CartItem {
  id: string;          // PostgreSQL returns "id", not "_id"
  _id?: string;        // fallback for legacy references
  product: {
    id: string;
    title: string;
    images: { id: string; url: string }[];
    variants?: { id: string; price: number; color?: string; size?: string; stock: number }[];
    price?: number;
    deliveryCharge?: number;
    freeDeliveryAbove?: number;
  };
  variant?: {
    id: string;
    price: number;
    color?: string;
    size?: string;
  };
  quantity: number;
}

interface CartContextType {
  cartItems: CartItem[];
  cartCount: number;
  cartTotal: number;
  loading: boolean;
  fetchCart: () => Promise<void>;
  addToCart: (productId: string, variantId?: string, quantity?: number) => Promise<void>;
  removeFromCart: (cartItemId: string) => Promise<void>;
  updateQty: (cartItemId: string, quantity: number) => Promise<void>;
  clearCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(false);
  const { isCustomer } = useAuth();

  const fetchCart = useCallback(async () => {
    if (!isCustomer) return;
    try {
      setLoading(true);
      const res = await api.get('/customer/cart');
      setCartItems(res.data.items || res.data || []);
    } catch (err) {
      console.error('Failed to fetch cart:', err);
      setCartItems([]);
    } finally {
      setLoading(false);
    }
  }, [isCustomer]);

  useEffect(() => {
    if (isCustomer) {
      fetchCart();
    } else {
      setCartItems([]);
    }
  }, [isCustomer, fetchCart]);

  const addToCart = useCallback(
    async (productId: string, variantId?: string, quantity: number = 1) => {
      try {
        await api.post('/customer/cart', { productId, variantId, quantity });
        await fetchCart();
      } catch (err) {
        console.error('Failed to add to cart:', err);
        throw err;
      }
    },
    [fetchCart]
  );

  const removeFromCart = useCallback(
    async (cartItemId: string) => {
      try {
        await api.delete(`/customer/cart/${cartItemId}`);
        setCartItems((prev) => prev.filter((item) => item.id !== cartItemId));
      } catch (err) {
        console.error('Failed to remove from cart:', err);
        throw err;
      }
    },
    []
  );

  const updateQty = useCallback(
    async (cartItemId: string, quantity: number) => {
      try {
        await api.put(`/customer/cart/${cartItemId}`, { quantity });
        setCartItems((prev) =>
          prev.map((item) => (item.id === cartItemId ? { ...item, quantity } : item))
        );
      } catch (err) {
        console.error('Failed to update cart quantity:', err);
        throw err;
      }
    },
    []
  );

  const clearCart = useCallback(() => {
    setCartItems([]);
  }, []);

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const cartTotal = cartItems.reduce((sum, item) => {
    const price = item.variant?.price ?? item.product?.price ?? 0;
    return sum + price * item.quantity;
  }, 0);

  return (
    <CartContext.Provider
      value={{
        cartItems,
        cartCount,
        cartTotal,
        loading,
        fetchCart,
        addToCart,
        removeFromCart,
        updateQty,
        clearCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = (): CartContextType => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

export default CartContext;
