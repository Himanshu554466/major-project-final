/**
 * Rollbar configuration for Ecommerce frontend.
 * Captures unhandled errors, promise rejections, and manual log calls.
 * Rollbar is disabled when no token is configured (e.g. local dev without .env).
 */
import Rollbar from 'rollbar';
import { APP_MODE, ROLLBAR_TOKEN } from '../config';

const token = ROLLBAR_TOKEN;
const isEnabled = Boolean(token && token !== 'undefined' && token !== 'your_rollbar_client_token_here');

const rollbar = new Rollbar({
  accessToken: token || 'undefined',
  environment: APP_MODE,
  captureUncaught: true,
  captureUnhandledRejections: true,
  enabled: isEnabled,
  payload: {
    client: {
      javascript: {
        source_map_enabled: true,
        code_version: '1.0.0',
        guess_uncaught_frames: true,
      },
    },
  },
  scrubFields: ['password', 'token', 'authorization', 'credit_card'],
});

// Only log in development mode
if (APP_MODE === 'development') {
  console.warn('[Rollbar]', isEnabled ? '✅ Enabled' : '❌ Disabled');
}

export default rollbar;
