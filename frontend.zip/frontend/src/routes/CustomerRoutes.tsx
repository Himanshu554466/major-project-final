import { Route } from 'react-router-dom';

import CustomerLayout from '../components/layouts/CustomerLayout';
import Home from '../pages/customer/Home';
import Products from '../pages/customer/Products';
import ProductDetail from '../pages/customer/ProductDetail';
import Cart from '../pages/customer/Cart';
import Checkout from '../pages/customer/Checkout';
import Orders from '../pages/customer/Orders';
import OrderDetail from '../pages/customer/OrderDetail';
import OrderTracking from '../pages/customer/OrderTracking';
import Wishlist from '../pages/customer/Wishlist';
import Account from '../pages/customer/Account';
import Addresses from '../pages/customer/Addresses';

import ProtectedRoute from './ProtectedRoute';

const customerRoutes = (
  <Route element={<CustomerLayout />}>
    <Route path="/" element={<Home />} />
    <Route path="/products" element={<Products />} />
    <Route path="/products/:id" element={<ProductDetail />} />
    <Route
      path="/cart"
      element={(
        <ProtectedRoute allowedRoles={['customer']} redirectTo="/login">
          <Cart />
        </ProtectedRoute>
      )}
    />
    <Route
      path="/checkout"
      element={(
        <ProtectedRoute allowedRoles={['customer']} redirectTo="/login">
          <Checkout />
        </ProtectedRoute>
      )}
    />
    <Route
      path="/orders"
      element={(
        <ProtectedRoute allowedRoles={['customer']} redirectTo="/login">
          <Orders />
        </ProtectedRoute>
      )}
    />
    <Route
      path="/orders/:id"
      element={(
        <ProtectedRoute allowedRoles={['customer']} redirectTo="/login">
          <OrderDetail />
        </ProtectedRoute>
      )}
    />
    <Route
      path="/orders/:id/track"
      element={(
        <ProtectedRoute allowedRoles={['customer']} redirectTo="/login">
          <OrderTracking />
        </ProtectedRoute>
      )}
    />
    <Route
      path="/wishlist"
      element={(
        <ProtectedRoute allowedRoles={['customer']} redirectTo="/login">
          <Wishlist />
        </ProtectedRoute>
      )}
    />
    <Route
      path="/account"
      element={(
        <ProtectedRoute allowedRoles={['customer']} redirectTo="/login">
          <Account />
        </ProtectedRoute>
      )}
    />
    <Route
      path="/addresses"
      element={(
        <ProtectedRoute allowedRoles={['customer']} redirectTo="/login">
          <Addresses />
        </ProtectedRoute>
      )}
    />
  </Route>
);

export default customerRoutes;
