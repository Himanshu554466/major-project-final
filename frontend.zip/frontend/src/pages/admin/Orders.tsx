import { useEffect, useState, useCallback, useRef } from "react";
import { io, Socket } from "socket.io-client";
import {
  ShoppingCart, ChevronLeft, ChevronRight, Loader2,
  AlertCircle, ChevronDown, ChevronUp, RefreshCw, Wifi, WifiOff,
} from "lucide-react";
import API from "../../services/api";
import { SOCKET_URL } from "../../config";

interface OrderItem {
  id: number; quantity: number; price: number;
  product?: { title: string };
  Product?: { title: string };
}
interface AdminOrder {
  id: number; totalAmount: number; status: string;
  paymentStatus: string; paymentMethod: string; createdAt: string;
  returnReason?: string;
  customer?: { email: string; username?: string; phone?: string };
  seller?: { email: string; shopName?: string };
  items?: OrderItem[];
  address?: { name: string; line1: string; city: string; pincode: string };
  shipment?: { id: number; status: string; deliveryPartner?: { fullName: string; deliveryPhone: string } };
}

const ALL_STATUSES = [
  "placed", "confirmed", "preparing", "packed", "shipped",
  "out_for_delivery", "delivered", "cancelled", "rejected",
  "return_requested", "return_approved", "returned",
  "refund_initiated", "refund_completed",
];

const STATUS_TABS = [
  { label: "All", value: "" },
  { label: "🆕 Placed", value: "placed" },
  { label: "✅ Confirmed", value: "confirmed" },
  { label: "🔧 Preparing", value: "preparing" },
  { label: "📦 Packed", value: "packed" },
  { label: "🚚 Shipped", value: "shipped" },
  { label: "🛵 Out for Delivery", value: "out_for_delivery" },
  { label: "✔️ Delivered", value: "delivered" },
  { label: "❌ Cancelled", value: "cancelled" },
  { label: "↩ Return", value: "return_requested,return_approved,returned" },
  { label: "💰 Refund", value: "refund_initiated,refund_completed" },
];

const STATUS_COLORS: Record<string, string> = {
  placed: "bg-blue-100 text-blue-700",
  confirmed: "bg-indigo-100 text-indigo-700",
  preparing: "bg-yellow-100 text-yellow-700",
  packed: "bg-orange-100 text-orange-700",
  shipped: "bg-purple-100 text-purple-700",
  out_for_delivery: "bg-cyan-100 text-cyan-700",
  delivered: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
  rejected: "bg-red-100 text-red-700",
  return_requested: "bg-pink-100 text-pink-700",
  return_approved: "bg-orange-100 text-orange-700",
  returned: "bg-teal-100 text-teal-700",
  refund_initiated: "bg-yellow-100 text-yellow-700",
  refund_completed: "bg-green-100 text-green-700",
};

const PAYMENT_COLORS: Record<string, string> = {
  paid: "bg-green-100 text-green-700",
  pending: "bg-yellow-100 text-yellow-700",
  failed: "bg-red-100 text-red-700",
  refunded: "bg-teal-100 text-teal-700",
};

export default function AdminOrders() {
  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [expandedOrder, setExpandedOrder] = useState<number | null>(null);
  const [statusUpdateLoading, setStatusUpdateLoading] = useState<number | null>(null);
  const [connected, setConnected] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const socketRef = useRef<Socket | null>(null);
  const limit = 15;

  const fetchOrders = useCallback(() => {
    setLoading(true);
    setError("");
    const params = new URLSearchParams({
      page: String(page), limit: String(limit),
      ...(statusFilter ? { status: statusFilter } : {}),
    });
    API.get(`/admin/orders?${params}`)
      .then((res) => {
        setOrders(res.data.orders ?? []);
        setTotal(res.data.total ?? 0);
        setLastRefresh(new Date());
      })
      .catch(() => setError("Failed to load orders."))
      .finally(() => setLoading(false));
  }, [page, statusFilter]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);

  // Real-time socket updates
  useEffect(() => {
    const socket = io(SOCKET_URL, {
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
    });
    socketRef.current = socket;
    socket.on("connect", () => setConnected(true));
    socket.on("disconnect", () => setConnected(false));

    socket.on("order:status:changed", (payload: { orderId: string | number; status: string }) => {
      setOrders(prev => prev.map(o =>
        String(o.id) === String(payload.orderId)
          ? { ...o, status: payload.status }
          : o
      ));
    });

    // Auto-refresh every 30s
    const interval = setInterval(fetchOrders, 30000);
    return () => { socket.disconnect(); clearInterval(interval); };
  }, [fetchOrders]);

  const handleStatusUpdate = async (orderId: number, status: string) => {
    if (!status) return;
    setStatusUpdateLoading(orderId);
    try {
      await API.put(`/admin/orders/${orderId}/status`, { status });
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
    } catch { /* silently fail */ }
    finally { setStatusUpdateLoading(null); }
  };

  const totalPages = Math.ceil(total / limit);

  return (
    <div className="max-w-6xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-gray-700" /> Orders
          </h1>
          <p className="text-sm text-gray-400 mt-0.5">
            Manage all platform orders · Updated {lastRefresh.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full ${connected ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
            {connected ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
            {connected ? "Live" : "Offline"}
          </div>
          <button onClick={fetchOrders} disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50 disabled:opacity-50">
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} /> Refresh
          </button>
        </div>
      </div>

      {/* Status Tabs */}
      <div className="flex gap-1 bg-gray-100 rounded-xl p-1 mb-5 overflow-x-auto">
        {STATUS_TABS.map((tab) => (
          <button key={tab.value} onClick={() => { setStatusFilter(tab.value); setPage(1); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
              statusFilter === tab.value ? "bg-white text-gray-800 shadow-sm" : "text-gray-500 hover:text-gray-700"
            }`}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      {loading ? (
        <div className="flex items-center justify-center h-48">
          <Loader2 className="w-8 h-8 animate-spin text-gray-500" />
        </div>
      ) : error ? (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-2 text-red-700 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />{error}
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-16 bg-white border border-gray-200 rounded-xl">
          <ShoppingCart className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="text-sm text-gray-400">No orders found</p>
        </div>
      ) : (
        <div className="space-y-2">
          {orders.map((order) => {
            const isExpanded = expandedOrder === order.id;
            return (
              <div key={order.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                {/* Order Row */}
                <div className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => setExpandedOrder(isExpanded ? null : order.id)}>
                  <div className="flex-1 grid grid-cols-2 md:grid-cols-6 gap-3 items-center text-sm">
                    <span className="font-mono text-xs text-gray-600">#{String(order.id).padStart(6, "0")}</span>
                    <span className="text-gray-600 truncate">{order.customer?.username || order.customer?.email || "—"}</span>
                    <span className="font-semibold text-gray-800 hidden md:block">
                      ₹{(order.totalAmount || 0).toLocaleString("en-IN")}
                    </span>
                    <div className="hidden md:flex flex-wrap gap-1">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${PAYMENT_COLORS[order.paymentStatus] || "bg-gray-100 text-gray-600"}`}>
                        {order.paymentStatus}
                      </span>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${STATUS_COLORS[order.status] || "bg-gray-100 text-gray-600"}`}>
                      {order.status.replace(/_/g, " ")}
                    </span>
                    <span className="text-gray-500 text-xs hidden md:block">
                      {new Date(order.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                    </span>
                  </div>
                  {isExpanded ? <ChevronUp className="w-4 h-4 text-gray-400 shrink-0" /> : <ChevronDown className="w-4 h-4 text-gray-400 shrink-0" />}
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="border-t border-gray-100 px-4 py-4 bg-gray-50 space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      {/* Customer */}
                      <div>
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Customer</p>
                        <div className="text-sm text-gray-600 space-y-0.5">
                          <p className="font-medium text-gray-800">{order.customer?.username || "—"}</p>
                          <p>{order.customer?.email}</p>
                          <p>{order.customer?.phone || "—"}</p>
                        </div>
                      </div>

                      {/* Items */}
                      <div>
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Items</p>
                        {order.items?.length ? (
                          <div className="space-y-1">
                            {order.items.map((item) => (
                              <div key={item.id} className="flex justify-between text-sm">
                                <span className="text-gray-700 truncate max-w-[120px]">
                                  {item.product?.title || item.Product?.title || `Item #${item.id}`}
                                </span>
                                <span className="text-gray-500 shrink-0 ml-2">×{item.quantity}</span>
                              </div>
                            ))}
                          </div>
                        ) : <p className="text-xs text-gray-400">No items</p>}
                      </div>

                      {/* Delivery */}
                      <div>
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Delivery</p>
                        {order.address ? (
                          <div className="text-sm text-gray-600 space-y-0.5">
                            <p className="font-medium">{order.address.name}</p>
                            <p>{order.address.line1}</p>
                            <p>{order.address.city} - {order.address.pincode}</p>
                          </div>
                        ) : <p className="text-xs text-gray-400">No address</p>}
                        {order.shipment && (
                          <div className="mt-2 text-xs">
                            <span className={`px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[order.shipment.status?.toLowerCase()] || "bg-gray-100 text-gray-600"}`}>
                              Shipment: {order.shipment.status}
                            </span>
                            {order.shipment.deliveryPartner && (
                              <p className="text-gray-600 mt-1">
                                🛵 {order.shipment.deliveryPartner.fullName} · {order.shipment.deliveryPartner.deliveryPhone}
                              </p>
                            )}
                          </div>
                        )}
                        {order.returnReason && (
                          <p className="text-xs text-pink-600 mt-1">↩ {order.returnReason}</p>
                        )}
                      </div>

                      {/* Status Update — disabled for terminal states */}
                      <div>
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Update Status</p>
                        {["delivered", "cancelled", "refund_completed", "returned"].includes(order.status) ? (
                          <p className="text-xs text-gray-400 italic">Order is in a final state</p>
                        ) : (
                          <div className="flex items-center gap-2">
                            <select
                              value={order.status}
                              onChange={(e) => handleStatusUpdate(order.id, e.target.value)}
                              disabled={statusUpdateLoading === order.id}
                              className="text-sm border border-gray-200 rounded-lg px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-gray-400 flex-1"
                            >
                              {ALL_STATUSES.map((s) => (
                                <option key={s} value={s}>{s.replace(/_/g, " ")}</option>
                              ))}
                            </select>
                            {statusUpdateLoading === order.id && (
                              <Loader2 className="w-4 h-4 animate-spin text-gray-500" />
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-5">
          <p className="text-sm text-gray-500">Page {page} of {totalPages} ({total} total)</p>
          <div className="flex gap-2">
            <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
