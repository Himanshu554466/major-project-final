import React, { useState, useEffect, useRef } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Truck, Clock, DollarSign,
  User, LogOut, Menu, Package, Bell,
} from 'lucide-react';
import { io, Socket } from 'socket.io-client';
import { useAuth } from '../../context/AuthContext';
import API from '../../services/api';
import { SOCKET_URL } from '../../config';

const NAV = [
  { to: '/delivery/dashboard',  icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/delivery/shipments',  icon: Truck,           label: 'Active Tasks' },
  { to: '/delivery/history',    icon: Clock,           label: 'History' },
  { to: '/delivery/earnings',   icon: DollarSign,      label: 'Earnings' },
  { to: '/delivery/profile',    icon: User,            label: 'Profile' },
];

interface AssignmentRequest {
  shipmentId: number;
  orderId: number;
  dropCity: string;
  dropPincode: string;
  dropAddress: string;
  customerName: string;
  earnings: number;
  broadcastAt: string;
}

const DeliveryLayout: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);
  const socketRef = useRef<Socket | null>(null);

  const handleLogout = () => { logout(); navigate('/delivery/login'); };

  // Connect to Socket.io — track pending count for bell badge only
  // Actual accept/decline happens on the Shipments page
  useEffect(() => {
    if (!user?.id) return;

    // Fetch initial count from API (survives reload)
    const fetchCount = () => {
      API.get('/delivery/shipments/pending')
        .then((res: any) => setPendingCount(res.data.shipments?.length || 0))
        .catch(() => {});
    };
    fetchCount();

    const socket = io(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
    });
    socketRef.current = socket;

    socket.on('connect', () => {
      socket.emit('partner:join', user.id);
      fetchCount(); // re-fetch on reconnect
    });

    socket.on('delivery:new_assignment_request', (_data: AssignmentRequest) => {
      setPendingCount(prev => prev + 1);
    });

    socket.on('delivery:assignment_taken', () => {
      setPendingCount(prev => Math.max(0, prev - 1));
    });

    // Refresh every 1 minute
    const interval = setInterval(fetchCount, 60000);

    return () => { socket.disconnect(); clearInterval(interval); };
  }, [user?.id]);

  const Sidebar = () => (
    <div className="flex flex-col h-full w-64 bg-green-900 text-white">
      <div className="flex items-center gap-3 px-6 py-5 border-b border-green-700">
        <div className="w-9 h-9 bg-orange-500 rounded-xl flex items-center justify-center">
          <Package size={18} className="text-white" />
        </div>
        <div>
          <p className="font-bold text-sm">Ecommerce</p>
          <p className="text-green-300 text-xs">Delivery Portal</p>
        </div>
      </div>
      <div className="px-4 py-3 border-b border-green-700">
        <p className="text-xs text-green-400">Logged in as</p>
        <p className="text-sm font-semibold truncate">{user?.fullName || user?.email}</p>
      </div>
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {NAV.map(({ to, icon: Icon, label }) => (
          <NavLink key={to} to={to} onClick={() => setOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                isActive ? 'bg-green-700 text-white' : 'text-green-200 hover:bg-green-800 hover:text-white'
              }`
            }>
            <Icon size={18} />
            {label}
            {/* Badge on Active Tasks nav item */}
            {to === '/delivery/shipments' && pendingCount > 0 && (
              <span className="ml-auto min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                {pendingCount}
              </span>
            )}
          </NavLink>
        ))}
      </nav>
      <div className="px-3 py-4 border-t border-green-700">
        <button onClick={handleLogout}
          className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm text-green-200 hover:bg-green-800 hover:text-white transition-colors">
          <LogOut size={18} />
          Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-100 overflow-hidden">
      <div className="hidden md:flex flex-shrink-0"><Sidebar /></div>
      {open && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <Sidebar />
          <div className="flex-1 bg-black/50" onClick={() => setOpen(false)} />
        </div>
      )}

      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 bg-green-900 text-white md:bg-white md:border-b md:border-gray-200 md:text-gray-800">
          <button onClick={() => setOpen(true)} className="md:hidden"><Menu size={22} /></button>
          <span className="font-bold text-sm md:hidden">Delivery Portal</span>
          <div className="hidden md:flex items-center gap-2 text-sm text-gray-500">
            <span>Welcome, <strong className="text-gray-800">{user?.fullName || user?.username}</strong></span>
          </div>
          {/* Bell — navigates to Shipments/pending tab */}
          <button
            onClick={() => navigate('/delivery/shipments')}
            className="relative p-2 rounded-xl text-green-200 hover:bg-green-800 md:text-gray-600 md:hover:bg-gray-100 transition-colors">
            <Bell size={18} />
            {pendingCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                {pendingCount}
              </span>
            )}
          </button>
        </div>
        <main className="flex-1 overflow-y-auto p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DeliveryLayout;
