import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const CustomerRegister: React.FC = () => {
  const [form, setForm] = useState({ username: '', email: '', password: '', phone: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    
    // Validate phone number - only allow digits, +, and spaces
    if (name === 'phone') {
      const cleaned = value.replace(/[^\d+\s]/g, '');
      setForm({ ...form, [name]: cleaned });
      return;
    }
    
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!form.username.trim() || !form.email.trim() || !form.password.trim()) {
      setError('Please fill in all required fields.'); return;
    }
    if (form.password.length < 6) { setError('Password must be at least 6 characters.'); return; }
    try {
      setLoading(true);
      const res = await api.post('/auth/register', { ...form, role: 'customer' });
      login(res.data.token, res.data.user);
      navigate('/');
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message || 'Registration failed.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const pwStrength = form.password.length === 0 ? 0 : form.password.length < 6 ? 1 : form.password.length < 10 ? 2 : 3;
  const pwColors = ['', 'bg-[#CC0C39]', 'bg-[#6d28d9]', 'bg-[#007600]'];
  const pwLabels = ['', 'Weak', 'Medium', 'Strong'];

  return (
    <div className="min-h-screen bg-[#EAEDED] flex flex-col items-center pt-8 pb-16 px-4">
      {/* Logo */}
      <Link to="/" className="mb-6">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-[#6d28d9] rounded-md flex items-center justify-center">
            <span className="text-white font-black text-lg">E</span>
          </div>
          <span className="font-black text-2xl text-[#1e1b4b] tracking-tight">Ecom<span className="text-[#6d28d9]">merce</span></span>
        </div>
      </Link>

      {/* Card */}
      <div className="w-full max-w-sm bg-white border border-[#ddd] rounded-lg p-6">
        <h1 className="text-2xl font-medium text-[#0f1111] mb-5">Create account</h1>

        {error && (
          <div className="mb-4 p-3 bg-[#fff8f0] border border-[#e77600] rounded text-sm text-[#5b21b6] flex items-start gap-2">
            <svg className="w-4 h-4 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#0f1111] mb-1">Your name</label>
            <input type="text" name="username" value={form.username} onChange={handleChange}
              placeholder="First and last name"
              className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30"
              required />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#0f1111] mb-1">Email address</label>
            <input type="email" name="email" value={form.email} onChange={handleChange}
              placeholder="you@example.com"
              className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30"
              required />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#0f1111] mb-1">Mobile number (optional)</label>
            <input 
              type="tel" 
              name="phone" 
              value={form.phone} 
              onChange={handleChange}
              placeholder="+91 XXXXX XXXXX"
              pattern="[\d+\s]*"
              title="Please enter only numbers"
              maxLength={15}
              className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30" 
            />
            <p className="text-xs text-[#555] mt-1">Enter numbers only (e.g., +91 98765 43210)</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#0f1111] mb-1">Password</label>
            <div className="relative">
              <input type={showPassword ? 'text' : 'password'} name="password" value={form.password} onChange={handleChange}
                placeholder="At least 6 characters"
                className="w-full px-3 py-2 pr-10 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30"
                required />
              <button type="button" onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#0066c0] hover:text-[#5b21b6] hover:underline">
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>
            {/* Password strength */}
            {form.password.length > 0 && (
              <div className="mt-1.5 flex items-center gap-2">
                <div className="flex gap-1 flex-1">
                  {[1, 2, 3].map(i => (
                    <div key={i} className={`h-1.5 flex-1 rounded-full ${i <= pwStrength ? pwColors[pwStrength] : 'bg-[#ddd]'}`} />
                  ))}
                </div>
                <span className={`text-xs font-medium ${pwStrength === 1 ? 'text-[#CC0C39]' : pwStrength === 2 ? 'text-[#6d28d9]' : 'text-[#007600]'}`}>
                  {pwLabels[pwStrength]}
                </span>
              </div>
            )}
            <p className="text-xs text-[#555] mt-1">Passwords must be at least 6 characters.</p>
          </div>

          <button type="submit" disabled={loading}
            className="w-full py-2 bg-[#FFD814] hover:bg-[#7c3aed] border border-[#FCD200] rounded text-sm font-semibold text-[#111] transition-colors disabled:opacity-60">
            {loading ? 'Creating account...' : 'Continue'}
          </button>
        </form>

        <p className="text-xs text-[#555] mt-4 leading-relaxed">
          By creating an account, you agree to Ecommerce's{' '}
          <span className="text-[#0066c0] hover:text-[#5b21b6] cursor-pointer hover:underline">Conditions of Use</span>
          {' '}and{' '}
          <span className="text-[#0066c0] hover:text-[#5b21b6] cursor-pointer hover:underline">Privacy Notice</span>.
        </p>

        <div className="mt-5 pt-4 border-t border-[#eee]">
          <p className="text-sm text-[#0f1111]">
            Already have an account?{' '}
            <Link to="/login" className="text-[#0066c0] hover:text-[#5b21b6] hover:underline font-medium">Sign in</Link>
          </p>
        </div>
      </div>

      {/* Other portals */}
      <div className="w-full max-w-sm mt-6 flex items-center gap-3">
        <div className="flex-1 h-px bg-[#ddd]" />
        <span className="text-xs text-[#767676]">Other portals</span>
        <div className="flex-1 h-px bg-[#ddd]" />
      </div>
      <div className="w-full max-w-sm mt-4 grid grid-cols-2 gap-2">
        <Link to="/seller/register"
          className="py-2 border border-[#ddd] rounded text-xs text-center text-[#0066c0] hover:bg-[#f0f0f0] hover:text-[#5b21b6] transition-colors bg-white">
          Become a Seller
        </Link>
        <Link to="/delivery/register"
          className="py-2 border border-[#ddd] rounded text-xs text-center text-[#0066c0] hover:bg-[#f0f0f0] hover:text-[#5b21b6] transition-colors bg-white">
          Delivery Partner
        </Link>
      </div>
    </div>
  );
};

export default CustomerRegister;
