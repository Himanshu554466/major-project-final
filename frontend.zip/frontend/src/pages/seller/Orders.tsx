import React, { useEffect, useState, useCallback, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import {
  ChevronLeft, ChevronRight, ChevronDown, ChevronUp,
  ShoppingBag, CheckCircle, XCircle, Package, Truck,
  MapPin, Clock, RefreshCw, Wifi, WifiOff,
} from 'lucide-react';
import api from '../../services/api';
import { SOCKET_URL } from '../../config';

type OrderStatus =
  | 'placed' | 'confirmed' | 'preparing' | 'packed'
  | 'shipped' | 'out_for_delivery' | 'delivered'
  | 'cancelled' | 'rejected' | 'return_requested'
  | 'returned' | 'refund_initiated' | 'refund_completed'
  | 'return_approved';

interface TrackingEvent {
  status: string; message: string; timestamp: string; location?: string; actorRole?: string;
}

interface OrderItem {
  id: string; quantity: number; price: number;
  product: { id: string; title: string; images: { id: string; url: string }[] };
  variant: { color: string; size: string } | null;
}

interface Order {
  id: string; status: OrderStatus; totalAmount: number;
  paymentMethod: string; paymentStatus: string; createdAt: string;
  items: OrderItem[];
  shipment: {
    id: string; status: string; deliveryPartnerId?: number;
    dropAddress?: string; dropCity?: string;
    trackingEvents?: TrackingEvent[];
    deliveryPartner?: { fullName: string; deliveryPhone: string };
  } | null;
  customer: { id: string; email: string; username: string; phone: string };
  address?: { name: string; phone: string; line1: string; city: string; pincode: string };
}

const STATUS_TABS = [
  { label: 'All', value: '' },
  { label: '🆕 Placed', value: 'placed' },
  { label: '✅ Confirmed', value: 'confirmed' },
  { label: '🔧 Preparing', value: 'preparing' },
  { label: '📦 Packed', value: 'packed' },
  { label: '🚚 Shipped', value: 'shipped' },
  { label: '🛵 Out for Delivery', value: 'out_for_delivery' },
  { label: '✔️ Delivered', value: 'delivered' },
  { label: '❌ Cancelled', value: 'cancelled' },
];

const STATUS_BADGE: Record<string, string> = {
  placed: 'bg-blue-100 text-blue-700',
  confirmed: 'bg-indigo-100 text-indigo-700',
  preparing: 'bg-yellow-100 text-yellow-700',
  packed: 'bg-orange-100 text-orange-700',
  shipped: 'bg-purple-100 text-purple-700',
  out_for_delivery: 'bg-cyan-100 text-cyan-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
  rejected: 'bg-red-100 text-red-700',
  return_requested: 'bg-pink-100 text-pink-700',
  return_approved: 'bg-orange-100 text-orange-700',
  returned: 'bg-teal-100 text-teal-700',
  refund_initiated: 'bg-yellow-100 text-yellow-700',
  refund_completed: 'bg-green-100 text-green-700',
};

const SHIPMENT_STATUS_BADGE: Record<string, string> = {
  ORDER_CREATED: 'bg-gray-100 text-gray-600',
  ORDER_CONFIRMED: 'bg-indigo-100 text-indigo-700',
  SELLER_PREPARING: 'bg-yellow-100 text-yellow-700',
  PACKED: 'bg-orange-100 text-orange-700',
  ASSIGNED: 'bg-blue-100 text-blue-700',
  ACCEPTED: 'bg-blue-100 text-blue-700',
  PICKED_UP: 'bg-purple-100 text-purple-700',
  IN_TRANSIT: 'bg-purple-100 text-purple-700',
  OUT_FOR_DELIVERY: 'bg-cyan-100 text-cyan-700',
  DELIVERED: 'bg-green-100 text-green-700',
  FAILED: 'bg-red-100 text-red-700',
  CANCELLED: 'bg-red-100 text-red-700',
};

// ── Seller Return Timeline (full operational view) ────────────────────────
const SELLER_RETURN_TIMELINE = [
  { key: 'return_requested', label: 'Return Requested' },
  { key: 'return_approved',  label: 'Return Approved' },
  { key: 'PACKED',           label: 'Pickup Assigned' },
  { key: 'PICKED_UP',        label: 'Picked Up from Customer' },
  { key: 'IN_TRANSIT',       label: 'In Transit to Seller' },
  { key: 'OUT_FOR_DELIVERY', label: 'Arriving to Seller' },
  { key: 'DELIVERED',        label: 'Delivered to Seller' },
  { key: 'refund_initiated', label: 'Refund Initiated' },
  { key: 'refund_completed', label: 'Refund Completed' },
];

const RETURN_SHIP_TO_SELLER_STEP: Record<string, string> = {
  PACKED:           'PACKED',
  ASSIGNED:         'PACKED',
  ACCEPTED:         'PACKED',
  PICKED_UP:        'PICKED_UP',
  IN_TRANSIT:       'IN_TRANSIT',
  OUT_FOR_DELIVERY: 'OUT_FOR_DELIVERY',
  DELIVERED:        'DELIVERED',
};

const Orders: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [pages, setPages] = useState(1);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [connected, setConnected] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const socketRef = useRef<Socket | null>(null);
  const limit = 15;

  const fetchOrders = useCallback(async () => {
    setLoading(true);
    try {
      const params: Record<string, string | number> = { page, limit };
      if (statusFilter) params.status = statusFilter;
      const res = await api.get('/seller/orders', { params });
      setOrders(res.data.orders ?? []);
      setPages(res.data.pages ?? 1);
      setLastRefresh(new Date());
    } catch {
      setOrders([]);
    } finally {
      setLoading(false);
    }
  }, [page, statusFilter]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);

  // Socket.io — listen for order status changes in real time
  useEffect(() => {
    const socket = io(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
    });
    socketRef.current = socket;

    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));

    // When any order status changes, update it in the list AND refresh full order data
    socket.on('order:status:changed', (payload: { orderId: string | number; status: string; message?: string }) => {
      setOrders(prev => prev.map(o =>
        String(o.id) === String(payload.orderId)
          ? { ...o, status: payload.status as OrderStatus }
          : o
      ));
      // Refresh full order list to get updated shipment/tracking data
      fetchOrders();
    });

    // Also listen for status sync events
    socket.on('order:status:sync', (payload: { orderId: string | number; status: string; shipmentStatus?: string }) => {
      setOrders(prev => prev.map(o => {
        if (String(o.id) !== String(payload.orderId)) return o;
        return {
          ...o,
          status: payload.status as OrderStatus,
          shipment: o.shipment ? { ...o.shipment, status: payload.shipmentStatus || o.shipment.status } : o.shipment,
        };
      }));
    });

    // Auto-refresh every 30 seconds (reduced from 60s for faster updates)
    const interval = setInterval(() => fetchOrders(), 30000);

    return () => {
      socket.disconnect();
      clearInterval(interval);
    };
  }, [fetchOrders]);

  const handleStatusUpdate = async (orderId: string, newStatus: string) => {
    setUpdatingId(orderId);
    try {
      await api.put(`/seller/orders/${orderId}/status`, { status: newStatus });
      setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus as OrderStatus } : o));
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
      alert(msg || 'Failed to update order status.');
    } finally {
      setUpdatingId(null);
    }
  };

  const formatTime = (iso: string) =>
    new Date(iso).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

  return (
    <div className="p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Orders</h1>
          <p className="text-gray-500 text-sm mt-0.5">
            Real-time order tracking · Last updated {lastRefresh.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
          </p>
        </div>
        <div className="flex items-center gap-3">
          {/* Live indicator */}
          <div className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-full ${
            connected ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
          }`}>
            {connected ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
            {connected ? 'Live' : 'Offline'}
          </div>
          <button onClick={fetchOrders} disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50 disabled:opacity-50 transition-colors">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Status Tabs */}
      <div className="flex flex-wrap gap-2">
        {STATUS_TABS.map(tab => (
          <button key={tab.value} onClick={() => { setStatusFilter(tab.value); setPage(1); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              statusFilter === tab.value
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
            }`}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center h-48">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
          </div>
        ) : orders.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-gray-400">
            <ShoppingBag className="w-10 h-10 mb-2" />
            <p className="font-medium">No orders found</p>
            <p className="text-sm mt-1">Orders will appear here when customers place them</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 text-gray-500 text-xs uppercase border-b border-gray-100">
                  <th className="px-4 py-3 text-left w-8" />
                  <th className="px-4 py-3 text-left">Order</th>
                  <th className="px-4 py-3 text-left">Customer</th>
                  <th className="px-4 py-3 text-left">Items</th>
                  <th className="px-4 py-3 text-left">Total</th>
                  <th className="px-4 py-3 text-left">Order Status</th>
                  <th className="px-4 py-3 text-left">Delivery Status</th>
                  <th className="px-4 py-3 text-left">Date</th>
                  <th className="px-4 py-3 text-left">Actions</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(order => (
                  <React.Fragment key={order.id}>
                    <tr className="border-b border-gray-100 hover:bg-gray-50 transition-colors cursor-pointer"
                      onClick={() => setExpandedId(prev => prev === order.id ? null : order.id)}>
                      <td className="px-4 py-3 text-gray-400">
                        {expandedId === order.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-gray-600">
                        #{String(order.id).padStart(6, '0')}
                      </td>
                      <td className="px-4 py-3 text-gray-700 max-w-[130px] truncate">
                        {order.customer?.username || order.customer?.email}
                      </td>
                      <td className="px-4 py-3 text-gray-600">{order.items?.length ?? 0}</td>
                      <td className="px-4 py-3 font-medium text-gray-800">
                        ₹{order.totalAmount?.toLocaleString('en-IN')}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium capitalize ${STATUS_BADGE[order.status] ?? 'bg-gray-100 text-gray-600'}`}>
                          {order.status?.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        {order.shipment ? (
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${SHIPMENT_STATUS_BADGE[order.shipment.status] ?? 'bg-gray-100 text-gray-600'}`}>
                            {order.shipment.status?.replace(/_/g, ' ')}
                          </span>
                        ) : <span className="text-xs text-gray-400">—</span>}
                      </td>
                      <td className="px-4 py-3 text-gray-500 text-xs">
                        {new Date(order.createdAt).toLocaleDateString('en-IN')}
                      </td>
                      <td className="px-4 py-3" onClick={e => e.stopPropagation()}>
                        <div className="flex items-center gap-1 flex-wrap">
                          {order.status === 'placed' && (
                            <>
                              <button onClick={() => handleStatusUpdate(order.id, 'confirmed')} disabled={updatingId === order.id}
                                className="flex items-center gap-1 px-2 py-1 bg-green-50 text-green-700 hover:bg-green-100 rounded-lg text-xs font-medium disabled:opacity-50">
                                <CheckCircle className="w-3 h-3" /> Accept
                              </button>
                              <button onClick={() => handleStatusUpdate(order.id, 'rejected')} disabled={updatingId === order.id}
                                className="flex items-center gap-1 px-2 py-1 bg-red-50 text-red-700 hover:bg-red-100 rounded-lg text-xs font-medium disabled:opacity-50">
                                <XCircle className="w-3 h-3" /> Decline
                              </button>
                            </>
                          )}
                          {order.status === 'confirmed' && (
                            <button onClick={() => handleStatusUpdate(order.id, 'preparing')} disabled={updatingId === order.id}
                              className="flex items-center gap-1 px-2 py-1 bg-yellow-50 text-yellow-700 hover:bg-yellow-100 rounded-lg text-xs font-medium disabled:opacity-50">
                              <Package className="w-3 h-3" /> Preparing
                            </button>
                          )}
                          {order.status === 'preparing' && (
                            <button onClick={() => handleStatusUpdate(order.id, 'packed')} disabled={updatingId === order.id}
                              className="flex items-center gap-1 px-2 py-1 bg-orange-50 text-orange-700 hover:bg-orange-100 rounded-lg text-xs font-medium disabled:opacity-50">
                              <Truck className="w-3 h-3" /> Mark Packed
                            </button>
                          )}
                          {order.status === 'return_requested' && (
                            <button onClick={() => handleStatusUpdate(order.id, 'return_approved')} disabled={updatingId === order.id}
                              className="flex items-center gap-1 px-2 py-1 bg-pink-50 text-pink-700 hover:bg-pink-100 rounded-lg text-xs font-medium disabled:opacity-50">
                              ↩ Approve Return
                            </button>
                          )}
                          {/* Initiate Refund — only after return shipment is DELIVERED (item back at seller) */}
                          {order.status === 'returned' && (order as any).returnShipment?.status === 'DELIVERED' && (
                            <button onClick={async () => {
                              setUpdatingId(order.id);
                              try {
                                await api.put(`/seller/orders/${order.id}/initiate-refund`);
                                setOrders(prev => prev.map(o => o.id === order.id ? { ...o, status: 'refund_initiated' as OrderStatus } : o));
                              } catch (err: unknown) {
                                const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
                                alert(msg || 'Failed to initiate refund.');
                              } finally { setUpdatingId(null); }
                            }} disabled={updatingId === order.id}
                              className="flex items-center gap-1 px-2 py-1 bg-green-50 text-green-700 hover:bg-green-100 rounded-lg text-xs font-medium disabled:opacity-50">
                              💰 Initiate Refund
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>

                    {/* ── Expanded Detail Row ── */}
                    {expandedId === order.id && (
                      <tr className="bg-indigo-50/30">
                        <td colSpan={9} className="px-6 py-5">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

                            {/* Customer Info */}
                            <div>
                              <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                                👤 Customer Details
                              </h4>
                              <div className="space-y-1.5 text-sm text-gray-600 bg-white rounded-lg p-3 border border-gray-100">
                                <p><span className="font-medium text-gray-700">Name:</span> {order.customer?.username || '—'}</p>
                                <p><span className="font-medium text-gray-700">Email:</span> {order.customer?.email}</p>
                                <p><span className="font-medium text-gray-700">Phone:</span> {order.customer?.phone || '—'}</p>
                                <p><span className="font-medium text-gray-700">Payment:</span>{' '}
                                  <span className={order.paymentStatus === 'paid' ? 'text-green-600 font-medium' : 'text-orange-600 font-medium'}>
                                    {order.paymentMethod?.toUpperCase()} · {order.paymentStatus}
                                  </span>
                                </p>
                                {(order as any).returnReason && (
                                  <p className="text-pink-600 text-xs mt-1">
                                    ↩ Return reason: {(order as any).returnReason}
                                  </p>
                                )}
                                {order.address && (
                                  <p className="flex items-start gap-1">
                                    <MapPin className="w-3.5 h-3.5 mt-0.5 text-gray-400 shrink-0" />
                                    {order.address.line1}, {order.address.city} - {order.address.pincode}
                                  </p>
                                )}
                              </div>
                            </div>

                            {/* Order Items */}
                            <div>
                              <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                                📦 Order Items
                              </h4>
                              <div className="space-y-2">
                                {order.items?.map(item => (
                                  <div key={item.id} className="flex items-center gap-3 bg-white rounded-lg p-2 border border-gray-100">
                                    {item.product?.images?.[0]?.url ? (
                                      <img src={item.product.images[0].url} alt={item.product.title}
                                        className="w-10 h-10 rounded object-cover border border-gray-200 flex-shrink-0" />
                                    ) : (
                                      <div className="w-10 h-10 rounded bg-gray-100 flex items-center justify-center flex-shrink-0">
                                        <Package className="w-4 h-4 text-gray-400" />
                                      </div>
                                    )}
                                    <div className="flex-1 min-w-0">
                                      <p className="text-sm font-medium text-gray-800 truncate">{item.product?.title}</p>
                                      {item.variant && (
                                        <p className="text-xs text-gray-500">{[item.variant.color, item.variant.size].filter(Boolean).join(' / ')}</p>
                                      )}
                                    </div>
                                    <div className="text-right text-sm shrink-0">
                                      <p className="font-medium text-gray-800">₹{item.price?.toLocaleString('en-IN')}</p>
                                      <p className="text-xs text-gray-500">×{item.quantity}</p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Delivery / Return Tracking */}
                            <div>
                              <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-1.5">
                                🚚 Delivery Tracking
                              </h4>

                              {/* Forward shipment — always shown */}
                              {order.shipment ? (
                                <div className="bg-white rounded-lg p-3 border border-gray-100 space-y-3 mb-3">
                                  <div className="flex items-center justify-between">
                                    <span className="text-xs text-gray-500">Shipment #{order.shipment.id}</span>
                                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${SHIPMENT_STATUS_BADGE[order.shipment.status] ?? 'bg-gray-100 text-gray-600'}`}>
                                      {order.shipment.status?.replace(/_/g, ' ')}
                                    </span>
                                  </div>
                                  {order.shipment.deliveryPartner && (
                                    <div className="text-xs text-gray-600 bg-green-50 rounded p-2">
                                      <p className="font-medium text-green-700">🛵 Delivery Partner</p>
                                      <p>{order.shipment.deliveryPartner.fullName}</p>
                                      <p>{order.shipment.deliveryPartner.deliveryPhone}</p>
                                    </div>
                                  )}
                                  {!order.shipment.deliveryPartnerId && ['PACKED', 'ORDER_CONFIRMED', 'SELLER_PREPARING'].includes(order.shipment.status) && (
                                    <p className="text-xs text-orange-600 bg-orange-50 rounded p-2">
                                      ⏳ Awaiting delivery partner (auto-broadcasts every 2 min)
                                    </p>
                                  )}
                                  {order.shipment.trackingEvents && order.shipment.trackingEvents.length > 0 && (
                                    <div>
                                      <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Timeline</p>
                                      <div className="space-y-2 max-h-40 overflow-y-auto">
                                        {[...order.shipment.trackingEvents].reverse().map((event, idx) => (
                                          <div key={idx} className="flex gap-2 text-xs">
                                            <div className={`w-2 h-2 rounded-full mt-1 shrink-0 ${idx === 0 ? 'bg-indigo-500' : 'bg-gray-300'}`} />
                                            <div>
                                              <p className="font-medium text-gray-700">{event.status?.replace(/_/g, ' ')}</p>
                                              <p className="text-gray-500">{event.message}</p>
                                              <p className="text-gray-400 flex items-center gap-1">
                                                <Clock className="w-3 h-3" />
                                                {formatTime(event.timestamp)}
                                                {event.actorRole && <span className="ml-1 capitalize">· {event.actorRole.replace(/_/g, ' ')}</span>}
                                              </p>
                                            </div>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              ) : (
                                <div className="bg-white rounded-lg p-3 border border-gray-100 text-xs text-gray-400 text-center mb-3">
                                  No shipment created yet
                                </div>
                              )}

                              {/* ── Return Shipment — separate section below ── */}
                              {(order as any).returnShipment && (() => {
                                const rs = (order as any).returnShipment;
                                const KEYS = SELLER_RETURN_TIMELINE.map(s => s.key);
                                const shipStatus = rs.status?.toUpperCase();
                                const mappedShip = RETURN_SHIP_TO_SELLER_STEP[shipStatus] || null;
                                const orderIdx = KEYS.indexOf(order.status);
                                const shipIdx = mappedShip ? KEYS.indexOf(mappedShip) : -1;
                                let activeIdx = Math.max(orderIdx, shipIdx);
                                if (shipStatus === 'DELIVERED') {
                                  if (order.status === 'refund_completed') activeIdx = KEYS.indexOf('refund_completed');
                                  else if (order.status === 'refund_initiated') activeIdx = KEYS.indexOf('refund_initiated');
                                  else activeIdx = KEYS.indexOf('DELIVERED');
                                }
                                return (
                                  <div className="bg-pink-50 rounded-lg p-3 border border-pink-200">
                                    <div className="flex items-center justify-between mb-3">
                                      <span className="text-xs font-semibold text-pink-700">↩ Return Shipment #{rs.id}</span>
                                      <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-pink-100 text-pink-700">
                                        {rs.status?.replace(/_/g, ' ')}
                                      </span>
                                    </div>
                                    {rs.deliveryPartner && (
                                      <div className="text-xs text-gray-600 bg-white rounded p-2 border border-pink-100 mb-3">
                                        <p className="font-medium text-pink-700">🛵 Pickup Partner</p>
                                        <p>{rs.deliveryPartner.fullName} · {rs.deliveryPartner.deliveryPhone}</p>
                                      </div>
                                    )}
                                    {/* Seller return progress steps */}
                                    <div className="space-y-1.5 mb-3">
                                      {SELLER_RETURN_TIMELINE.map((step, idx) => {
                                        const done = idx <= activeIdx;
                                        const active = idx === activeIdx;
                                        return (
                                          <div key={step.key} className="flex items-center gap-2">
                                            <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 text-[10px] font-bold ${
                                              done ? 'bg-pink-500 text-white' : 'bg-gray-200 text-gray-400'
                                            } ${active ? 'ring-2 ring-pink-300' : ''}`}>
                                              {done ? '✓' : idx + 1}
                                            </div>
                                            <span className={`text-xs ${done ? 'text-gray-800 font-medium' : 'text-gray-400'}`}>
                                              {step.label}
                                            </span>
                                          </div>
                                        );
                                      })}
                                    </div>
                                    {/* Return timeline events */}
                                    {rs.trackingEvents?.length > 0 && (
                                      <div className="border-t border-pink-200 pt-2">
                                        <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1.5">Return Timeline</p>
                                        <div className="space-y-1.5 max-h-32 overflow-y-auto">
                                          {[...rs.trackingEvents].reverse().map((event: TrackingEvent, idx: number) => (
                                            <div key={idx} className="flex gap-2 text-xs">
                                              <div className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${idx === 0 ? 'bg-pink-500' : 'bg-gray-300'}`} />
                                              <div>
                                                <span className="font-medium text-gray-700">{event.status?.replace(/_/g, ' ')}</span>
                                                <span className="text-gray-400 ml-1">· {formatTime(event.timestamp)}</span>
                                              </div>
                                            </div>
                                          ))}
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                );
                              })()}
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {pages > 1 && (
          <div className="flex items-center justify-between px-6 py-4 border-t border-gray-100">
            <p className="text-sm text-gray-500">Page {page} of {pages}</p>
            <div className="flex items-center gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-40">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button onClick={() => setPage(p => Math.min(pages, p + 1))} disabled={page === pages}
                className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-40">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Orders;
