import { Route } from 'react-router-dom';

import AdminLayout from '../components/layouts/AdminLayout';
import AdminDashboard from '../pages/admin/Dashboard';
import AdminUsers from '../pages/admin/Users';
import AdminSellerView from '../pages/admin/SellerView';
import AdminProducts from '../pages/admin/Products';
import AdminOrders from '../pages/admin/Orders';
import AdminShipments from '../pages/admin/Shipments';
import AdminComplaints from '../pages/admin/Complaints';
import AdminRefunds from '../pages/admin/Refunds';

import ProtectedRoute from './ProtectedRoute';

const adminRoutes = (
  <Route
    element={(
      <ProtectedRoute allowedRoles={['admin']} redirectTo="/admin/login">
        <AdminLayout />
      </ProtectedRoute>
    )}
  >
    <Route path="/admin/dashboard" element={<AdminDashboard />} />
    <Route path="/admin/users" element={<AdminUsers />} />
    <Route path="/admin/sellers/:sellerId" element={<AdminSellerView />} />
    <Route path="/admin/products" element={<AdminProducts />} />
    <Route path="/admin/orders" element={<AdminOrders />} />
    <Route path="/admin/shipments" element={<AdminShipments />} />
    <Route path="/admin/complaints" element={<AdminComplaints />} />
    <Route path="/admin/refunds" element={<AdminRefunds />} />
  </Route>
);

export default adminRoutes;
