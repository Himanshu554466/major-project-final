import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { io, Socket } from 'socket.io-client';
import {
  Truck, CheckCircle, Clock, MapPin, RefreshCw,
  AlertCircle, Loader2, Package, RotateCcw, IndianRupee,
} from 'lucide-react';
import api from '../../services/api';
import { SOCKET_URL } from '../../config';

interface TrackingEvent {
  status: string;
  message: string;
  timestamp: string;
  location?: string;
  isReturn?: boolean;
}

interface TrackingData {
  order: {
    id: string | number;
    status: string;
    returnReason?: string;
    totalAmount?: number;
    paymentStatus?: string;
  };
  shipment?: {
    id: string;
    status: string;
    deliveryPartner?: { fullName?: string; name?: string; deliveryPhone?: string; phone?: string };
    trackingEvents: TrackingEvent[];
  } | null;
  returnShipment?: {
    id: string;
    status: string;
    deliveryPartner?: { fullName?: string; deliveryPhone?: string };
    trackingEvents: TrackingEvent[];
  } | null;
}

// ── Forward delivery steps (customer view) ───────────────────────────────────
const FORWARD_STEPS = [
  { key: 'ORDER_CREATED',    label: 'Order Placed',       icon: Package },
  { key: 'ORDER_CONFIRMED',  label: 'Confirmed',          icon: CheckCircle },
  { key: 'SELLER_PREPARING', label: 'Preparing',          icon: Package },
  { key: 'PACKED',           label: 'Packed',             icon: Package },
  { key: 'ASSIGNED',         label: 'Partner Assigned',   icon: Truck },
  { key: 'PICKED_UP',        label: 'Picked Up',          icon: Truck },
  { key: 'IN_TRANSIT',       label: 'In Transit',         icon: Truck },
  { key: 'OUT_FOR_DELIVERY', label: 'Out for Delivery',   icon: Truck },
  { key: 'DELIVERED',        label: 'Delivered',          icon: CheckCircle },
];

// ── Customer-facing return steps (simplified — max 7 steps) ─────────────────
const CUSTOMER_RETURN_STEPS = [
  { key: 'return_requested', label: 'Return Requested',    icon: RotateCcw },
  { key: 'return_approved',  label: 'Return Approved',     icon: CheckCircle },
  { key: 'PACKED',           label: 'Pickup Scheduled',    icon: Package },
  { key: 'PICKED_UP',        label: 'Item Picked Up',      icon: Truck },
  { key: 'IN_TRANSIT',       label: 'In Transit',          icon: Truck },
  { key: 'OUT_FOR_DELIVERY', label: 'Arriving to Seller',  icon: Truck },
  { key: 'refund_initiated', label: 'Refund Initiated',    icon: IndianRupee },
  { key: 'refund_completed', label: 'Refund Completed',    icon: CheckCircle },
];

// Map order status → forward step key
const ORDER_TO_FORWARD: Record<string, string> = {
  placed:           'ORDER_CREATED',
  confirmed:        'ORDER_CONFIRMED',
  preparing:        'SELLER_PREPARING',
  packed:           'PACKED',
  shipped:          'PICKED_UP',
  out_for_delivery: 'OUT_FOR_DELIVERY',
  delivered:        'DELIVERED',
};

// Map shipment status → forward step key (shipment is always more accurate than order status)
const SHIPMENT_TO_FORWARD: Record<string, string> = {
  ORDER_CREATED:    'ORDER_CREATED',
  ORDER_CONFIRMED:  'ORDER_CONFIRMED',
  SELLER_PREPARING: 'SELLER_PREPARING',
  PACKED:           'PACKED',
  ASSIGNED:         'ASSIGNED',
  ACCEPTED:         'ASSIGNED',   // ACCEPTED = partner confirmed, still at "Partner Assigned" step
  PICKED_UP:        'PICKED_UP',
  IN_TRANSIT:       'IN_TRANSIT',
  OUT_FOR_DELIVERY: 'OUT_FOR_DELIVERY',
  DELIVERED:        'DELIVERED',
};

// Map return shipment status → customer return step key
const RETURN_SHIP_TO_CUSTOMER: Record<string, string> = {
  PACKED:           'PACKED',
  ASSIGNED:         'PACKED',
  ACCEPTED:         'PACKED',
  PICKED_UP:        'PICKED_UP',
  IN_TRANSIT:       'IN_TRANSIT',
  OUT_FOR_DELIVERY: 'OUT_FOR_DELIVERY',
  DELIVERED:        'OUT_FOR_DELIVERY', // item at seller — refund next
};

const RETURN_ORDER_STATUSES = [
  'return_requested', 'return_approved', 'returned',
  'refund_initiated', 'refund_completed',
];
export default function OrderTracking() {
  const { id: orderId } = useParams<{ id: string }>();
  const [data, setData] = useState<TrackingData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const socketRef = useRef<Socket | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchTracking = useCallback(async () => {
    if (!orderId) return;
    try {
      const res = await api.get(`/customer/track/${orderId}`);
      const { order, shipment, returnShipment } = res.data;
      setData({ order, shipment: shipment || null, returnShipment: returnShipment || null });
      setLastUpdated(new Date());
      setError('');
    } catch {
      setError('Unable to fetch tracking information.');
    } finally {
      setLoading(false);
    }
  }, [orderId]);

  useEffect(() => {
    fetchTracking();
    intervalRef.current = setInterval(fetchTracking, 30000);

    const socket = io(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
    });
    socketRef.current = socket;

    socket.on('connect', () => socket.emit('track:join', orderId));
    socket.on('order:status:changed', (payload: { orderId: string }) => {
      if (String(payload.orderId) === String(orderId)) fetchTracking();
    });
    socket.on('order:status:sync', (payload: { orderId: string }) => {
      if (String(payload.orderId) === String(orderId)) fetchTracking();
    });

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      socket.disconnect();
    };
  }, [orderId, fetchTracking]);

  const orderStatus = data?.order?.status || '';
  // Show return flow if order is in return status OR if a return shipment exists
  const isReturnFlow = RETURN_ORDER_STATUSES.includes(orderStatus) || !!data?.returnShipment;

  // ── Compute current step index ────────────────────────────────────────────
  const getForwardStepIdx = (): number => {
    const shipStatus = data?.shipment?.status?.toUpperCase();
    const shipKey = shipStatus ? SHIPMENT_TO_FORWARD[shipStatus] : null;
    const orderKey = ORDER_TO_FORWARD[orderStatus];
    const shipIdx = shipKey ? FORWARD_STEPS.findIndex(s => s.key === shipKey) : -1;
    const orderIdx = orderKey ? FORWARD_STEPS.findIndex(s => s.key === orderKey) : -1;
    // Shipment status is always more accurate — only fall back to order if no shipment
    return shipIdx >= 0 ? shipIdx : orderIdx;
  };

  const getReturnStepIdx = (): number => {
    const KEYS = CUSTOMER_RETURN_STEPS.map(s => s.key);
    const returnShipStatus = data?.returnShipment?.status?.toUpperCase();
    const mappedShipKey = returnShipStatus ? RETURN_SHIP_TO_CUSTOMER[returnShipStatus] : null;

    // Order status index
    const orderIdx = KEYS.indexOf(orderStatus);
    // Return shipment index
    const shipIdx = mappedShipKey ? KEYS.indexOf(mappedShipKey) : -1;

    // Special: if return shipment is DELIVERED → item is back at seller → refund should be next
    if (returnShipStatus === 'DELIVERED') {
      if (orderStatus === 'refund_completed') return KEYS.indexOf('refund_completed');
      if (orderStatus === 'refund_initiated') return KEYS.indexOf('refund_initiated');
      // Item delivered to seller but refund not yet initiated
      return KEYS.indexOf('OUT_FOR_DELIVERY');
    }

    return Math.max(orderIdx, shipIdx);
  };

  const activeSteps = isReturnFlow ? CUSTOMER_RETURN_STEPS : FORWARD_STEPS;
  const currentStepIdx = isReturnFlow ? getReturnStepIdx() : getForwardStepIdx();

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleString('en-IN', {
      day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
    });

  // ── Customer-friendly event labels ───────────────────────────────────────
  const getCustomerFriendlyLabel = (event: TrackingEvent & { isReturn?: boolean }): string => {
    if (!event.isReturn) {
      const forwardMap: Record<string, string> = {
        ORDER_CREATED:    'Order Placed',
        ORDER_CONFIRMED:  'Order Confirmed',
        SELLER_PREPARING: 'Seller Preparing',
        PACKED:           'Order Packed',
        ASSIGNED:         'Delivery Partner Assigned',
        ACCEPTED:         'Delivery Partner Accepted',
        PICKED_UP:        'Order Picked Up',
        IN_TRANSIT:       'In Transit',
        OUT_FOR_DELIVERY: 'Out for Delivery',
        DELIVERED:        'Delivered',
        FAILED:           'Delivery Attempt Failed',
        DECLINED:         'Partner Declined — Reassigning',
      };
      return forwardMap[event.status.toUpperCase()] || event.status.replace(/_/g, ' ');
    }
    const returnMap: Record<string, string> = {
      PACKED:           'Pickup Scheduled',
      ASSIGNED:         'Delivery Partner Assigned for Pickup',
      ACCEPTED:         'Delivery Partner Accepted Pickup',
      PICKED_UP:        'Item Picked Up from Your Address',
      IN_TRANSIT:       'Item on the Way Back',
      OUT_FOR_DELIVERY: 'Arriving to Seller',
      DELIVERED:        'Item Returned to Seller',
      DECLINED:         'Pickup Declined — Rescheduling',
    };
    return returnMap[event.status.toUpperCase()] || event.status.replace(/_/g, ' ');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
        <p className="text-xl font-semibold text-gray-700">{error || 'Tracking info not available'}</p>
        <Link to="/orders" className="mt-4 inline-block text-orange-500 hover:text-orange-600 font-medium">
          ← Back to Orders
        </Link>
      </div>
    );
  }

  // Merge tracking events — for return flow, show customer-friendly labels
  const allEvents: (TrackingEvent & { isReturn?: boolean })[] = [
    ...(data.shipment?.trackingEvents || []).map(e => ({ ...e, isReturn: false })),
    ...(data.returnShipment?.trackingEvents || []).map(e => ({ ...e, isReturn: true })),
  ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const returnPartner = data.returnShipment?.deliveryPartner;
  const forwardPartner = data.shipment?.deliveryPartner;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Track Order</h1>
            <p className="text-sm text-gray-500">#{String(orderId).padStart(6, '0')}</p>
          </div>
          <div className="flex items-center gap-3">
            <p className="text-xs text-gray-400">
              Updated {lastUpdated.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
            </p>
            <button onClick={fetchTracking}
              className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50 text-gray-500 hover:text-orange-500 transition-colors">
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Return reason banner */}
        {isReturnFlow && data.order.returnReason && (
          <div className="bg-pink-50 border border-pink-200 rounded-xl px-4 py-3 mb-5 flex items-start gap-2">
            <RotateCcw className="w-4 h-4 text-pink-500 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold text-pink-700">Return in Progress</p>
              <p className="text-xs text-pink-600 mt-0.5">Reason: {data.order.returnReason}</p>
            </div>
          </div>
        )}

        {/* ── Forward Delivery Progress Bar (always shown) ── */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-5">
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-bold text-gray-800">Shipment Progress</h2>
            <span className="text-xs bg-orange-100 text-orange-600 px-2.5 py-1 rounded-full font-medium capitalize">
              {isReturnFlow ? 'Delivered' : (() => {
                const shipStatus = data?.shipment?.status?.toUpperCase();
                const labelMap: Record<string, string> = {
                  ASSIGNED: 'Partner Assigned', ACCEPTED: 'Partner Assigned',
                  PICKED_UP: 'Picked Up', IN_TRANSIT: 'In Transit',
                  OUT_FOR_DELIVERY: 'Out for Delivery', DELIVERED: 'Delivered',
                };
                return (shipStatus && labelMap[shipStatus]) || orderStatus.replace(/_/g, ' ');
              })()}
            </span>
          </div>
          <div className="relative mt-6 mb-2">
            <div className="absolute top-4 left-0 right-0 h-1 bg-gray-200 rounded-full" />
            <div className="absolute top-4 left-0 h-1 bg-orange-500 rounded-full transition-all duration-700"
              style={{ width: isReturnFlow ? '100%' : (getForwardStepIdx() >= 0 ? `${(getForwardStepIdx() / (FORWARD_STEPS.length - 1)) * 100}%` : '0%') }} />
            <div className="relative flex justify-between">
              {FORWARD_STEPS.map((step, idx) => {
                const fwdIdx = isReturnFlow ? FORWARD_STEPS.length - 1 : getForwardStepIdx();
                const done = idx <= fwdIdx;
                const active = !isReturnFlow && idx === fwdIdx;
                const Icon = step.icon;
                return (
                  <div key={step.key} className="flex flex-col items-center gap-1" style={{ width: `${100 / FORWARD_STEPS.length}%` }}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 transition-all duration-300 ${
                      done ? 'bg-orange-500 text-white shadow-md'
                        : active ? 'bg-orange-200 text-orange-600 ring-2 ring-orange-400'
                        : 'bg-gray-100 text-gray-400'
                    } ${active ? 'scale-110' : ''}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className={`text-[10px] text-center leading-tight mt-1 ${done ? 'text-orange-600 font-medium' : 'text-gray-400'}`}>
                      {step.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
          {/* Forward delivery partner */}
          {!isReturnFlow && forwardPartner && (
            <div className="mt-4 flex items-center gap-3 bg-indigo-50 rounded-xl p-3">
              <div className="w-9 h-9 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0">
                <Truck className="w-5 h-5 text-indigo-500" />
              </div>
              <div>
                <p className="text-xs text-gray-500 font-medium uppercase tracking-wide">Delivery Partner</p>
                <p className="font-semibold text-gray-800 text-sm">{forwardPartner.fullName || forwardPartner.name || '—'}</p>
                <p className="text-xs text-gray-500">{forwardPartner.deliveryPhone || forwardPartner.phone || '—'}</p>
              </div>
            </div>
          )}
        </div>

        {/* ── Return Progress Bar (shown separately below, only when in return flow) ── */}
        {isReturnFlow && (
          <div className="bg-white rounded-2xl shadow-sm p-6 mb-5 border-l-4 border-pink-400">
            <div className="flex items-center justify-between mb-2">
              <h2 className="font-bold text-gray-800 flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-pink-500" /> Return Status
              </h2>
              <span className="text-xs bg-pink-100 text-pink-700 px-2.5 py-1 rounded-full font-medium capitalize">
                {orderStatus.replace(/_/g, ' ')}
              </span>
            </div>
            <div className="relative mt-6 mb-2">
              <div className="absolute top-4 left-0 right-0 h-1 bg-gray-200 rounded-full" />
              <div className="absolute top-4 left-0 h-1 bg-pink-500 rounded-full transition-all duration-700"
                style={{ width: currentStepIdx >= 0 ? `${(currentStepIdx / (activeSteps.length - 1)) * 100}%` : '0%' }} />
              <div className="relative flex justify-between">
                {activeSteps.map((step, idx) => {
                  const done = idx <= currentStepIdx;
                  const active = idx === currentStepIdx;
                  const Icon = step.icon;
                  return (
                    <div key={step.key} className="flex flex-col items-center gap-1" style={{ width: `${100 / activeSteps.length}%` }}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 transition-all duration-300 ${
                        done ? 'bg-pink-500 text-white shadow-md'
                          : active ? 'bg-pink-200 text-pink-600 ring-2 ring-pink-400'
                          : 'bg-gray-100 text-gray-400'
                      } ${active ? 'scale-110' : ''}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className={`text-[10px] text-center leading-tight mt-1 ${done ? 'text-pink-600 font-medium' : 'text-gray-400'}`}>
                        {step.label}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Pickup partner */}
            {returnPartner && (
              <div className="mt-4 flex items-center gap-3 bg-pink-50 rounded-xl p-3">
                <div className="w-9 h-9 rounded-full bg-pink-100 flex items-center justify-center flex-shrink-0">
                  <Truck className="w-5 h-5 text-pink-500" />
                </div>
                <div>
                  <p className="text-xs text-gray-500 font-medium uppercase tracking-wide">Pickup Partner</p>
                  <p className="font-semibold text-gray-800 text-sm">{returnPartner.fullName || '—'}</p>
                  <p className="text-xs text-gray-500">{returnPartner.deliveryPhone || '—'}</p>
                </div>
              </div>
            )}

            {/* Refund info — only show when refund is still in progress */}
            {orderStatus === 'refund_completed' && (
              <div className="mt-4 bg-green-50 border border-green-200 rounded-xl p-3 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                <div>
                  <p className="text-sm font-semibold text-green-700">Refund Completed</p>
                  <p className="text-xs text-green-600">₹{data.order.totalAmount?.toLocaleString('en-IN')} has been refunded to your account.</p>
                </div>
              </div>
            )}
            {orderStatus === 'refund_initiated' && (
              <div className="mt-4 bg-yellow-50 border border-yellow-200 rounded-xl p-3 flex items-center gap-2">
                <Clock className="w-5 h-5 text-yellow-600 flex-shrink-0" />
                <p className="text-sm text-yellow-700">
                  Refund of ₹{data.order.totalAmount?.toLocaleString('en-IN')} is being processed. Allow 5–7 business days.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Tracking History */}
        {allEvents.length > 0 ? (
          <div className="bg-white rounded-2xl shadow-sm p-5">
            <h2 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5 text-orange-500" /> Tracking History
            </h2>
            <div className="space-y-0">
              {allEvents.map((event, idx) => (
                <div key={idx} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className={`w-3 h-3 rounded-full flex-shrink-0 mt-1.5 ${
                      idx === 0
                        ? event.isReturn ? 'bg-pink-500' : 'bg-orange-500'
                        : 'bg-gray-300'
                    }`} />
                    {idx < allEvents.length - 1 && (
                      <div className="w-0.5 flex-1 bg-gray-200 my-1 min-h-[1.5rem]" />
                    )}
                  </div>
                  <div className="pb-4">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-semibold text-gray-800 capitalize">
                        {getCustomerFriendlyLabel(event)}
                      </p>
                      {event.isReturn && (
                        <span className="text-[10px] bg-pink-100 text-pink-600 px-1.5 py-0.5 rounded-full font-medium">RETURN</span>
                      )}
                    </div>
                    <p className="text-xs text-gray-600">{event.message}</p>
                    {event.location && (
                      <p className="text-xs text-gray-400 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3" /> {event.location}
                      </p>
                    )}
                    <p className="text-xs text-gray-400 mt-0.5">{formatDate(event.timestamp)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-sm p-8 text-center text-gray-400">
            <Truck className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="font-medium">No tracking events yet</p>
            <p className="text-sm mt-1">Updates will appear here once your order is shipped.</p>
          </div>
        )}

        <div className="mt-5 text-center">
          <Link to={`/orders/${orderId}`} className="text-orange-500 hover:text-orange-600 font-medium text-sm">
            ← View Order Details
          </Link>
        </div>
      </div>
    </div>
  );
}
