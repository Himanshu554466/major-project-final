import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const CustomerLogin: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirect = searchParams.get('redirect') || '/';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email.trim() || !password.trim()) { setError('Please fill in all fields.'); return; }
    try {
      setLoading(true);
      const res = await api.post('/auth/login', { email, password, role: 'customer' });
      login(res.data.token, res.data.user);
      navigate(redirect);
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message || 'Invalid email or password.';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#EAEDED] flex flex-col items-center pt-8 pb-16 px-4">
      {/* Logo */}
      <Link to="/" className="mb-6">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-[#6d28d9] rounded-md flex items-center justify-center">
            <span className="text-white font-black text-lg">E</span>
          </div>
          <span className="font-black text-2xl text-[#1e1b4b] tracking-tight">Ecom<span className="text-[#6d28d9]">merce</span></span>
        </div>
      </Link>

      {/* Card */}
      <div className="w-full max-w-sm bg-white border border-[#ddd] rounded-lg p-6">
        <h1 className="text-2xl font-medium text-[#0f1111] mb-5">Sign in</h1>

        {error && (
          <div className="mb-4 p-3 bg-[#fff8f0] border border-[#e77600] rounded text-sm text-[#5b21b6] flex items-start gap-2">
            <svg className="w-4 h-4 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-[#0f1111] mb-1">Email or mobile phone number</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30"
              required
            />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-sm font-medium text-[#0f1111]">Password</label>
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full px-3 py-2 pr-10 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30"
                required
              />
              <button type="button" onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#0066c0] hover:text-[#5b21b6] hover:underline">
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>
          </div>
          <button type="submit" disabled={loading}
            className="w-full py-2 bg-[#FFD814] hover:bg-[#7c3aed] border border-[#FCD200] rounded text-sm font-semibold text-[#111] transition-colors disabled:opacity-60">
            {loading ? 'Signing in...' : 'Continue'}
          </button>
        </form>

        <p className="text-xs text-[#555] mt-4 leading-relaxed">
          By continuing, you agree to Ecommerce's{' '}
          <span className="text-[#0066c0] hover:text-[#5b21b6] cursor-pointer hover:underline">Conditions of Use</span>
          {' '}and{' '}
          <span className="text-[#0066c0] hover:text-[#5b21b6] cursor-pointer hover:underline">Privacy Notice</span>.
        </p>

        <div className="mt-5 pt-4 border-t border-[#eee]">
          <p className="text-sm text-[#0f1111]">
            New to Ecommerce?{' '}
            <Link to="/register" className="text-[#0066c0] hover:text-[#5b21b6] hover:underline font-medium">
              Create your Ecommerce account
            </Link>
          </p>
        </div>
      </div>

      {/* Divider */}
      <div className="w-full max-w-sm mt-6 flex items-center gap-3">
        <div className="flex-1 h-px bg-[#ddd]" />
        <span className="text-xs text-[#767676]">Other portals</span>
        <div className="flex-1 h-px bg-[#ddd]" />
      </div>

      <div className="w-full max-w-sm mt-4 grid grid-cols-3 gap-2">
        <Link to="/seller/login"
          className="py-2 border border-[#ddd] rounded text-xs text-center text-[#0066c0] hover:bg-[#f0f0f0] hover:text-[#5b21b6] transition-colors bg-white">
          Seller Login
        </Link>
        <Link to="/delivery/login"
          className="py-2 border border-[#ddd] rounded text-xs text-center text-[#0066c0] hover:bg-[#f0f0f0] hover:text-[#5b21b6] transition-colors bg-white">
          Delivery Login
        </Link>
        <Link to="/admin/login"
          className="py-2 border border-[#ddd] rounded text-xs text-center text-[#0066c0] hover:bg-[#f0f0f0] hover:text-[#5b21b6] transition-colors bg-white">
          Admin Login
        </Link>
      </div>
    </div>
  );
};

export default CustomerLogin;
