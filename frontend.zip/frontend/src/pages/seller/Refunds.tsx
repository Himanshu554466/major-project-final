import { useEffect, useState, useCallback } from 'react';
import {
  RotateCcw, CheckCircle, ChevronLeft, ChevronRight,
  Loader2, AlertCircle, IndianRupee, User, Package,
  Clock, CreditCard, RefreshCw, X,
} from 'lucide-react';
import api from '../../services/api';

interface Customer { id: number; email: string; username?: string; }
interface OrderItem { id: string; quantity: number; price: number; product: { title: string } }

interface RefundOrder {
  id: number;
  status: string;
  paymentStatus: string;
  paymentMethod: string;
  totalAmount: number;
  returnReason?: string;
  createdAt: string;
  updatedAt: string;
  customer: Customer;
  items: OrderItem[];
}

const STATUS_BADGE: Record<string, string> = {
  return_requested: 'bg-pink-100 text-pink-700',
  return_approved:  'bg-orange-100 text-orange-700',
  returned:         'bg-teal-100 text-teal-700',
  refund_initiated: 'bg-yellow-100 text-yellow-700',
  refund_completed: 'bg-green-100 text-green-700',
};

const REFUND_METHODS = [
  { value: 'bank_transfer', label: '🏦 Bank Transfer' },
  { value: 'upi',           label: '📱 UPI' },
  { value: 'razorpay',      label: '💳 Razorpay' },
  { value: 'cash',          label: '💵 Cash' },
  { value: 'wallet',        label: '👛 Wallet Credit' },
];

// ── Process Refund Modal ─────────────────────────────────────────────────────
function ProcessRefundModal({
  order, onClose, onSuccess,
}: { order: RefundOrder; onClose: () => void; onSuccess: () => void }) {
  const [method, setMethod] = useState('bank_transfer');
  const [transactionId, setTransactionId] = useState('');
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleProcess = async () => {
    setSubmitting(true);
    setError('');
    try {
      await api.put(`/seller/orders/${order.id}/process-refund`, { method, transactionId, notes });
      onSuccess();
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
      setError(msg || 'Failed to process refund.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <IndianRupee className="w-5 h-5 text-green-600" />
            <h2 className="text-base font-bold text-gray-900">Process Refund</h2>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-gray-100 text-gray-400">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Summary */}
          <div className="bg-gray-50 rounded-xl p-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">Order</span>
              <span className="font-semibold">#{String(order.id).padStart(6, '0')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Customer</span>
              <span className="font-medium">{order.customer.username || order.customer.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Email</span>
              <span className="text-gray-600 text-xs">{order.customer.email}</span>
            </div>
            {order.returnReason && (
              <div className="flex justify-between">
                <span className="text-gray-500">Return Reason</span>
                <span className="text-gray-700 text-right max-w-[55%] text-xs">{order.returnReason}</span>
              </div>
            )}
            <div className="flex justify-between items-center border-t border-gray-200 pt-2 mt-1">
              <span className="text-gray-500">Refund Amount</span>
              <span className="text-xl font-bold text-green-600">₹{order.totalAmount.toLocaleString('en-IN')}</span>
            </div>
          </div>

          {/* Method */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Refund Method *</label>
            <div className="grid grid-cols-2 gap-2">
              {REFUND_METHODS.map(m => (
                <label key={m.value} className={`flex items-center gap-2 p-3 rounded-xl border-2 cursor-pointer text-sm transition-colors ${
                  method === m.value ? 'border-green-500 bg-green-50' : 'border-gray-200 hover:border-green-200'
                }`}>
                  <input type="radio" name="method" value={m.value} checked={method === m.value}
                    onChange={() => setMethod(m.value)} className="accent-green-500" />
                  {m.label}
                </label>
              ))}
            </div>
          </div>

          {/* Transaction ID */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Transaction ID / Reference <span className="text-gray-400 font-normal">(optional)</span>
            </label>
            <input type="text" value={transactionId} onChange={e => setTransactionId(e.target.value)}
              placeholder="e.g. UTR123456789 or TXN..."
              className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-400" />
          </div>

          {/* Note */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Note to Customer <span className="text-gray-400 font-normal">(optional)</span>
            </label>
            <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2}
              placeholder="e.g. Refund sent to your UPI. Please allow 1-2 days."
              className="w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-400 resize-none" />
          </div>

          {error && (
            <p className="text-sm text-red-500 flex items-center gap-1">
              <AlertCircle className="w-4 h-4" /> {error}
            </p>
          )}
        </div>

        <div className="flex gap-3 px-6 py-4 border-t border-gray-100">
          <button onClick={onClose}
            className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50">
            Cancel
          </button>
          <button onClick={handleProcess} disabled={submitting}
            className="flex-1 py-2.5 bg-green-600 hover:bg-green-700 text-white rounded-xl text-sm font-semibold disabled:opacity-50 flex items-center justify-center gap-2">
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
            {submitting ? 'Processing...' : `Confirm Refund ₹${order.totalAmount.toLocaleString('en-IN')}`}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Component ───────────────────────────────────────────────────────────
export default function SellerRefunds() {
  const [orders, setOrders] = useState<RefundOrder[]>([]);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('returned');
  const [loading, setLoading] = useState(true);
  const [processOrder, setProcessOrder] = useState<RefundOrder | null>(null);
  const [initiatingId, setInitiatingId] = useState<number | null>(null);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  const showToast = (type: 'success' | 'error', msg: string) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 4000);
  };

  const fetchOrders = useCallback(() => {
    setLoading(true);
    // Use seller orders endpoint filtered by return/refund statuses
    const statusMap: Record<string, string> = {
      returned: 'returned',
      refund_initiated: 'refund_initiated',
      refund_completed: 'refund_completed',
      all: '',
    };
    const statusParam = statusMap[statusFilter] ?? statusFilter;
    const params = new URLSearchParams({ page: String(page), limit: '15' });
    if (statusParam) params.set('status', statusParam);
    api.get(`/seller/orders?${params}`)
      .then(res => {
        setOrders(res.data.orders || []);
        setTotal(res.data.total || 0);
        setPages(res.data.pages || 1);
      })
      .catch(() => setOrders([]))
      .finally(() => setLoading(false));
  }, [page, statusFilter]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);

  const handleInitiateRefund = async (orderId: number) => {
    setInitiatingId(orderId);
    try {
      await api.put(`/seller/orders/${orderId}/initiate-refund`);
      showToast('success', 'Refund initiated. Customer has been notified.');
      fetchOrders();
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
      showToast('error', msg || 'Failed to initiate refund.');
    } finally {
      setInitiatingId(null);
    }
  };

  const handleProcessSuccess = () => {
    setProcessOrder(null);
    showToast('success', 'Refund processed! Customer has been notified via email.');
    fetchOrders();
  };

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

  // Stats
  const pendingCount = orders.filter(o => o.status === 'returned').length;
  const initiatedCount = orders.filter(o => o.status === 'refund_initiated').length;

  return (
    <div className="p-6 space-y-6">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.type === 'success' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'
        }`}>
          {toast.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {toast.msg}
        </div>
      )}

      {/* Process Modal */}
      {processOrder && (
        <ProcessRefundModal order={processOrder} onClose={() => setProcessOrder(null)} onSuccess={handleProcessSuccess} />
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <RotateCcw className="w-6 h-6 text-indigo-600" /> Refunds
          </h1>
          <p className="text-gray-500 text-sm mt-1">Process refunds for returned orders</p>
        </div>
        <button onClick={fetchOrders} disabled={loading}
          className="flex items-center gap-1.5 px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50 disabled:opacity-50">
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
        </button>
      </div>

      {/* Quick stats */}
      {(pendingCount > 0 || initiatedCount > 0) && (
        <div className="grid grid-cols-2 gap-4">
          {pendingCount > 0 && (
            <div className="bg-teal-50 border border-teal-200 rounded-xl p-4">
              <p className="text-xs font-semibold text-teal-600 uppercase tracking-wider">Awaiting Refund</p>
              <p className="text-3xl font-bold text-teal-700 mt-1">{pendingCount}</p>
              <p className="text-xs text-teal-600 mt-1">Items returned, refund not started</p>
            </div>
          )}
          {initiatedCount > 0 && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
              <p className="text-xs font-semibold text-yellow-600 uppercase tracking-wider">Refund In Progress</p>
              <p className="text-3xl font-bold text-yellow-700 mt-1">{initiatedCount}</p>
              <p className="text-xs text-yellow-600 mt-1">Initiated, awaiting confirmation</p>
            </div>
          )}
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-2 flex-wrap">
        {[
          { value: 'returned',         label: '↩ Returned' },
          { value: 'refund_initiated', label: '⏳ Initiated' },
          { value: 'refund_completed', label: '✅ Completed' },
          { value: 'all',              label: 'All Returns' },
        ].map(f => (
          <button key={f.value} onClick={() => { setStatusFilter(f.value); setPage(1); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              statusFilter === f.value ? 'bg-indigo-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
            }`}>
            {f.label}
          </button>
        ))}
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex items-center justify-center h-48">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-16 bg-white border border-gray-200 rounded-xl">
          <RotateCcw className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="text-sm text-gray-400">No refund orders found</p>
          <p className="text-xs text-gray-400 mt-1">Returned orders will appear here</p>
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Order</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Customer</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Items</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Amount</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Status</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Date</th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {orders.map(order => (
                  <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <p className="font-mono text-xs text-gray-600">#{String(order.id).padStart(6, '0')}</p>
                      {order.returnReason && (
                        <p className="text-xs text-pink-600 mt-0.5 max-w-[120px] truncate" title={order.returnReason}>
                          ↩ {order.returnReason}
                        </p>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
                          <User className="w-3.5 h-3.5 text-gray-400" />
                        </div>
                        <div>
                          <p className="text-xs font-medium text-gray-800">{order.customer.username || '—'}</p>
                          <p className="text-xs text-gray-400">{order.customer.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <Package className="w-3.5 h-3.5 text-gray-400" />
                        <span className="text-xs text-gray-600">{order.items?.length || 0} item(s)</span>
                      </div>
                      <p className="text-xs text-gray-400 mt-0.5 max-w-[120px] truncate">
                        {order.items?.[0]?.product?.title}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="font-bold text-gray-900">₹{order.totalAmount.toLocaleString('en-IN')}</p>
                      <div className="flex items-center gap-1 mt-0.5">
                        <CreditCard className="w-3 h-3 text-gray-400" />
                        <span className={`text-xs font-medium capitalize ${
                          order.paymentStatus === 'refunded' ? 'text-green-600' :
                          order.paymentStatus === 'paid' ? 'text-blue-600' : 'text-gray-500'
                        }`}>{order.paymentStatus}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize ${STATUS_BADGE[order.status] || 'bg-gray-100 text-gray-600'}`}>
                        {order.status.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Clock className="w-3 h-3" />
                        {formatDate(order.updatedAt)}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-2">
                        {/* Step 1: Initiate refund — only after item delivered back to seller */}
                        {order.status === 'returned' && (
                          <button
                            onClick={() => handleInitiateRefund(order.id)}
                            disabled={initiatingId === order.id}
                            className="flex items-center gap-1 px-3 py-1.5 bg-yellow-500 hover:bg-yellow-600 text-white text-xs font-semibold rounded-lg disabled:opacity-50"
                          >
                            {initiatingId === order.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <RotateCcw className="w-3 h-3" />}
                            Initiate
                          </button>
                        )}
                        {/* Step 2: Process refund (mark money as sent) */}
                        {['returned', 'refund_initiated'].includes(order.status) && (
                          <button
                            onClick={() => setProcessOrder(order)}
                            className="flex items-center gap-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-semibold rounded-lg"
                          >
                            <IndianRupee className="w-3 h-3" /> Process
                          </button>
                        )}
                        {order.status === 'refund_completed' && (
                          <span className="flex items-center gap-1 text-xs text-green-600 font-medium">
                            <CheckCircle className="w-3.5 h-3.5" /> Done
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Pagination */}
      {pages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-500">Page {page} of {pages} ({total} total)</p>
          <div className="flex gap-2">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button onClick={() => setPage(p => Math.min(pages, p + 1))} disabled={page === pages}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
