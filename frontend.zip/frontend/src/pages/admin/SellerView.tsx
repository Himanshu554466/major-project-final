import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  ArrowLeft, Store, Package, ShoppingCart, IndianRupee,
  Mail, Calendar, MapPin, Phone, AlertCircle, Loader2, ExternalLink,
  Clock, CheckCircle, XCircle, Box
} from "lucide-react";
import API from "../../services/api";

interface SellerStats {
  totalProducts: number;
  activeProducts: number;
  totalOrders: number;
  pendingOrders: number;
  deliveredOrders: number;
  cancelledOrders: number;
  revenue: number;
}

interface SellerInfo {
  id: number;
  email: string;
  shopName: string;
  fullName?: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  status: string;
  createdAt: string;
}

interface Product {
  id: number;
  title: string;
  price: number;
  stock: number;
  status: string;
  createdAt: string;
}

interface Order {
  id: number;
  customer: { email: string };
  totalAmount: number;
  status: string;
  createdAt: string;
}

interface SellerData {
  seller: SellerInfo;
  stats: SellerStats;
  recentProducts: Product[];
  recentOrders: Order[];
}

const statusColors: Record<string, string> = {
  active: "bg-green-100 text-green-700",
  draft: "bg-gray-100 text-gray-600",
  inactive: "bg-gray-100 text-gray-600",
  placed: "bg-blue-100 text-blue-700",
  confirmed: "bg-indigo-100 text-indigo-700",
  preparing: "bg-yellow-100 text-yellow-700",
  shipped: "bg-purple-100 text-purple-700",
  delivered: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
  rejected: "bg-red-100 text-red-700",
};

export default function AdminSellerView() {
  const { sellerId } = useParams<{ sellerId: string }>();
  const navigate = useNavigate();
  const [data, setData] = useState<SellerData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!sellerId) return;
    
    setLoading(true);
    setError("");
    
    API.get<SellerData>(`/admin/sellers/${sellerId}`)
      .then(res => setData(res.data))
      .catch(() => setError("Failed to load seller data."))
      .finally(() => setLoading(false));
  }, [sellerId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="w-10 h-10 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-6xl mx-auto py-8 px-4">
        <div className="bg-red-50 border border-red-200 rounded-xl p-6 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
          <div>
            <p className="font-semibold text-red-800">{error || "Seller not found"}</p>
            <button onClick={() => navigate("/admin/users")} className="text-sm text-red-600 hover:text-red-800 mt-1">
              ← Back to Users
            </button>
          </div>
        </div>
      </div>
    );
  }

  const { seller, stats, recentProducts, recentOrders } = data;

  const statCards = [
    { label: "Total Products", value: stats.totalProducts, icon: Package, color: "bg-indigo-50 text-indigo-600", border: "border-indigo-200" },
    { label: "Active Products", value: stats.activeProducts, icon: Box, color: "bg-blue-50 text-blue-600", border: "border-blue-200" },
    { label: "Total Orders", value: stats.totalOrders, icon: ShoppingCart, color: "bg-orange-50 text-orange-600", border: "border-orange-200" },
    { label: "Pending Orders", value: stats.pendingOrders, icon: Clock, color: "bg-yellow-50 text-yellow-600", border: "border-yellow-200" },
    { label: "Delivered", value: stats.deliveredOrders, icon: CheckCircle, color: "bg-green-50 text-green-600", border: "border-green-200" },
    { label: "Cancelled", value: stats.cancelledOrders, icon: XCircle, color: "bg-red-50 text-red-600", border: "border-red-200" },
    { label: "Total Revenue", value: `₹${stats.revenue.toLocaleString("en-IN")}`, icon: IndianRupee, color: "bg-purple-50 text-purple-600", border: "border-purple-200", span: true },
  ];

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate("/admin/users")} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <Store className="w-6 h-6 text-indigo-600" />
              {seller.shopName}
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">Seller Profile & Analytics</p>
          </div>
        </div>
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusColors[seller.status] || "bg-gray-100 text-gray-600"}`}>
          {seller.status}
        </span>
      </div>

      {/* Seller Info Card */}
      <div className="bg-white border border-gray-200 rounded-xl p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Seller Information</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="flex items-start gap-3">
            <Mail className="w-4 h-4 text-gray-400 mt-0.5" />
            <div>
              <p className="text-xs text-gray-500">Email</p>
              <p className="text-sm font-medium text-gray-900">{seller.email}</p>
            </div>
          </div>
          {seller.fullName && (
            <div className="flex items-start gap-3">
              <Store className="w-4 h-4 text-gray-400 mt-0.5" />
              <div>
                <p className="text-xs text-gray-500">Full Name</p>
                <p className="text-sm font-medium text-gray-900">{seller.fullName}</p>
              </div>
            </div>
          )}
          {seller.phone && (
            <div className="flex items-start gap-3">
              <Phone className="w-4 h-4 text-gray-400 mt-0.5" />
              <div>
                <p className="text-xs text-gray-500">Phone</p>
                <p className="text-sm font-medium text-gray-900">{seller.phone}</p>
              </div>
            </div>
          )}
          {seller.address && (
            <div className="flex items-start gap-3">
              <MapPin className="w-4 h-4 text-gray-400 mt-0.5" />
              <div>
                <p className="text-xs text-gray-500">Address</p>
                <p className="text-sm font-medium text-gray-900">
                  {seller.address}
                  {seller.city && `, ${seller.city}`}
                  {seller.state && `, ${seller.state}`}
                  {seller.pincode && ` - ${seller.pincode}`}
                </p>
              </div>
            </div>
          )}
          <div className="flex items-start gap-3">
            <Calendar className="w-4 h-4 text-gray-400 mt-0.5" />
            <div>
              <p className="text-xs text-gray-500">Joined</p>
              <p className="text-sm font-medium text-gray-900">
                {new Date(seller.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className={`bg-white rounded-xl border ${card.border} p-5 flex items-center gap-4 shadow-sm ${card.span ? 'lg:col-span-1' : ''}`}
            >
              <div className={`p-3 rounded-lg ${card.color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-gray-500">{card.label}</p>
                <p className="text-xl font-bold text-gray-900">{card.value}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Products */}
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h2 className="text-base font-semibold text-gray-800">Recent Products</h2>
            <Link to={`/admin/products?seller=${sellerId}`} className="text-sm text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-1">
              View all <ExternalLink className="w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-gray-100">
            {recentProducts.length === 0 ? (
              <p className="px-6 py-8 text-center text-gray-400 text-sm">No products yet</p>
            ) : (
              recentProducts.map((product) => (
                <div key={product.id} className="px-6 py-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-gray-900 truncate">{product.title}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <p className="text-xs text-gray-500">₹{product.price.toLocaleString("en-IN")}</p>
                        <p className="text-xs text-gray-500">Stock: {product.stock}</p>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors[product.status] || "bg-gray-100 text-gray-600"}`}>
                          {product.status}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Orders */}
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h2 className="text-base font-semibold text-gray-800">Recent Orders</h2>
            <Link to={`/admin/orders?seller=${sellerId}`} className="text-sm text-indigo-600 hover:text-indigo-800 font-medium flex items-center gap-1">
              View all <ExternalLink className="w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-gray-100">
            {recentOrders.length === 0 ? (
              <p className="px-6 py-8 text-center text-gray-400 text-sm">No orders yet</p>
            ) : (
              recentOrders.map((order) => (
                <div key={order.id} className="px-6 py-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-gray-900">Order #{order.id}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <p className="text-xs text-gray-500 truncate">{order.customer.email}</p>
                        <p className="text-xs font-semibold text-gray-700">₹{order.totalAmount.toLocaleString("en-IN")}</p>
                      </div>
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium whitespace-nowrap ${statusColors[order.status] || "bg-gray-100 text-gray-600"}`}>
                      {order.status}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
