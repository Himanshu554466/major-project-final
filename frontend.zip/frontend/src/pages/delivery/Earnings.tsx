import { useEffect, useState, useCallback } from "react";
import {
  IndianRupee,
  Calendar,
  Loader2,
  AlertCircle,
  TrendingUp,
  MapPin,
  User,
} from "lucide-react";
import API from "../../services/api";

interface EarningDelivery {
  id: number;
  status: string;
  earnings: number;
  updatedAt: string;
  dropAddress: string;
  customerName: string;
  dropCity?: string;
}

interface EarningsResponse {
  totalEarnings: number;
  deliveries: EarningDelivery[];
}

export default function Earnings() {
  const [data, setData] = useState<EarningsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  const fetchEarnings = useCallback(() => {
    setLoading(true);
    setError("");
    const params = new URLSearchParams();
    if (fromDate) params.set("from", fromDate);
    if (toDate) params.set("to", toDate);
    API.get<EarningsResponse>(`/delivery/earnings?${params}`)
      .then((res) => setData(res.data))
      .catch(() => setError("Failed to load earnings data."))
      .finally(() => setLoading(false));
  }, [fromDate, toDate]);

  useEffect(() => {
    fetchEarnings();
  }, [fetchEarnings]);

  // Group by month when no date filter
  const monthlyGroups = (() => {
    if (!data?.deliveries || fromDate || toDate) return null;
    const groups: Record<string, { earnings: number; count: number }> = {};
    data.deliveries.forEach((d) => {
      const key = new Date(d.updatedAt).toLocaleDateString("en-IN", {
        month: "long",
        year: "numeric",
      });
      if (!groups[key]) groups[key] = { earnings: 0, count: 0 };
      groups[key].earnings += d.earnings || 0;
      groups[key].count += 1;
    });
    return groups;
  })();

  const handleClearFilter = () => {
    setFromDate("");
    setToDate("");
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
          <IndianRupee className="w-5 h-5 text-green-700" />
          Earnings
        </h1>
        <p className="text-sm text-gray-400 mt-0.5">Track your delivery earnings</p>
      </div>

      {/* Date Filter */}
      <div className="bg-white border border-gray-200 rounded-xl p-4 mb-6">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">From</label>
            <div className="relative">
              <Calendar className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="pl-8 pr-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">To</label>
            <div className="relative">
              <Calendar className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="pl-8 pr-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>
          {(fromDate || toDate) && (
            <button
              onClick={handleClearFilter}
              className="text-sm text-gray-500 hover:text-gray-700 px-3 py-2 border border-gray-200 rounded-lg hover:bg-gray-50"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-48">
          <Loader2 className="w-8 h-8 animate-spin text-green-600" />
        </div>
      ) : error ? (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-2 text-red-700 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {error}
        </div>
      ) : (
        <>
          {/* Total Earnings Card */}
          <div className="bg-linear-to-br from-green-700 to-green-800 rounded-2xl p-6 mb-6 text-white">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-5 h-5 opacity-80" />
              <span className="text-sm font-medium opacity-80">
                {fromDate || toDate ? "Filtered Earnings" : "Total Earnings"}
              </span>
            </div>
            <div className="flex items-end gap-1">
              <span className="text-4xl font-bold">
                ₹{(data?.totalEarnings || 0).toLocaleString("en-IN")}
              </span>
            </div>
            <p className="text-xs opacity-60 mt-1">
              {data?.deliveries?.length ?? 0} deliveries
            </p>
          </div>

          {/* Monthly Summary (when no filter) */}
          {monthlyGroups && Object.keys(monthlyGroups).length > 0 && (
            <div className="bg-white border border-gray-200 rounded-xl p-5 mb-6">
              <h2 className="text-sm font-semibold text-gray-700 mb-4">Monthly Summary</h2>
              <div className="space-y-3">
                {Object.entries(monthlyGroups).map(([month, stats]) => (
                  <div
                    key={month}
                    className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0"
                  >
                    <div>
                      <p className="text-sm font-medium text-gray-800">{month}</p>
                      <p className="text-xs text-gray-400">{stats.count} deliveries</p>
                    </div>
                    <span className="text-sm font-semibold text-green-700">
                      ₹{stats.earnings.toLocaleString("en-IN")}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Deliveries List */}
          {data?.deliveries && data.deliveries.length > 0 ? (
            <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
              <div className="px-5 py-3 border-b border-gray-100 bg-gray-50">
                <h2 className="text-sm font-semibold text-gray-700">Delivery Breakdown</h2>
              </div>

              {/* Desktop Table */}
              <div className="hidden md:block">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-100">
                      <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        Customer
                      </th>
                      <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        City
                      </th>
                      <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        Earnings
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-50">
                    {data.deliveries.map((delivery) => (
                      <tr key={delivery.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-4 py-3 text-gray-600">
                          {new Date(delivery.updatedAt).toLocaleDateString("en-IN", {
                            day: "numeric",
                            month: "short",
                            year: "numeric",
                          })}
                        </td>
                        <td className="px-4 py-3 font-medium text-gray-800">
                          {delivery.customerName}
                        </td>
                        <td className="px-4 py-3 text-gray-600">
                          {delivery.dropCity || "—"}
                        </td>
                        <td className="px-4 py-3 text-right font-semibold text-green-700">
                          ₹{(delivery.earnings || 0).toLocaleString("en-IN")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile Cards */}
              <div className="md:hidden divide-y divide-gray-50">
                {data.deliveries.map((delivery) => (
                  <div key={delivery.id} className="px-4 py-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-1.5 mb-1">
                          <User className="w-3.5 h-3.5 text-gray-400" />
                          <span className="text-sm font-medium text-gray-800">
                            {delivery.customerName}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-gray-400" />
                          <span className="text-xs text-gray-500">
                            {delivery.dropCity || delivery.dropAddress}
                          </span>
                        </div>
                        <p className="text-xs text-gray-400 mt-1">
                          {new Date(delivery.updatedAt).toLocaleDateString("en-IN", {
                            day: "numeric",
                            month: "short",
                            year: "numeric",
                          })}
                        </p>
                      </div>
                      <span className="text-sm font-semibold text-green-700">
                        ₹{(delivery.earnings || 0).toLocaleString("en-IN")}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-16 bg-white border border-gray-200 rounded-xl">
              <IndianRupee className="w-12 h-12 text-gray-200 mx-auto mb-3" />
              <p className="text-sm text-gray-400">No earnings data for this period</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
