import React from 'react';
import { Link } from 'react-router-dom';
import {
  Store,
  Truck,
  User,
  ArrowRight,
  Facebook,
  Twitter,
  Instagram,
  Mail,
  Phone,
  MapPin,
} from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* Portal Access Section - The Key Feature */}
      <div className="bg-gray-800 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h2 className="text-center text-white text-xl font-bold mb-2">Join Ecommerce</h2>
          <p className="text-center text-gray-400 text-sm mb-8">
            Choose your role and get started today
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Seller Panel */}
            <div className="bg-indigo-900 border border-indigo-700 rounded-2xl p-6 hover:border-indigo-500 transition-colors">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center">
                  <Store size={24} className="text-white" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">Are you a Seller?</h3>
                  <p className="text-indigo-300 text-xs">Grow your business online</p>
                </div>
              </div>
              <p className="text-indigo-200 text-sm mb-5">
                List your products, manage inventory, track orders, and grow your business with
                Ecommerce's seller platform.
              </p>
              <div className="space-y-2">
                <Link
                  to="/seller/register"
                  className="flex items-center justify-between w-full bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2.5 rounded-lg font-medium text-sm transition-colors"
                >
                  <span>Start Selling</span>
                  <ArrowRight size={16} />
                </Link>
                <Link
                  to="/seller/login"
                  className="flex items-center justify-between w-full border border-indigo-600 hover:bg-indigo-800 text-indigo-300 px-4 py-2.5 rounded-lg font-medium text-sm transition-colors"
                >
                  <span>Seller Login</span>
                  <ArrowRight size={16} />
                </Link>
              </div>
            </div>

            {/* Delivery Partner Panel */}
            <div className="bg-green-900 border border-green-700 rounded-2xl p-6 hover:border-green-500 transition-colors">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center">
                  <Truck size={24} className="text-white" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">Delivery Partner?</h3>
                  <p className="text-green-300 text-xs">Earn on your own schedule</p>
                </div>
              </div>
              <p className="text-green-200 text-sm mb-5">
                Join our delivery network, manage shipments, track earnings and deliver smiles to
                customers across India.
              </p>
              <div className="space-y-2">
                <Link
                  to="/delivery/register"
                  className="flex items-center justify-between w-full bg-green-600 hover:bg-green-500 text-white px-4 py-2.5 rounded-lg font-medium text-sm transition-colors"
                >
                  <span>Become a Partner</span>
                  <ArrowRight size={16} />
                </Link>
                <Link
                  to="/delivery/login"
                  className="flex items-center justify-between w-full border border-green-600 hover:bg-green-800 text-green-300 px-4 py-2.5 rounded-lg font-medium text-sm transition-colors"
                >
                  <span>Partner Login</span>
                  <ArrowRight size={16} />
                </Link>
              </div>
            </div>

            {/* Customer Panel */}
            <div className="bg-orange-900 border border-orange-700 rounded-2xl p-6 hover:border-orange-500 transition-colors">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-12 bg-orange-600 rounded-xl flex items-center justify-center">
                  <User size={24} className="text-white" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg">Already Have Account?</h3>
                  <p className="text-orange-300 text-xs">Continue shopping</p>
                </div>
              </div>
              <p className="text-orange-200 text-sm mb-5">
                Access your orders, wishlist, and exclusive deals. Sign in to continue your
                Ecommerce shopping journey.
              </p>
              <div className="space-y-2">
                <Link
                  to="/register"
                  className="flex items-center justify-between w-full bg-orange-600 hover:bg-orange-500 text-white px-4 py-2.5 rounded-lg font-medium text-sm transition-colors"
                >
                  <span>Create Account</span>
                  <ArrowRight size={16} />
                </Link>
                <Link
                  to="/login"
                  className="flex items-center justify-between w-full border border-orange-600 hover:bg-orange-800 text-orange-300 px-4 py-2.5 rounded-lg font-medium text-sm transition-colors"
                >
                  <span>Customer Login</span>
                  <ArrowRight size={16} />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">S</span>
              </div>
              <span className="text-xl font-bold text-orange-400">Ecommerce</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-4">
              India's most trusted e-commerce platform. Connecting buyers, sellers, and delivery
              partners across the nation.
            </p>
            <div className="flex space-x-3">
              <a href="#" className="text-gray-400 hover:text-orange-400 transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-400 transition-colors">
                <Twitter size={18} />
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-400 transition-colors">
                <Instagram size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {[
                { label: 'Home', to: '/' },
                { label: 'Products', to: '/products' },
                { label: 'My Orders', to: '/orders' },
                { label: 'My Cart', to: '/cart' },
                { label: 'Wishlist', to: '/wishlist' },
              ].map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-gray-400 hover:text-orange-400 text-sm transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-white font-semibold mb-4">Categories</h4>
            <ul className="space-y-2">
              {[
                'Electronics',
                'Fashion',
                'Home & Kitchen',
                'Sports',
                'Books',
                'Groceries',
              ].map((cat) => (
                <li key={cat}>
                  <Link
                    to={`/products?category=${encodeURIComponent(cat)}`}
                    className="text-gray-400 hover:text-orange-400 text-sm transition-colors"
                  >
                    {cat}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-semibold mb-4">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2 text-sm text-gray-400">
                <MapPin size={14} className="mt-0.5 flex-shrink-0 text-orange-400" />
                <span>123 Commerce Street, Bangalore, Karnataka 560001</span>
              </li>
              <li className="flex items-center space-x-2 text-sm text-gray-400">
                <Phone size={14} className="text-orange-400" />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex items-center space-x-2 text-sm text-gray-400">
                <Mail size={14} className="text-orange-400" />
                <span>support@ecommerce.com</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-gray-500 text-xs">
            &copy; {new Date().getFullYear()} Ecommerce. All rights reserved.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="text-gray-500 hover:text-gray-300 text-xs">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-500 hover:text-gray-300 text-xs">
              Terms of Service
            </a>
            <a href="#" className="text-gray-500 hover:text-gray-300 text-xs">
              Refund Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
