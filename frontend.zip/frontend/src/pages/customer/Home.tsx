import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../../services/api';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';

interface Variant { id: string; price: number; color?: string; size?: string; stock: number; }
interface ProductImage { id: string; url: string; }
interface Product {
  id: string; title: string; category: string; brand: string;
  deliveryCharge: number; freeDeliveryAbove: number;
  variants: Variant[]; images: ProductImage[];
}

// ── Hero Carousel ──────────────────────────────────────────────────────────
const SLIDES = [
  { bg: 'from-[#232f3e] to-[#37475a]', tag: 'Great Indian Festival', title: 'Deals You Cannot Miss', sub: 'Up to 70% off · Electronics, Fashion, Home & more', cta: 'Shop Now', link: '/products', emoji: '🎉' },
  { bg: 'from-[#0f3460] to-[#16213e]', tag: 'New Arrivals', title: 'Latest Smartphones & Laptops', sub: 'Starting at just ₹9,999', cta: 'Explore Electronics', link: '/products?category=Electronics', emoji: '📱' },
  { bg: 'from-[#1a472a] to-[#2d6a4f]', tag: 'Fashion Week', title: 'Style That Speaks', sub: 'Top brands · Nike, Adidas, Levi\'s & more', cta: 'Shop Fashion', link: '/products?category=Fashion', emoji: '👗' },
];

function HeroCarousel() {
  const [current, setCurrent] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setCurrent(c => (c + 1) % SLIDES.length), 4200);
    return () => clearInterval(t);
  }, []);
  const slide = SLIDES[current];
  return (
    <div className="relative h-[320px] md:h-[400px] overflow-hidden">
      <div className={`absolute inset-0 bg-gradient-to-r ${slide.bg} transition-all duration-700`} />
      <div className="relative max-w-[1500px] mx-auto h-full px-8 flex items-center z-10">
        <div className="max-w-lg text-white">
          <span className="inline-block text-xs font-bold tracking-widest bg-white/20 text-white px-5 py-2 rounded-3xl mb-4">{slide.tag}</span>
          <h1 className="text-4xl md:text-5xl font-black leading-tight tracking-tight mb-4">{slide.title}</h1>
          <p className="text-lg mb-8 opacity-90">{slide.sub}</p>
          <Link to={slide.link}
            className="inline-flex items-center px-8 py-3.5 bg-[#6d28d9] text-[#0f1111] font-bold text-base rounded-3xl hover:bg-[#7c3aed] transition-all active:scale-95">
            {slide.cta}
          </Link>
        </div>
        <div className="hidden xl:block ml-auto text-[180px] leading-none select-none">{slide.emoji}</div>
      </div>
      {/* Dots */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-3">
        {SLIDES.map((_, i) => (
          <button key={i} onClick={() => setCurrent(i)}
            className={`h-2.5 rounded-3xl transition-all ${i === current ? 'w-8 bg-[#6d28d9]' : 'w-2.5 bg-white/60'}`} />
        ))}
      </div>
    </div>
  );
}

// ── Star Rating ────────────────────────────────────────────────────────────
function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(s => (
        <svg key={s} className={`w-3.5 h-3.5 ${s <= Math.round(rating) ? 'text-[#6d28d9]' : 'text-[#ddd]'}`} fill="currentColor" viewBox="0 0 20 20">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
    </div>
  );
}

// ── Product Card ───────────────────────────────────────────────────────────
function ProductCard({ product, onAddToCart, addingId }: { product: Product; onAddToCart: (p: Product) => void; addingId: string | null }) {
  const minPrice = product.variants?.length ? Math.min(...product.variants.map(v => v.price)) : 0;
  const mrp = minPrice ? Math.round(minPrice * 1.3) : 0;
  const discountPct = mrp ? Math.round(((mrp - minPrice) / mrp) * 100) : 0;
  const inStock = product.variants?.some(v => v.stock > 0) ?? false;
  const image = product.images?.[0]?.url;
  const rating = 4.1 + ((parseInt(product.id) * 7) % 10) / 10 * 0.8;
  const reviewCount = 1200 + (parseInt(product.id) * 37) % 4800;

  return (
    <div className="group bg-white border border-[#ddd] rounded-lg hover:shadow-lg transition-shadow duration-200 relative overflow-hidden flex flex-col">
      {discountPct > 0 && inStock && (
        <div className="absolute top-2.5 left-2.5 z-10 bg-[#CC0C39] text-white text-[11px] font-bold px-2 py-0.5 rounded">
          -{discountPct}%
        </div>
      )}
      <Link to={`/products/${product.id}`} className="block">
        <div className="aspect-square bg-white flex items-center justify-center p-4 border-b border-[#f0f0f0] overflow-hidden">
          {image ? (
            <img src={image} alt={product.title}
              className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-300" />
          ) : (
            <span className="text-5xl text-[#ddd]">📦</span>
          )}
          {!inStock && (
            <div className="absolute inset-0 bg-white/80 flex items-center justify-center">
              <span className="text-xs font-bold text-[#CC0C39] bg-white px-3 py-1.5 border border-[#CC0C39] rounded">OUT OF STOCK</span>
            </div>
          )}
        </div>
      </Link>
      <div className="p-3.5 flex flex-col flex-1">
        {product.brand && <p className="text-[#0066c0] text-xs mb-0.5 truncate font-medium">{product.brand}</p>}
        <Link to={`/products/${product.id}`}>
          <p className="text-[#0f1111] text-sm leading-snug line-clamp-2 min-h-[2.5rem] mb-1.5 hover:text-[#5b21b6]">{product.title}</p>
        </Link>
        <div className="mb-2 flex items-center gap-1.5">
          <Stars rating={rating} />
          <span className="text-xs text-[#0066c0]">({reviewCount.toLocaleString('en-IN')})</span>
        </div>
        {minPrice > 0 && (
          <div className="mb-1">
            <div className="flex items-baseline gap-1.5 flex-wrap">
              <span className="text-xl font-bold text-[#B12704]">₹{minPrice.toLocaleString('en-IN')}</span>
            </div>
            {mrp > 0 && (
              <p className="text-xs text-[#565959]">M.R.P: <span className="line-through">₹{mrp.toLocaleString('en-IN')}</span></p>
            )}
          </div>
        )}
        <p className="text-[#007600] text-xs mb-3">
          {product.deliveryCharge === 0 ? 'FREE Delivery' : `₹${product.deliveryCharge} delivery`}
        </p>
        <div className="mt-auto">
          {inStock ? (
            <button
              onClick={() => onAddToCart(product)}
              disabled={addingId === product.id}
              className="w-full py-2 text-sm font-semibold rounded border transition-all bg-[#FFD814] hover:bg-[#7c3aed] border-[#FCD200] text-[#111] active:bg-[#F0C000] disabled:opacity-60"
            >
              {addingId === product.id ? '✓ Adding...' : 'Add to Cart'}
            </button>
          ) : (
            <button disabled className="w-full py-2 text-sm font-semibold rounded border bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed">
              Out of Stock
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Category Card ──────────────────────────────────────────────────────────
const CATEGORIES = [
  { name: 'Electronics', emoji: '📱' }, { name: 'Fashion', emoji: '👗' },
  { name: 'Home & Kitchen', emoji: '🏠' }, { name: 'Sports & Outdoors', emoji: '⚽' },
  { name: 'Books', emoji: '📚' }, { name: 'Groceries', emoji: '🛒' },
  { name: 'Beauty & Personal Care', emoji: '💄' }, { name: 'Toys & Games', emoji: '🎮' },
  { name: 'Automotive', emoji: '🚗' }, { name: 'Health & Wellness', emoji: '💊' },
];

// ── Main Component ─────────────────────────────────────────────────────────
export default function Home() {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { isAuthenticated, user } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [addingId, setAddingId] = useState<string | null>(null);

  useEffect(() => {
    api.get('/customer/products?limit=12')
      .then(res => setProducts(res.data.products || []))
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, []);

  const handleAddToCart = async (product: Product) => {
    if (!isAuthenticated) { navigate('/login'); return; }
    setAddingId(product.id);
    try {
      const variantId = product.variants?.[0]?.id;
      await addToCart(product.id, variantId, 1);
    } catch { /* ignore */ }
    finally { setAddingId(null); }
  };

  const Skeleton = () => (
    <div className="bg-white border border-[#ddd] rounded-lg animate-pulse">
      <div className="aspect-square bg-[#f3f3f3] rounded-t-lg" />
      <div className="p-3 space-y-2">
        <div className="h-3 bg-[#f3f3f3] rounded w-1/2" />
        <div className="h-4 bg-[#f3f3f3] rounded" />
        <div className="h-4 bg-[#f3f3f3] rounded w-3/4" />
        <div className="h-8 bg-[#f3f3f3] rounded mt-2" />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#EAEDED]">
      {/* Hero */}
      <HeroCarousel />

      <div className="max-w-[1500px] mx-auto px-4 py-6 space-y-8">

        {/* Welcome banner for logged-in users */}
        {isAuthenticated && user && (
          <div className="bg-white border border-[#ddd] rounded-lg px-6 py-4 flex items-center justify-between">
            <div>
              <p className="text-lg font-bold text-[#0f1111]">Welcome back, {user.username || user.fullName || 'Shopper'}! 👋</p>
              <p className="text-sm text-[#555]">Continue where you left off</p>
            </div>
            <div className="flex gap-3">
              <Link to="/orders" className="px-4 py-2 bg-[#FFD814] hover:bg-[#7c3aed] border border-[#FCD200] rounded text-sm font-semibold text-[#111] transition-colors">
                Your Orders
              </Link>
              <Link to="/wishlist" className="px-4 py-2 border border-[#888c8c] rounded text-sm bg-white hover:bg-[#f0f0f0] text-[#111] transition-colors">
                Wish List
              </Link>
            </div>
          </div>
        )}

        {/* Shop by Category */}
        <section>
          <div className="flex justify-between items-end mb-4">
            <h2 className="text-xl font-bold text-[#0f1111]">Shop by Category</h2>
            <Link to="/products" className="text-[#0066c0] hover:text-[#5b21b6] text-sm font-medium">See all ›</Link>
          </div>
          <div className="grid grid-cols-5 md:grid-cols-10 gap-3">
            {CATEGORIES.map(cat => (
              <Link key={cat.name} to={`/products?category=${encodeURIComponent(cat.name)}`}
                className="bg-white border border-[#ddd] rounded-lg p-3 flex flex-col items-center gap-2 hover:shadow-md transition-shadow text-center group">
                <span className="text-3xl group-hover:scale-110 transition-transform">{cat.emoji}</span>
                <span className="text-xs font-medium text-[#0f1111] leading-tight">{cat.name.split(' ')[0]}</span>
              </Link>
            ))}
          </div>
        </section>

        {/* Today's Deals */}
        <section>
          <div className="flex justify-between items-end mb-4">
            <div>
              <h2 className="text-xl font-bold text-[#0f1111]">Today's Deals</h2>
              <p className="text-sm text-[#CC0C39] font-medium">Limited time offers</p>
            </div>
            <Link to="/products" className="text-[#0066c0] hover:text-[#5b21b6] text-sm font-medium">See all deals ›</Link>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {[...Array(6)].map((_, i) => <Skeleton key={i} />)}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {products.slice(0, 6).map(p => (
                <ProductCard key={p.id} product={p} onAddToCart={handleAddToCart} addingId={addingId} />
              ))}
            </div>
          )}
        </section>

        {/* Promotional Banners */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { bg: 'from-[#6d28d9] to-[#5b21b6]', title: 'Up to 60% off', sub: 'Electronics Sale', link: '/products?category=Electronics', emoji: '⚡' },
            { bg: 'from-[#232f3e] to-[#37475a]', title: 'Free Delivery', sub: 'Orders above ₹499', link: '/products', emoji: '🚚' },
            { bg: 'from-[#0f3460] to-[#16213e]', title: 'New Arrivals', sub: 'Fresh stock daily', link: '/products', emoji: '✨' },
          ].map(b => (
            <Link key={b.title} to={b.link}
              className={`bg-gradient-to-r ${b.bg} rounded-lg p-5 text-white flex items-center justify-between hover:opacity-90 transition-opacity`}>
              <div>
                <p className="text-xl font-bold">{b.title}</p>
                <p className="text-sm opacity-90">{b.sub}</p>
              </div>
              <span className="text-4xl">{b.emoji}</span>
            </Link>
          ))}
        </section>

        {/* Featured Products */}
        <section>
          <div className="flex justify-between items-end mb-4">
            <h2 className="text-xl font-bold text-[#0f1111]">Featured Products</h2>
            <Link to="/products" className="text-[#0066c0] hover:text-[#5b21b6] text-sm font-medium">See all ›</Link>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {[...Array(6)].map((_, i) => <Skeleton key={i} />)}
            </div>
          ) : products.length === 0 ? (
            <div className="bg-white border border-[#ddd] rounded-lg p-12 text-center">
              <p className="text-5xl mb-4">🛍️</p>
              <p className="text-xl font-medium text-[#0f1111] mb-1">No products yet</p>
              <p className="text-sm text-[#555]">Check back soon for amazing deals!</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {products.slice(6, 12).map(p => (
                <ProductCard key={p.id} product={p} onAddToCart={handleAddToCart} addingId={addingId} />
              ))}
            </div>
          )}
        </section>

        {/* Why Shop */}
        <section className="bg-white border border-[#ddd] rounded-lg p-6">
          <h2 className="text-xl font-bold text-[#0f1111] mb-5 text-center">Why Shop with Ecommerce?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { emoji: '🚚', title: 'Fast Delivery', desc: 'Get your orders delivered quickly across India' },
              { emoji: '✅', title: 'Verified Sellers', desc: 'All sellers are verified for quality assurance' },
              { emoji: '🔄', title: 'Easy Returns', desc: 'Hassle-free 7-day return policy' },
            ].map(item => (
              <div key={item.title} className="flex items-start gap-4">
                <span className="text-3xl">{item.emoji}</span>
                <div>
                  <h3 className="font-bold text-[#0f1111]">{item.title}</h3>
                  <p className="text-sm text-[#555] mt-1">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
