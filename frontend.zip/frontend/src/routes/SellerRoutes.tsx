import { Route } from 'react-router-dom';

import SellerLayout from '../components/layouts/SellerLayout';
import SellerDashboard from '../pages/seller/Dashboard';
import SellerProducts from '../pages/seller/Products';
import AddProduct from '../pages/seller/AddProduct';
import EditProduct from '../pages/seller/EditProduct';
import SellerOrders from '../pages/seller/Orders';
import SellerInventory from '../pages/seller/Inventory';
import SellerProfile from '../pages/seller/Profile';
import SellerRefunds from '../pages/seller/Refunds';

import ProtectedRoute from './ProtectedRoute';

const sellerRoutes = (
  <Route
    element={(
      <ProtectedRoute allowedRoles={['seller', 'admin']} redirectTo="/seller/login">
        <SellerLayout />
      </ProtectedRoute>
    )}
  >
    <Route path="/seller/dashboard" element={<SellerDashboard />} />
    <Route path="/seller/products" element={<SellerProducts />} />
    <Route path="/seller/products/new" element={<AddProduct />} />
    <Route path="/seller/products/:id/edit" element={<EditProduct />} />
    <Route path="/seller/orders" element={<SellerOrders />} />
    <Route path="/seller/inventory" element={<SellerInventory />} />
    <Route path="/seller/refunds" element={<SellerRefunds />} />
    <Route path="/seller/profile" element={<SellerProfile />} />
  </Route>
);

export default sellerRoutes;
