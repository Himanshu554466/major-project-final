import React, { useEffect, useState, useCallback } from 'react';
import {
  IndianRupee,
  ShoppingCart,
  TrendingUp,
  BarChart2,
  Calendar,
} from 'lucide-react';
import api from '../../services/api';

interface OrdersByStatus {
  status: string;
  count: number;
}

interface TopProduct {
  productId: string;
  title: string;
  unitsSold: number;
  revenue: number;
}

interface AnalyticsData {
  totalRevenue: number;
  totalOrders: number;
  ordersByStatus: OrdersByStatus[];
  topProducts: TopProduct[];
}

const statusColors: Record<string, string> = {
  placed: 'bg-blue-500',
  confirmed: 'bg-indigo-500',
  preparing: 'bg-yellow-500',
  packed: 'bg-orange-500',
  shipped: 'bg-purple-500',
  delivered: 'bg-green-500',
  cancelled: 'bg-red-400',
  rejected: 'bg-red-600',
};

const formatDate = (d: Date) => d.toISOString().split('T')[0];

const Analytics: React.FC = () => {
  const today = new Date();
  const thirtyDaysAgo = new Date(today);
  thirtyDaysAgo.setDate(today.getDate() - 30);

  const [from, setFrom] = useState(formatDate(thirtyDaysAgo));
  const [to, setTo] = useState(formatDate(today));
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchAnalytics = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.get<AnalyticsData>('/seller/analytics', {
        params: { from, to },
      });
      setData(res.data);
    } catch {
      setError('Failed to load analytics data.');
    } finally {
      setLoading(false);
    }
  }, [from, to]);

  useEffect(() => {
    fetchAnalytics();
  }, [fetchAnalytics]);

  const maxCount = Math.max(...(data?.ordersByStatus?.map((s) => s.count) ?? [1]), 1);

  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
          <p className="text-gray-500 text-sm mt-1">Track your store performance</p>
        </div>

        {/* Date Range Filter */}
        <div className="flex items-center gap-3 bg-white border border-gray-200 rounded-xl px-4 py-3 shadow-sm">
          <Calendar className="w-4 h-4 text-gray-400" />
          <div className="flex items-center gap-2 text-sm">
            <label className="text-gray-500">From</label>
            <input
              type="date"
              value={from}
              max={to}
              onChange={(e) => setFrom(e.target.value)}
              className="border border-gray-300 rounded-lg px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <label className="text-gray-500">To</label>
            <input
              type="date"
              value={to}
              min={from}
              max={formatDate(today)}
              onChange={(e) => setTo(e.target.value)}
              className="border border-gray-300 rounded-lg px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600" />
        </div>
      ) : error ? (
        <div className="p-6 text-red-600 bg-red-50 rounded-lg">{error}</div>
      ) : (
        <>
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white rounded-xl border border-indigo-200 p-6 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-indigo-50 rounded-lg">
                <IndianRupee className="w-6 h-6 text-indigo-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Total Revenue</p>
                <p className="text-2xl font-bold text-gray-900">
                  ₹{(data?.totalRevenue ?? 0).toLocaleString('en-IN')}
                </p>
              </div>
            </div>
            <div className="bg-white rounded-xl border border-orange-200 p-6 shadow-sm flex items-center gap-4">
              <div className="p-3 bg-orange-50 rounded-lg">
                <ShoppingCart className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Total Orders</p>
                <p className="text-2xl font-bold text-gray-900">{data?.totalOrders ?? 0}</p>
              </div>
            </div>
          </div>

          {/* Orders by Status */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
            <h2 className="text-base font-semibold text-gray-800 mb-6 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-indigo-600" />
              Orders by Status
            </h2>

            {!data?.ordersByStatus?.length ? (
              <p className="text-gray-400 text-sm text-center py-8">No order data available</p>
            ) : (
              <div className="space-y-4">
                {data.ordersByStatus.map((item) => {
                  const pct = Math.round((item.count / maxCount) * 100);
                  return (
                    <div key={item.status} className="flex items-center gap-4">
                      <span className="w-24 text-sm text-gray-600 capitalize text-right flex-shrink-0">
                        {item.status}
                      </span>
                      <div className="flex-1 bg-gray-100 rounded-full h-6 overflow-hidden">
                        <div
                          className={`h-full rounded-full flex items-center justify-end pr-2 transition-all duration-500 ${
                            statusColors[item.status] ?? 'bg-gray-400'
                          }`}
                          style={{ width: `${Math.max(pct, 4)}%` }}
                        >
                          {pct > 15 && (
                            <span className="text-white text-xs font-medium">{item.count}</span>
                          )}
                        </div>
                      </div>
                      <span className="w-8 text-sm font-semibold text-gray-700 flex-shrink-0">
                        {item.count}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Top Products */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-100">
              <h2 className="text-base font-semibold text-gray-800 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-indigo-600" />
                Top 5 Products by Sales
              </h2>
            </div>

            {!data?.topProducts?.length ? (
              <div className="flex flex-col items-center justify-center h-32 text-gray-400">
                <TrendingUp className="w-8 h-8 mb-2" />
                <p className="text-sm">No sales data available</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 text-gray-500 text-xs uppercase border-b border-gray-100">
                      <th className="px-6 py-3 text-left">#</th>
                      <th className="px-6 py-3 text-left">Product</th>
                      <th className="px-6 py-3 text-left">Units Sold</th>
                      <th className="px-6 py-3 text-left">Revenue</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {data.topProducts.slice(0, 5).map((product, index) => (
                      <tr key={product.productId} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-3">
                          <span
                            className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                              index === 0
                                ? 'bg-yellow-100 text-yellow-700'
                                : index === 1
                                ? 'bg-gray-100 text-gray-600'
                                : index === 2
                                ? 'bg-orange-100 text-orange-700'
                                : 'bg-gray-50 text-gray-500'
                            }`}
                          >
                            {index + 1}
                          </span>
                        </td>
                        <td className="px-6 py-3 font-medium text-gray-800">{product.title}</td>
                        <td className="px-6 py-3 text-gray-600">{product.unitsSold}</td>
                        <td className="px-6 py-3 font-semibold text-indigo-700">
                          ₹{product.revenue?.toLocaleString('en-IN')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default Analytics;
