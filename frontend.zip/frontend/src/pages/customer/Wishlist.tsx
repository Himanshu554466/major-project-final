import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Heart, ShoppingCart, Trash2, Package, Loader2 } from 'lucide-react';
import api from '../../services/api';
import { useCart } from '../../context/CartContext';

interface WishlistItem {
  id: string;
  product: {
    id: string;
    title: string;
    brand: string;
    category: string;
    variants: { id: string; price: number; color?: string; size?: string; stock: number }[];
    images: { id: string; url: string }[];
  };
}

export default function Wishlist() {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [items, setItems] = useState<WishlistItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [removingId, setRemovingId] = useState<string | null>(null);
  const [addingId, setAddingId] = useState<string | null>(null);

  useEffect(() => {
    api.get('/customer/wishlist')
      .then(res => setItems(res.data.items || res.data || []))
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, []);

  const handleRemove = async (itemId: string) => {
    setRemovingId(itemId);
    try {
      await api.delete(`/customer/wishlist/${itemId}`);
      setItems(prev => prev.filter(i => i.id !== itemId));
    } catch {
      // silently fail
    } finally {
      setRemovingId(null);
    }
  };

  const handleAddToCart = async (item: WishlistItem) => {
    setAddingId(item.id);
    try {
      const variantId = item.product.variants?.[0]?.id;
      await addToCart(item.product.id, variantId, 1);
    } catch {
      navigate('/login');
    } finally {
      setAddingId(null);
    }
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-10">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">My Wishlist</h1>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="bg-white rounded-xl shadow-sm overflow-hidden animate-pulse">
              <div className="bg-gray-200 h-44 w-full" />
              <div className="p-3 space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4" />
                <div className="h-3 bg-gray-200 rounded w-1/2" />
                <div className="h-8 bg-gray-200 rounded" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-20 text-center">
        <Heart className="w-20 h-20 text-gray-300 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-700 mb-2">Your wishlist is empty</h2>
        <p className="text-gray-500 mb-6">Save items you love to your wishlist.</p>
        <Link
          to="/products"
          className="inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-semibold px-6 py-3 rounded-xl transition-colors"
        >
          Explore Products
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-800">
            My Wishlist <span className="text-gray-400 font-normal text-lg">({items.length})</span>
          </h1>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {items.map(item => {
            const price = item.product.variants?.[0]?.price ?? 0;
            const imageUrl = item.product.images?.[0]?.url;

            return (
              <div key={item.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden group relative">
                {/* Remove button */}
                <button
                  onClick={() => handleRemove(item.id)}
                  disabled={removingId === item.id}
                  className="absolute top-2 right-2 z-10 w-8 h-8 bg-white rounded-full shadow flex items-center justify-center text-gray-400 hover:text-red-500 transition-colors"
                >
                  {removingId === item.id ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4" />
                  )}
                </button>

                <Link to={`/products/${item.product.id}`}>
                  {imageUrl ? (
                    <img
                      src={imageUrl}
                      alt={item.product.title}
                      className="w-full h-44 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-44 bg-gray-100 flex items-center justify-center">
                      <Package className="w-10 h-10 text-gray-300" />
                    </div>
                  )}
                </Link>

                <div className="p-3">
                  <Link to={`/products/${item.product.id}`}>
                    <h3 className="text-sm font-semibold text-gray-800 line-clamp-2 hover:text-orange-500 transition-colors">
                      {item.product.title}
                    </h3>
                  </Link>
                  <p className="text-xs text-gray-500 mt-0.5">{item.product.brand}</p>
                  <p className="text-base font-bold text-gray-900 mt-1">₹{price.toLocaleString()}</p>

                  <button
                    onClick={() => handleAddToCart(item)}
                    disabled={addingId === item.id}
                    className="mt-2 w-full bg-orange-500 hover:bg-orange-600 disabled:bg-orange-300 text-white text-xs font-semibold py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  >
                    {addingId === item.id ? (
                      <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Adding...</>
                    ) : (
                      <><ShoppingCart className="w-3.5 h-3.5" /> Add to Cart</>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
