import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

const AdminLogin: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email.trim() || !password.trim()) { setError('Please fill in all fields.'); return; }
    try {
      setLoading(true);
      const res = await api.post('/auth/admin/login', { email, password });
      login(res.data.token, res.data.user);
      navigate('/admin/dashboard');
    } catch (err: unknown) {
      setError((err as { response?: { data?: { message?: string } } })?.response?.data?.message || 'Invalid admin credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#EAEDED] flex flex-col items-center pt-8 pb-16 px-4">
      {/* Logo */}
      <Link to="/" className="mb-6">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-[#6d28d9] rounded-md flex items-center justify-center">
            <span className="text-white font-black text-lg">E</span>
          </div>
          <span className="font-black text-2xl text-[#1e1b4b] tracking-tight">Ecom<span className="text-[#6d28d9]">merce</span></span>
        </div>
      </Link>

      <div className="w-full max-w-sm bg-white border border-[#ddd] rounded-lg overflow-hidden">
        {/* Portal header — dark theme */}
        <div className="bg-[#0f1111] px-6 py-4 flex items-center gap-3">
          <div className="w-10 h-10 bg-[#6d28d9] rounded-lg flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
          </div>
          <div>
            <p className="text-white font-bold text-base leading-tight">Admin Portal</p>
            <p className="text-[#888c8c] text-xs">Platform operations & oversight</p>
          </div>
        </div>

        <div className="p-6">
          <h1 className="text-xl font-medium text-[#0f1111] mb-1">Administrator sign in</h1>
          <p className="text-xs text-[#555] mb-5">Restricted access — authorised personnel only</p>

          {error && (
            <div className="mb-4 p-3 bg-[#fff8f0] border border-[#e77600] rounded text-sm text-[#5b21b6] flex items-start gap-2">
              <svg className="w-4 h-4 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[#0f1111] mb-1">Admin email</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                placeholder="admin@ecommerce.com"
                className="w-full px-3 py-2 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30"
                required />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0f1111] mb-1">Password</label>
              <div className="relative">
                <input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)}
                  className="w-full px-3 py-2 pr-10 border border-[#888c8c] rounded text-sm focus:outline-none focus:border-[#e77600] focus:ring-2 focus:ring-[#e77600]/30"
                  required />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#0066c0] hover:text-[#5b21b6] hover:underline">
                  {showPassword ? 'Hide' : 'Show'}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-2 bg-[#FFD814] hover:bg-[#7c3aed] border border-[#FCD200] rounded text-sm font-semibold text-[#111] transition-colors disabled:opacity-60">
              {loading ? 'Signing in...' : 'Sign in to Admin'}
            </button>
          </form>

          {/* Security notice */}
          <div className="mt-5 p-3 bg-[#f8f8f8] border border-[#eee] rounded text-xs text-[#555] flex items-start gap-2">
            <svg className="w-3.5 h-3.5 mt-0.5 shrink-0 text-[#888]" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
            </svg>
            This is a secure area. All access is logged and monitored.
          </div>
        </div>
      </div>

      <div className="w-full max-w-sm mt-5 flex items-center gap-3">
        <div className="flex-1 h-px bg-[#ddd]" />
        <span className="text-xs text-[#767676]">Other portals</span>
        <div className="flex-1 h-px bg-[#ddd]" />
      </div>
      <div className="w-full max-w-sm mt-3 grid grid-cols-3 gap-2">
        {[{ to: '/login', label: 'Customer' }, { to: '/seller/login', label: 'Seller' }, { to: '/delivery/login', label: 'Delivery' }].map(p => (
          <Link key={p.to} to={p.to}
            className="py-2 border border-[#ddd] rounded text-xs text-center text-[#0066c0] hover:bg-[#f0f0f0] hover:text-[#5b21b6] transition-colors bg-white">
            {p.label}
          </Link>
        ))}
      </div>
    </div>
  );
};

export default AdminLogin;
