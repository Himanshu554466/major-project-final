import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Trash2, ChevronRight, ChevronLeft, Upload, X, Tag, CheckCircle } from 'lucide-react';
import api from '../../services/api';

const CATEGORIES = [
  'Electronics', 'Fashion', 'Home & Kitchen', 'Sports & Outdoors', 'Books',
  'Groceries', 'Beauty & Personal Care', 'Toys & Games', 'Automotive',
  'Health & Wellness', 'Furniture', 'Appliances', 'Jewelry', 'Pet Supplies',
  'Office Supplies', 'Garden & Outdoor', 'Baby & Kids', 'Music & Instruments',
  'Art & Crafts', 'Mobile & Tablets', 'Computers & Laptops', 'Cameras & Photography',
  'Watches', 'Footwear', 'Bags & Luggage', 'Stationery', 'Gaming',
  'Fitness Equipment', 'Home Decor', 'Kitchen Appliances',
];

const BRANDS_BY_CATEGORY: Record<string, string[]> = {
  Electronics: ['Apple', 'Samsung', 'Sony', 'LG', 'OnePlus', 'Xiaomi', 'Boat', 'JBL'],
  Fashion: ['Nike', 'Adidas', 'Puma', "Levi's", 'H&M', 'Zara', 'Allen Solly', 'Peter England'],
  'Home & Kitchen': ['Prestige', 'Philips', 'Bajaj', 'Havells', 'Pigeon', 'Butterfly'],
  'Sports & Outdoors': ['Nike', 'Adidas', 'Puma', 'Decathlon', 'Cosco', 'Nivia'],
  Books: ['Penguin', 'HarperCollins', 'Scholastic', 'Oxford'],
};

interface Variant { color: string; size: string; price: string; stock: string; }

interface FormData {
  title: string; description: string; category: string; brand: string;
  stock: string; lowStock: string; deliveryCharge: string; freeDeliveryAbove: string; tags: string;
}

const emptyVariant = (): Variant => ({ color: '', size: '', price: '', stock: '' });

const AddProduct: React.FC = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const [form, setForm] = useState<FormData>({
    title: '', description: '', category: '', brand: '',
    stock: '0', lowStock: '5', deliveryCharge: '0', freeDeliveryAbove: '0', tags: '',
  });

  const [variants, setVariants] = useState<Variant[]>([emptyVariant()]);
  const [images, setImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  const brandSuggestions = form.category ? BRANDS_BY_CATEGORY[form.category] ?? [] : [];

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleVariantChange = (index: number, field: keyof Variant, value: string) => {
    setVariants(prev => { const u = [...prev]; u[index] = { ...u[index], [field]: value }; return u; });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    setImages(prev => [...prev, ...files]);
    setImagePreviews(prev => [...prev, ...files.map(f => URL.createObjectURL(f))]);
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => { URL.revokeObjectURL(prev[index]); return prev.filter((_, i) => i !== index); });
  };

  const validateStep = (): boolean => {
    setError('');
    if (step === 1) {
      if (!form.title.trim()) { setError('Product title is required.'); return false; }
      if (!form.category) { setError('Please select a category.'); return false; }
    }
    if (step === 2) {
      const validVariants = variants.filter(v => v.price);
      if (validVariants.length === 0) { setError('At least one variant with a price is required.'); return false; }
    }
    return true;
  };

  const handleNext = () => {
    if (validateStep()) setStep(s => s + 1);
  };

  const handleBack = () => { setError(''); setStep(s => s - 1); };

  // Only called on step 3 — the submit button is the only way to reach this
  const handleSubmit = async () => {
    setError('');
    setSubmitting(true);
    try {
      const fd = new FormData();
      fd.append('title', form.title);
      fd.append('description', form.description);
      fd.append('category', form.category);
      fd.append('brand', form.brand);
      fd.append('stock', form.stock || '0');
      fd.append('lowStock', form.lowStock || '5');
      fd.append('deliveryCharge', form.deliveryCharge || '0');
      fd.append('freeDeliveryAbove', form.freeDeliveryAbove || '0');
      fd.append('tags', JSON.stringify(form.tags.split(',').map(t => t.trim()).filter(Boolean)));
      fd.append('variants', JSON.stringify(variants.filter(v => v.price).map(v => ({
        color: v.color || null, size: v.size || null,
        price: parseFloat(v.price) || 0, stock: parseInt(v.stock) || 0,
      }))));
      images.forEach(img => fd.append('images', img));
      await api.post('/seller/products', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      navigate('/seller/products');
    } catch (err: unknown) {
      setError((err as { response?: { data?: { message?: string } } })?.response?.data?.message || 'Failed to create product.');
    } finally {
      setSubmitting(false);
    }
  };

  const steps = ['Basic Info', 'Variants & Pricing', 'Images & Details'];

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Add New Product</h1>
        <p className="text-gray-500 text-sm mt-1">Fill in the details to list your product</p>
      </div>

      {/* Step Indicator */}
      <div className="flex items-center mb-8">
        {steps.map((label, i) => {
          const num = i + 1;
          const active = step === num;
          const done = step > num;
          return (
            <React.Fragment key={label}>
              <div className="flex items-center gap-2">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${
                  done ? 'bg-green-500 text-white' : active ? 'bg-indigo-600 text-white ring-4 ring-indigo-100' : 'bg-gray-200 text-gray-500'
                }`}>
                  {done ? <CheckCircle className="w-4 h-4" /> : num}
                </div>
                <span className={`text-sm font-medium hidden sm:block ${active ? 'text-indigo-600' : done ? 'text-green-600' : 'text-gray-400'}`}>
                  {label}
                </span>
              </div>
              {i < steps.length - 1 && <div className={`flex-1 h-0.5 mx-3 ${done ? 'bg-green-400' : 'bg-gray-200'}`} />}
            </React.Fragment>
          );
        })}
      </div>

      {/* NO <form> wrapper — all buttons are type="button" to prevent accidental submission */}
      <div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-5">

          {/* ── Step 1: Basic Info ── */}
          {step === 1 && (
            <>
              <h2 className="text-base font-semibold text-gray-800">Basic Information</h2>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Product Title <span className="text-red-500">*</span></label>
                <input type="text" name="title" value={form.title} onChange={handleFormChange}
                  placeholder="e.g. Wireless Bluetooth Headphones"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea name="description" value={form.description} onChange={handleFormChange} rows={4}
                  placeholder="Describe your product in detail..."
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category <span className="text-red-500">*</span></label>
                <select name="category" value={form.category} onChange={handleFormChange}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="">Select a category</option>
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Brand</label>
                {brandSuggestions.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {brandSuggestions.map(b => (
                      <button key={b} type="button" onClick={() => setForm(p => ({ ...p, brand: b }))}
                        className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                          form.brand === b ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-600 border-gray-300 hover:border-indigo-400'
                        }`}>
                        {b}
                      </button>
                    ))}
                  </div>
                )}
                <input type="text" name="brand" value={form.brand} onChange={handleFormChange}
                  placeholder="Or type brand name manually"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
            </>
          )}

          {/* ── Step 2: Variants & Pricing ── */}
          {step === 2 && (
            <>
              <h2 className="text-base font-semibold text-gray-800">Variants & Pricing</h2>
              <div className="bg-blue-50 border border-blue-200 rounded-lg px-4 py-3 text-sm text-blue-700">
                💡 Add at least one variant with a price. Color and size are optional.
              </div>
              <div>
                <div className="flex items-center justify-between mb-3">
                  <label className="text-sm font-medium text-gray-700">Variants <span className="text-gray-400 font-normal">(color, size, price, stock)</span></label>
                  <button type="button" onClick={() => setVariants(p => [...p, emptyVariant()])}
                    className="flex items-center gap-1 text-sm text-indigo-600 hover:text-indigo-800 font-medium">
                    <Plus className="w-4 h-4" /> Add Variant
                  </button>
                </div>
              <div className="space-y-3">
                  {variants.map((variant, index) => (
                    <div key={index} className="bg-gray-50 border border-gray-200 rounded-xl p-4">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Variant {index + 1}</span>
                        {variants.length > 1 && (
                          <button type="button" onClick={() => setVariants(p => p.filter((_, i) => i !== index))}
                            className="text-xs text-red-500 hover:text-red-700 flex items-center gap-1">
                            <Trash2 className="w-3.5 h-3.5" /> Remove
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">Color <span className="text-gray-400">(optional)</span></label>
                          <input type="text" placeholder="e.g. Black, Red" value={variant.color}
                            onChange={e => handleVariantChange(index, 'color', e.target.value)}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">Size <span className="text-gray-400">(optional)</span></label>
                          <input type="text" placeholder="e.g. S, M, L, XL" value={variant.size}
                            onChange={e => handleVariantChange(index, 'size', e.target.value)}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">Price ₹ <span className="text-red-500">*</span></label>
                          <input type="number" placeholder="0.00" value={variant.price}
                            onChange={e => handleVariantChange(index, 'price', e.target.value)} min="0"
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">Stock</label>
                          <input type="number" placeholder="0" value={variant.stock}
                            onChange={e => handleVariantChange(index, 'stock', e.target.value)} min="0"
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* ── Step 3: Images & Details ── */}
          {step === 3 && (
            <>
              <h2 className="text-base font-semibold text-gray-800">Images & Details</h2>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Product Images</label>
                <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-indigo-400 hover:bg-indigo-50 transition-colors">
                  <Upload className="w-6 h-6 text-gray-400 mb-1" />
                  <span className="text-sm text-gray-500">Click to upload images</span>
                  <span className="text-xs text-gray-400">PNG, JPG, WEBP up to 5MB each</span>
                  <input type="file" multiple accept="image/*" onChange={handleImageChange} className="hidden" />
                </label>
                {imagePreviews.length > 0 && (
                  <div className="flex flex-wrap gap-3 mt-3">
                    {imagePreviews.map((src, i) => (
                      <div key={i} className="relative">
                        <img src={src} alt={`preview-${i}`} className="w-20 h-20 object-cover rounded-lg border border-gray-200" />
                        <button type="button" onClick={() => removeImage(i)}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600">
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  <span className="flex items-center gap-1">
                    <Tag className="w-4 h-4" /> Tags
                  </span>
                </label>
                <input type="text" name="tags" value={form.tags} onChange={handleFormChange}
                  placeholder="e.g. wireless, bluetooth, headphones (comma separated)"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Charge (₹)</label>
                  <input type="number" name="deliveryCharge" value={form.deliveryCharge} onChange={handleFormChange} min="0"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Free Delivery Above (₹)</label>
                  <input type="number" name="freeDeliveryAbove" value={form.freeDeliveryAbove} onChange={handleFormChange} min="0"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Low Stock Threshold</label>
                  <input type="number" name="lowStock" value={form.lowStock} onChange={handleFormChange} min="0"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>
            </>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-4 py-3 flex items-center gap-2">
              <span>⚠️</span> {error}
            </div>
          )}
        </div>

        {/* Navigation — all type="button", no form submission */}
        <div className="flex items-center justify-between mt-6">
          <button type="button" onClick={step === 1 ? () => navigate('/seller/products') : handleBack}
            className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
            <ChevronLeft className="w-4 h-4" />
            {step === 1 ? 'Cancel' : 'Back'}
          </button>

          {step < 3 ? (
            <button type="button" onClick={handleNext}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors">
              Next <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button type="button" onClick={handleSubmit} disabled={submitting}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-5 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-60">
              {submitting ? (
                <><div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" /> Submitting...</>
              ) : (
                <><CheckCircle className="w-4 h-4" /> Submit Product</>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default AddProduct;
