/**
 * Application-level error boundary with Rollbar integration.
 * Catches render errors and displays a clean fallback UI.
 */
import React from 'react';
import { ErrorBoundary as RollbarErrorBoundary } from '@rollbar/react';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { IS_DEV } from '../../config';

interface FallbackProps {
  error: Error;
  resetError: () => void;
}

function ErrorFallback({ error, resetError }: FallbackProps) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 max-w-md w-full text-center">
        <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="w-7 h-7 text-red-500" />
        </div>

        <h1 className="text-lg font-semibold text-gray-900 mb-2">
          Something went wrong
        </h1>

        <p className="text-sm text-gray-500 mb-1">
          An unexpected error occurred. Our team has been notified and is
          working on a fix.
        </p>

        {IS_DEV && (
          <p className="text-xs text-red-400 bg-red-50 rounded-lg px-3 py-2 mt-3 text-left font-mono break-all">
            {error.message}
          </p>
        )}

        <div className="flex gap-3 mt-6">
          <button
            onClick={resetError}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-sm font-medium transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            Try Again
          </button>
          <button
            onClick={() => (window.location.href = '/')}
            className="flex-1 py-2.5 border border-gray-200 text-gray-600 hover:bg-gray-50 rounded-xl text-sm font-medium transition-colors"
          >
            Go Home
          </button>
        </div>
      </div>
    </div>
  );
}

interface Props {
  children: React.ReactNode;
}

export default function AppErrorBoundary({ children }: Props) {
  return (
    <RollbarErrorBoundary
      fallbackUI={({ error, resetError }) => (
        <ErrorFallback error={error as Error} resetError={resetError} />
      )}
    >
      {children}
    </RollbarErrorBoundary>
  );
}
