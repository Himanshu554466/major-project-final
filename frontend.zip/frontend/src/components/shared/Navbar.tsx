import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import api from '../../services/api';

const ALL_CATEGORIES = [
  'Electronics', 'Fashion', 'Home & Kitchen', 'Sports & Outdoors', 'Books',
  'Groceries', 'Beauty & Personal Care', 'Toys & Games', 'Automotive',
  'Health & Wellness', 'Furniture', 'Appliances', 'Jewelry', 'Pet Supplies',
  'Office Supplies',
];

function useDebounce(value: string, delay: number) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

function HighlightMatch({ text, query }: { text: string; query: string }) {
  if (!query) return <span>{text}</span>;
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return <span>{text}</span>;
  return (
    <span>
      {text.slice(0, idx)}
      <strong className="font-semibold text-[#111]">{text.slice(idx, idx + query.length)}</strong>
      {text.slice(idx + query.length)}
    </span>
  );
}

interface Suggestion {
  products: { id: number; title: string; category?: string; id_str?: string }[];
  brands: string[];
  categories: string[];
}

const Navbar: React.FC = () => {
  const { isAuthenticated, user, logout } = useAuth();
  const { cartCount } = useCart();
  const navigate = useNavigate();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [catDropOpen, setCatDropOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [suggestions, setSuggestions] = useState<Suggestion>({ products: [], brands: [], categories: [] });
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [sugLoading, setSugLoading] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);

  const catDropRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);
  const debouncedSearch = useDebounce(search, 220);

  // Fetch suggestions from backend
  const fetchSuggestions = useCallback(async (q: string) => {
    if (!q.trim()) {
      setSuggestions({ products: [], brands: [], categories: [] });
      setShowSuggestions(false);
      return;
    }
    setSugLoading(true);
    try {
      const params: Record<string, string> = { search: q, limit: '5' };
      if (selectedCategory !== 'All') params.category = selectedCategory;
      // Use dedicated suggestions endpoint
      const res = await api.get('/customer/products/suggestions', { params });
      setSuggestions({
        products: res.data.products || [],
        brands: res.data.brands || [],
        categories: res.data.categories || [],
      });
      setShowSuggestions(true);
    } catch {
      // ignore
    } finally {
      setSugLoading(false);
    }
  }, [selectedCategory]);

  useEffect(() => {
    fetchSuggestions(debouncedSearch);
  }, [debouncedSearch, fetchSuggestions]);

  // Close dropdowns on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (catDropRef.current && !catDropRef.current.contains(e.target as Node)) setCatDropOpen(false);
      if (
        suggestionsRef.current && !suggestionsRef.current.contains(e.target as Node) &&
        searchRef.current && !searchRef.current.contains(e.target as Node)
      ) setShowSuggestions(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSearch = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!search.trim()) return;
    const params = new URLSearchParams();
    params.set('search', search.trim());
    if (selectedCategory !== 'All') params.set('category', selectedCategory);
    navigate(`/products?${params.toString()}`);
    setSearch('');
    setShowSuggestions(false);
    setMobileSearchOpen(false);
  };

  const handleSuggestionClick = (type: string, value: string, id?: string | number) => {
    setShowSuggestions(false);
    setSearch('');
    if (type === 'product') navigate(`/products/${id}`);
    else if (type === 'brand') navigate(`/products?brand=${encodeURIComponent(value)}`);
    else if (type === 'category') navigate(`/products?category=${encodeURIComponent(value)}`);
    setMobileSearchOpen(false);
  };

  const hasSuggestions = suggestions.products.length > 0 || suggestions.brands.length > 0 || suggestions.categories.length > 0;

  // Inline search bar JSX — NOT a nested component (would cause focus loss on re-render)
  const renderSearchBar = (mobile = false) => (
    <div className={`flex ${mobile ? 'w-full' : 'flex-1 max-w-3xl'} relative`}>
      <form onSubmit={handleSearch} className="flex w-full h-10 rounded-lg overflow-visible shadow-sm">
        {/* Category dropdown */}
        <div ref={catDropRef} className="relative shrink-0 z-10">
          <button
            type="button"
            onClick={() => setCatDropOpen(!catDropOpen)}
            className="h-10 px-3 bg-[#e8e8e8] hover:bg-[#d8d8d8] text-[#333] text-xs font-semibold flex items-center gap-1.5 border-r border-[#c0c0c0] rounded-l-lg transition-colors whitespace-nowrap"
          >
            <span className="max-w-[72px] truncate">{selectedCategory}</span>
            <svg className="w-3 h-3 text-[#555] shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          {catDropOpen && (
            <div className="absolute top-full left-0 mt-1 bg-white border border-[#ccc] rounded-lg shadow-2xl z-50 w-52 py-1.5 max-h-80 overflow-y-auto">
              {['All', ...ALL_CATEGORIES].map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => { setSelectedCategory(c); setCatDropOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-sm transition-colors ${
                    selectedCategory === c ? 'bg-[#ede9fe] text-[#5b21b6] font-semibold' : 'text-[#111] hover:bg-[#f5f5f5]'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Input — always controlled, never remounted */}
        <input
          ref={searchRef}
          type="text"
          value={search}
          onChange={(e) => { setSearch(e.target.value); if (e.target.value) setShowSuggestions(true); else setShowSuggestions(false); }}
          onFocus={() => { if (search && hasSuggestions) setShowSuggestions(true); }}
          placeholder={`Search Ecommerce${selectedCategory !== 'All' ? ` in ${selectedCategory}` : ''}`}
          className="flex-1 h-10 px-4 text-[#111] text-sm outline-none bg-white placeholder-[#999]"
          autoComplete="off"
        />

        {/* Search button */}
        <button
          type="submit"
          className="h-10 px-5 bg-[#6d28d9] hover:bg-[#5b21b6] text-[#111] rounded-r-lg transition-colors flex items-center justify-center"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </button>
      </form>

      {/* Suggestions dropdown */}
      {showSuggestions && search.trim() && (
        <div
          ref={suggestionsRef}
          className="absolute top-full left-0 right-0 mt-1 bg-white border border-[#ddd] rounded-lg shadow-2xl z-50 overflow-hidden"
        >
          {sugLoading && (
            <div className="px-4 py-3 text-sm text-[#555] flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-[#6d28d9] border-t-transparent rounded-full animate-spin" />
              Searching...
            </div>
          )}
          {!sugLoading && !hasSuggestions && (
            <div className="px-4 py-3 text-sm text-[#555]">No results for "<strong>{search}</strong>"</div>
          )}
          {suggestions.categories.length > 0 && (
            <div>
              <p className="px-4 pt-2.5 pb-1 text-[10px] font-bold text-[#999] uppercase tracking-widest">Categories</p>
              {suggestions.categories.map((cat) => (
                <button key={cat} onClick={() => handleSuggestionClick('category', cat)}
                  className="w-full text-left px-4 py-2 text-sm text-[#111] hover:bg-[#f5f5f5] flex items-center gap-3 transition-colors">
                  <svg className="w-4 h-4 text-[#999] shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                  </svg>
                  in <strong>{cat}</strong>
                </button>
              ))}
            </div>
          )}
          {suggestions.brands.length > 0 && (
            <div>
              <p className="px-4 pt-2.5 pb-1 text-[10px] font-bold text-[#999] uppercase tracking-widest">Brands</p>
              {suggestions.brands.map((brand) => (
                <button key={brand} onClick={() => handleSuggestionClick('brand', brand)}
                  className="w-full text-left px-4 py-2 text-sm text-[#111] hover:bg-[#f5f5f5] flex items-center gap-3 transition-colors">
                  <svg className="w-4 h-4 text-[#999] shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                  </svg>
                  <HighlightMatch text={brand} query={search} />
                  <span className="text-xs text-[#999] ml-auto">Brand</span>
                </button>
              ))}
            </div>
          )}
          {suggestions.products.length > 0 && (
            <div>
              <p className="px-4 pt-2.5 pb-1 text-[10px] font-bold text-[#999] uppercase tracking-widest">Products</p>
              {suggestions.products.map((p) => (
                <button key={p.id} onClick={() => handleSuggestionClick('product', p.title, p.id)}
                  className="w-full text-left px-4 py-2 text-sm text-[#111] hover:bg-[#f5f5f5] flex items-center gap-3 transition-colors">
                  <svg className="w-4 h-4 text-[#999] shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                  <span className="truncate flex-1"><HighlightMatch text={p.title} query={search} /></span>
                  {p.category && <span className="text-xs text-[#999] shrink-0">in {p.category}</span>}
                </button>
              ))}
            </div>
          )}
          {hasSuggestions && (
            <button onClick={handleSearch}
              className="w-full text-left px-4 py-2.5 text-sm text-[#0066c0] hover:text-[#5b21b6] hover:bg-[#f5f5f5] border-t border-[#eee] font-medium transition-colors">
              See all results for "<strong>{search}</strong>"
              {selectedCategory !== 'All' && ` in ${selectedCategory}`}
            </button>
          )}
        </div>
      )}
    </div>
  );

  return (
    <header className="sticky top-0 z-50 shadow-md">
      {/* ── Top Bar ── */}
      <div style={{ background: 'linear-gradient(180deg, #312e81 0%, #1e1b4b 100%)' }}>
        <div className="max-w-[1500px] mx-auto px-4 flex items-center gap-3 h-16">

          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0 px-2 py-1.5 rounded border border-transparent hover:border-white transition-colors">
            <div className="w-8 h-8 bg-[#6d28d9] rounded-md flex items-center justify-center shadow-sm">
              <span className="text-white font-black text-base">E</span>
            </div>
            <div className="hidden sm:block">
              <span className="font-black text-xl text-white tracking-tight leading-none">Ecom</span>
              <span className="text-[#6d28d9] font-black text-xl">merce</span>
            </div>
          </Link>

          {/* Deliver to */}
          <div className="hidden xl:flex flex-col shrink-0 px-2 py-1 rounded border border-transparent hover:border-white transition-colors cursor-pointer">
            <span className="text-[#adb7c3] text-xs leading-none mb-0.5">Deliver to</span>
            <div className="flex items-center gap-1">
              <svg className="w-3.5 h-3.5 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
              </svg>
              <span className="text-white font-bold text-sm">India</span>
            </div>
          </div>

          {/* Search bar — desktop */}
          <div className="hidden md:flex flex-1 max-w-3xl">
            {renderSearchBar()}
          </div>

          {/* Right Nav */}
          <div className="flex items-center shrink-0 gap-1 ml-auto">

            {/* Mobile search toggle */}
            <button
              onClick={() => setMobileSearchOpen(!mobileSearchOpen)}
              className="md:hidden p-2 rounded border border-transparent hover:border-white transition-colors"
            >
              <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>

            {/* Account */}
            <div
              className="relative px-3 py-1.5 rounded border border-transparent hover:border-white transition-colors cursor-pointer"
              onMouseEnter={() => setAccountOpen(true)}
              onMouseLeave={() => setAccountOpen(false)}
            >
              {isAuthenticated && user ? (
                <>
                  <p className="text-[#adb7c3] text-xs leading-none mb-0.5">Hello, {user.username?.split(' ')[0] || user.fullName?.split(' ')[0] || 'User'}</p>
                  <p className="text-white font-bold text-sm flex items-center gap-1 leading-none">
                    Account & Lists
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                  </p>
                </>
              ) : (
                <Link to="/login">
                  <p className="text-[#adb7c3] text-xs leading-none mb-0.5">Hello, sign in</p>
                  <p className="text-white font-bold text-sm flex items-center gap-1 leading-none">
                    Account & Lists
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                    </svg>
                  </p>
                </Link>
              )}

              {isAuthenticated && user && accountOpen && (
                <div className="absolute right-0 top-full mt-1 z-50 w-60">
                  <div className="bg-white border border-[#ddd] rounded-lg shadow-2xl py-3 overflow-hidden">
                    <div className="px-4 pb-3 border-b border-[#eee] mb-2">
                      <p className="text-xs text-[#555] mb-2">Signed in as <strong>{user.username || user.email}</strong></p>
                      <button
                        onClick={() => { logout(); navigate('/'); setAccountOpen(false); }}
                        className="w-full py-2 bg-[#FFD814] hover:bg-[#7c3aed] border border-[#FCD200] rounded-md text-sm font-semibold text-[#111] transition-colors"
                      >
                        Sign Out
                      </button>
                    </div>
                    <div className="grid grid-cols-2">
                      {[
                        { label: 'Your Account', to: '/account', icon: '👤' },
                        { label: 'Your Orders', to: '/orders', icon: '📦' },
                        { label: 'Wish List', to: '/wishlist', icon: '❤️' },
                        { label: 'Addresses', to: '/addresses', icon: '📍' },
                      ].map((item) => (
                        <Link key={item.to} to={item.to} onClick={() => setAccountOpen(false)}
                          className="px-4 py-2.5 text-xs text-[#111] hover:text-[#5b21b6] hover:bg-[#f5f5f5] transition-colors flex items-center gap-1.5">
                          <span>{item.icon}</span>
                          {item.label}
                        </Link>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Returns & Orders */}
            <Link to="/orders" className="hidden md:block px-3 py-1.5 rounded border border-transparent hover:border-white transition-colors">
              <p className="text-[#adb7c3] text-xs leading-none mb-0.5">Returns</p>
              <p className="text-white font-bold text-sm leading-none">& Orders</p>
            </Link>

            {/* Cart */}
            <Link to="/cart" className="flex items-center gap-1.5 px-3 py-1.5 rounded border border-transparent hover:border-white transition-colors relative">
              <div className="relative">
                <svg className="w-9 h-9 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
                </svg>
                {cartCount > 0 && (
                  <span className="absolute -top-2 left-5 min-w-[22px] h-[22px] bg-[#6d28d9] text-[#111] text-xs font-black rounded-full flex items-center justify-center px-1 shadow-sm">
                    {cartCount > 99 ? '99+' : cartCount}
                  </span>
                )}
              </div>
              <span className="text-white font-bold text-sm hidden sm:block">Cart</span>
            </Link>
          </div>
        </div>

        {/* Mobile search bar */}
        {mobileSearchOpen && (
          <div className="md:hidden px-4 pb-3">
            {renderSearchBar(true)}
          </div>
        )}
      </div>

      {/* ── Category Bar ── */}
      <div className="bg-[#232f3e]">
        <div className="max-w-[1500px] mx-auto px-4 flex items-center h-11 overflow-x-auto scrollbar-hide">
          <Link to="/products"
            className="flex items-center gap-1.5 px-3 h-full text-sm font-medium text-white whitespace-nowrap hover:bg-white/10 rounded transition-colors shrink-0">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
            All
          </Link>
          {["Today's Deals", "Customer Service", ...ALL_CATEGORIES.slice(0, 9)].map((cat) => (
            <Link key={cat}
              to={ALL_CATEGORIES.includes(cat) ? `/products?category=${encodeURIComponent(cat)}` : '/products'}
              className="px-3 h-full flex items-center text-sm font-medium text-white whitespace-nowrap hover:bg-white/10 rounded transition-colors">
              {cat}
            </Link>
          ))}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
