import React from 'react';
import ReactDOM from 'react-dom/client';
import { Provider as RollbarProvider } from '@rollbar/react';
import App from './App';
import AppErrorBoundary from './components/shared/ErrorBoundary';
import rollbar from './services/rollbar';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <RollbarProvider instance={rollbar}>
      <AppErrorBoundary>
        <App />
      </AppErrorBoundary>
    </RollbarProvider>
  </React.StrictMode>,
);
