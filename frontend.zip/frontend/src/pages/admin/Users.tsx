import { useEffect, useState, useCallback } from "react";
import {
  Users, Search, ChevronLeft, ChevronRight, Loader2,
  AlertCircle, Trash2, ShieldCheck, ShieldOff, UserX, CheckCircle,
} from "lucide-react";
import API from "../../services/api";

interface AdminUser {
  id: number;
  email: string;
  username?: string;
  fullName?: string;
  shopName?: string;
  role: string;
  status: string;
  deliveryCity?: string;
  deliveryPincode?: string;
  vehicleType?: string;
  createdAt: string;
}

interface UsersResponse { users: AdminUser[]; total: number; }

const ROLE_COLORS: Record<string, string> = {
  customer: "bg-blue-100 text-blue-700",
  seller: "bg-indigo-100 text-indigo-700",
  delivery_partner: "bg-green-100 text-green-700",
  admin: "bg-red-100 text-red-700",
};

const STATUS_COLORS: Record<string, string> = {
  active: "bg-green-100 text-green-700",
  inactive: "bg-gray-100 text-gray-600",
  suspended: "bg-red-100 text-red-700",
};

const ROLES = [
  { value: "", label: "All Roles" },
  { value: "customer", label: "Customer" },
  { value: "seller", label: "Seller" },
  { value: "delivery_partner", label: "Delivery Partner" },
];

const STATUSES = [
  { value: "", label: "All Statuses" },
  { value: "active", label: "Active" },
  { value: "inactive", label: "Inactive" },
  { value: "suspended", label: "Suspended" },
];

export default function AdminUsers() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [actionLoading, setActionLoading] = useState<number | null>(null);
  const [toast, setToast] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  // deleteModal: { userId, mode: 'soft' | 'permanent' }
  const [deleteModal, setDeleteModal] = useState<{ userId: number; userName: string; role: string } | null>(null);
  const limit = 15;

  const showToast = (type: 'success' | 'error', msg: string) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 3500);
  };

  const fetchUsers = useCallback(() => {
    setLoading(true);
    setError("");
    const params = new URLSearchParams({
      page: String(page), limit: String(limit),
      ...(search ? { search } : {}),
      ...(roleFilter ? { role: roleFilter } : {}),
      ...(statusFilter ? { status: statusFilter } : {}),
    });
    API.get<UsersResponse>(`/admin/users?${params}`)
      .then(res => { setUsers(res.data.users ?? []); setTotal(res.data.total ?? 0); })
      .catch(() => setError("Failed to load users."))
      .finally(() => setLoading(false));
  }, [page, search, roleFilter, statusFilter]);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  const handleStatusChange = async (userId: number, status: string) => {
    setActionLoading(userId);
    try {
      await API.put(`/admin/users/${userId}/status`, { status });
      showToast('success', `User ${status === 'active' ? 'activated' : 'suspended'} successfully.`);
      fetchUsers();
    } catch {
      showToast('error', 'Failed to update status.');
    } finally {
      setActionLoading(null);
    }
  };

  const handleSoftDelete = async (userId: number) => {
    setActionLoading(userId);
    try {
      await API.delete(`/admin/users/${userId}`);
      showToast('success', 'User deactivated.');
      setDeleteModal(null);
      fetchUsers();
    } catch {
      showToast('error', 'Failed to deactivate user.');
    } finally {
      setActionLoading(null);
    }
  };

  const handlePermanentDelete = async (userId: number) => {
    setActionLoading(userId);
    try {
      await API.delete(`/admin/users/${userId}?permanent=true`);
      showToast('success', 'User permanently deleted.');
      setDeleteModal(null);
      fetchUsers();
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
      showToast('error', msg || 'Failed to delete user.');
    } finally {
      setActionLoading(null);
    }
  };

  const getDisplayName = (user: AdminUser) =>
    user.shopName || user.fullName || user.username || "—";

  const totalPages = Math.ceil(total / limit);

  return (
    <div className="max-w-6xl mx-auto py-8 px-4">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-sm font-medium ${
          toast.type === 'success' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'
        }`}>
          {toast.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {toast.msg}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <UserX className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">Delete User</h3>
                <p className="text-sm text-gray-500">{deleteModal.userName}</p>
              </div>
            </div>

            <p className="text-sm text-gray-600 mb-5">
              Choose how to remove this <strong>{deleteModal.role.replace('_', ' ')}</strong>:
            </p>

            <div className="space-y-3 mb-5">
              <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm font-semibold text-yellow-800">Deactivate (Soft Delete)</p>
                <p className="text-xs text-yellow-700 mt-0.5">User can no longer log in. Data is preserved. Can be reactivated.</p>
              </div>
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm font-semibold text-red-800">⚠️ Permanently Delete</p>
                <p className="text-xs text-red-700 mt-0.5">Removes user and all their data. This cannot be undone.</p>
              </div>
            </div>

            <div className="flex gap-2">
              <button onClick={() => setDeleteModal(null)}
                className="flex-1 py-2 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50">
                Cancel
              </button>
              <button
                onClick={() => handleSoftDelete(deleteModal.userId)}
                disabled={actionLoading === deleteModal.userId}
                className="flex-1 py-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-xl text-sm font-medium disabled:opacity-50">
                {actionLoading === deleteModal.userId ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'Deactivate'}
              </button>
              <button
                onClick={() => handlePermanentDelete(deleteModal.userId)}
                disabled={actionLoading === deleteModal.userId}
                className="flex-1 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-medium disabled:opacity-50">
                {actionLoading === deleteModal.userId ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'Delete Forever'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
          <Users className="w-5 h-5 text-gray-700" /> Users
        </h1>
        <p className="text-sm text-gray-400 mt-0.5">Manage platform users — {total} total</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-5">
        <form onSubmit={(e) => { e.preventDefault(); setSearch(searchInput); setPage(1); }} className="flex gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input type="text" value={searchInput} onChange={e => setSearchInput(e.target.value)}
              placeholder="Search by email or name..."
              className="pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-400 w-64" />
          </div>
          <button type="submit" className="px-3 py-2 bg-gray-800 text-white text-sm rounded-lg hover:bg-gray-900">Search</button>
        </form>
        <select value={roleFilter} onChange={e => { setRoleFilter(e.target.value); setPage(1); }}
          className="text-sm border border-gray-200 rounded-lg px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-400">
          {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
        </select>
        <select value={statusFilter} onChange={e => { setStatusFilter(e.target.value); setPage(1); }}
          className="text-sm border border-gray-200 rounded-lg px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-400">
          {STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex items-center justify-center h-48"><Loader2 className="w-8 h-8 animate-spin text-gray-500" /></div>
      ) : error ? (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-2 text-red-700 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />{error}
        </div>
      ) : users.length === 0 ? (
        <div className="text-center py-16 bg-white border border-gray-200 rounded-xl">
          <Users className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="text-sm text-gray-400">No users found</p>
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Email</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Name / Shop</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Role</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Details</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Joined</th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {users.map(user => (
                  <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 text-gray-800 max-w-[160px] truncate">{user.email}</td>
                    <td className="px-4 py-3 text-gray-600">{getDisplayName(user)}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${ROLE_COLORS[user.role] || "bg-gray-100 text-gray-600"}`}>
                        {user.role.replace("_", " ")}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-500">
                      {user.role === 'delivery_partner' && (
                        <span>{user.deliveryCity || '—'} · {user.vehicleType || '—'}</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[user.status] || "bg-gray-100 text-gray-600"}`}>
                        {user.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-500 text-xs">
                      {new Date(user.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Suspend / Activate — hide for admin accounts */}
                        {user.role !== 'admin' && (
                          user.status === "suspended" ? (
                            <button onClick={() => handleStatusChange(user.id, "active")} disabled={actionLoading === user.id}
                              title="Activate" className="p-1.5 rounded-lg text-green-600 hover:bg-green-50 disabled:opacity-50">
                              {actionLoading === user.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                            </button>
                          ) : (
                            <button onClick={() => handleStatusChange(user.id, "suspended")} disabled={actionLoading === user.id}
                              title="Suspend" className="p-1.5 rounded-lg text-yellow-600 hover:bg-yellow-50 disabled:opacity-50">
                              {actionLoading === user.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldOff className="w-4 h-4" />}
                            </button>
                          )
                        )}
                        {/* Delete — hide for admin accounts */}
                        {user.role !== 'admin' && <button
                          onClick={() => setDeleteModal({ userId: user.id, userName: user.email, role: user.role })}
                          title="Delete user"
                          className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-5">
          <p className="text-sm text-gray-500">Page {page} of {totalPages} ({total} total)</p>
          <div className="flex gap-2">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
