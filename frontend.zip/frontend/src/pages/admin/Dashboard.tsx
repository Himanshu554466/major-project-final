import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Users,
  Store,
  UserCheck,
  Truck,
  Package,
  Clock,
  ShoppingCart,
  IndianRupee,
  Activity,
  MessageSquare,
  Loader2,
  ChevronRight,
} from "lucide-react";
import API from "../../services/api";

interface AdminStats {
  totalUsers: number;
  totalSellers: number;
  totalCustomers: number;
  totalDeliveryPartners: number;
  totalProducts: number;
  pendingProducts: number;
  totalOrders: number;
  totalRevenue: number;
  activeShipments: number;
  openComplaints: number;
}

interface RecentOrder {
  id: number;
  totalAmount: number;
  status: string;
  createdAt: string;
  customer?: { email: string };
}

interface DashboardData {
  stats: AdminStats;
  recentOrders: RecentOrder[];
}

const ORDER_STATUS_COLORS: Record<string, string> = {
  placed: "bg-blue-100 text-blue-700",
  confirmed: "bg-indigo-100 text-indigo-700",
  packed: "bg-purple-100 text-purple-700",
  shipped: "bg-yellow-100 text-yellow-700",
  delivered: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

export default function AdminDashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    API.get<DashboardData>("/admin/dashboard")
      .then((res) => setData(res.data))
      .catch(() => setError("Failed to load dashboard data."))
      .finally(() => setLoading(false));
  }, []);

  const statCards = data?.stats
    ? [
        {
          label: "Total Users",
          value: data.stats.totalUsers,
          icon: <Users className="w-5 h-5" />,
          color: "bg-blue-50 text-blue-700",
        },
        {
          label: "Sellers",
          value: data.stats.totalSellers,
          icon: <Store className="w-5 h-5" />,
          color: "bg-indigo-50 text-indigo-700",
        },
        {
          label: "Customers",
          value: data.stats.totalCustomers,
          icon: <UserCheck className="w-5 h-5" />,
          color: "bg-cyan-50 text-cyan-700",
        },
        {
          label: "Delivery Partners",
          value: data.stats.totalDeliveryPartners,
          icon: <Truck className="w-5 h-5" />,
          color: "bg-green-50 text-green-700",
        },
        {
          label: "Total Products",
          value: data.stats.totalProducts,
          icon: <Package className="w-5 h-5" />,
          color: "bg-purple-50 text-purple-700",
        },
        {
          label: "Pending Approval",
          value: data.stats.pendingProducts,
          icon: <Clock className="w-5 h-5" />,
          color: "bg-yellow-50 text-yellow-700",
        },
        {
          label: "Total Orders",
          value: data.stats.totalOrders,
          icon: <ShoppingCart className="w-5 h-5" />,
          color: "bg-orange-50 text-orange-700",
        },
        {
          label: "Total Revenue",
          value: `₹${(data.stats.totalRevenue || 0).toLocaleString("en-IN")}`,
          icon: <IndianRupee className="w-5 h-5" />,
          color: "bg-emerald-50 text-emerald-700",
        },
        {
          label: "Active Shipments",
          value: data.stats.activeShipments,
          icon: <Activity className="w-5 h-5" />,
          color: "bg-teal-50 text-teal-700",
        },
        {
          label: "Open Complaints",
          value: data.stats.openComplaints,
          icon: <MessageSquare className="w-5 h-5" />,
          color: "bg-red-50 text-red-700",
        },
      ]
    : [];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-gray-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-5xl mx-auto py-8 px-4">
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-red-700 text-sm">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-xl font-semibold text-gray-900">Admin Dashboard</h1>
        <p className="text-sm text-gray-400 mt-0.5">Platform overview</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
        {statCards.map((card) => (
          <div
            key={card.label}
            className="bg-white border border-gray-200 rounded-xl px-4 py-4"
          >
            <div
              className={`w-8 h-8 rounded-lg ${card.color} flex items-center justify-center mb-2`}
            >
              {card.icon}
            </div>
            <p className="text-xl font-bold text-gray-900">{card.value}</p>
            <p className="text-xs text-gray-500 mt-0.5 leading-tight">{card.label}</p>
          </div>
        ))}
      </div>

      {/* Recent Orders */}
      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden mb-6">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm font-semibold text-gray-700">Recent Orders</h2>
          <Link
            to="/admin/orders"
            className="text-xs text-gray-500 hover:text-gray-700 flex items-center gap-1"
          >
            View all <ChevronRight className="w-3 h-3" />
          </Link>
        </div>

        {!data?.recentOrders?.length ? (
          <div className="text-center py-10">
            <ShoppingCart className="w-10 h-10 text-gray-200 mx-auto mb-2" />
            <p className="text-sm text-gray-400">No orders yet</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                    Order ID
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                    Customer
                  </th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                    Total
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {data.recentOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 font-medium text-gray-800">#{order.id}</td>
                    <td className="px-4 py-3 text-gray-600 max-w-[160px] truncate">
                      {order.customer?.email || "—"}
                    </td>
                    <td className="px-4 py-3 text-right font-semibold text-gray-800">
                      ₹{(order.totalAmount || 0).toLocaleString("en-IN")}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                          ORDER_STATUS_COLORS[order.status] ||
                          "bg-gray-100 text-gray-600"
                        }`}
                      >
                        {order.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-500">
                      {new Date(order.createdAt).toLocaleDateString("en-IN", {
                        day: "numeric",
                        month: "short",
                        year: "numeric",
                      })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Quick Links */}
      <div>
        <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3">
          Quick Links
        </p>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { label: "Manage Users", path: "/admin/users", icon: <Users className="w-4 h-4" />, color: "text-blue-600" },
            { label: "Review Products", path: "/admin/products", icon: <Package className="w-4 h-4" />, color: "text-purple-600" },
            { label: "View Orders", path: "/admin/orders", icon: <ShoppingCart className="w-4 h-4" />, color: "text-orange-600" },
            { label: "Shipments", path: "/admin/shipments", icon: <Truck className="w-4 h-4" />, color: "text-teal-600" },
            { label: "Complaints", path: "/admin/complaints", icon: <MessageSquare className="w-4 h-4" />, color: "text-red-600" },
          ].map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className="flex items-center gap-3 bg-white border border-gray-200 rounded-xl px-4 py-3 text-sm font-medium text-gray-700 hover:border-gray-300 hover:shadow-sm transition-all"
            >
              <span className={link.color}>{link.icon}</span>
              {link.label}
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
