import { useEffect, useState, useCallback } from "react";
import {
  History as HistoryIcon,
  ChevronLeft,
  ChevronRight,
  Loader2,
  AlertCircle,
  IndianRupee,
  MapPin,
  User,
} from "lucide-react";
import API from "../../services/api";

interface HistoryItem {
  id: number;
  status: string;
  earnings: number;
  updatedAt: string;
  dropAddress: string;
  dropCity: string;
  customerName: string;
  customerPhone: string;
  Order?: {
    id: number;
    totalAmount: number;
    status: string;
    customer?: { email: string; username: string };
  };
}

interface HistoryResponse {
  total: number;
  history: HistoryItem[];
}

const STATUS_COLORS: Record<string, string> = {
  DELIVERED: "bg-green-100 text-green-700",
  RETURNED:  "bg-pink-100 text-pink-700",
  FAILED: "bg-red-100 text-red-700",
  CANCELLED: "bg-gray-100 text-gray-600",
};

const STATUS_LABELS: Record<string, string> = {
  DELIVERED: "Delivered",
  RETURNED:  "Return Delivered",
  FAILED: "Failed",
  CANCELLED: "Cancelled",
};

export default function History() {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const limit = 15;

  const fetchHistory = useCallback(() => {
    setLoading(true);
    setError("");
    API.get<HistoryResponse>(`/delivery/history?page=${page}&limit=${limit}`)
      .then((res) => {
        setHistory(res.data.history ?? []);
        setTotal(res.data.total ?? 0);
      })
      .catch(() => setError("Failed to load delivery history."))
      .finally(() => setLoading(false));
  }, [page]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  const totalPages = Math.ceil(total / limit);

  const totalDelivered = history.filter((h) => h.status === "DELIVERED").length;
  const totalEarnings = history
    .filter((h) => h.status === "DELIVERED" || h.status === "RETURNED")
    .reduce((sum, h) => sum + (h.earnings || 0), 0);

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
          <HistoryIcon className="w-5 h-5 text-green-700" />
          Delivery History
        </h1>
        <p className="text-sm text-gray-400 mt-0.5">Your completed and failed deliveries</p>
      </div>

      {/* Summary Cards */}
      {!loading && !error && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white border border-gray-200 rounded-xl px-4 py-4">
            <p className="text-2xl font-bold text-gray-900">{total}</p>
            <p className="text-xs text-gray-500 mt-0.5">Total Records</p>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl px-4 py-4">
            <p className="text-2xl font-bold text-green-700">{totalDelivered}</p>
            <p className="text-xs text-gray-500 mt-0.5">Delivered (this page)</p>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl px-4 py-4 col-span-2 md:col-span-1">
            <div className="flex items-center gap-1">
              <IndianRupee className="w-4 h-4 text-green-700" />
              <p className="text-2xl font-bold text-green-700">
                {totalEarnings.toLocaleString("en-IN")}
              </p>
            </div>
            <p className="text-xs text-gray-500 mt-0.5">Earnings (this page)</p>
          </div>
        </div>
      )}

      {/* Content */}
      {loading ? (
        <div className="flex items-center justify-center h-48">
          <Loader2 className="w-8 h-8 animate-spin text-green-600" />
        </div>
      ) : error ? (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-2 text-red-700 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />
          {error}
        </div>
      ) : history.length === 0 ? (
        <div className="text-center py-16 bg-white border border-gray-200 rounded-xl">
          <HistoryIcon className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="text-sm text-gray-400">No delivery history yet</p>
        </div>
      ) : (
        <>
          {/* Desktop Table */}
          <div className="hidden md:block bg-white border border-gray-200 rounded-xl overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Customer</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Order</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">City</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Earnings</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {history.map((item) => (
                  <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 text-gray-600">
                      {new Date(item.updatedAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                    </td>
                    <td className="px-4 py-3">
                      <p className="font-medium text-gray-800">{item.customerName}</p>
                      {item.customerPhone && <p className="text-xs text-gray-400">{item.customerPhone}</p>}
                      {item.Order?.customer?.email && <p className="text-xs text-gray-400">{item.Order.customer.email}</p>}
                    </td>
                    <td className="px-4 py-3">
                      {item.Order ? (
                        <div>
                          <p className="text-xs font-medium text-gray-700">#{item.Order.id}</p>
                          <p className="text-xs text-gray-500">₹{(item.Order.totalAmount || 0).toLocaleString("en-IN")}</p>
                        </div>
                      ) : <span className="text-gray-400 text-xs">—</span>}
                    </td>
                    <td className="px-4 py-3 text-gray-600">{item.dropCity}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[item.status] || "bg-gray-100 text-gray-600"}`}>
                        {STATUS_LABELS[item.status] || item.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      {(item.status === "DELIVERED" || item.status === "RETURNED") ? (
                        <span className={`font-semibold ${item.earnings > 0 ? "text-green-700" : "text-gray-400"}`}>
                          ₹{(item.earnings || 0).toLocaleString("en-IN")}
                        </span>
                      ) : <span className="text-gray-400">—</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Cards */}
          <div className="md:hidden space-y-3">
            {history.map((item) => (
              <div key={item.id} className="bg-white border border-gray-200 rounded-xl p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="flex items-center gap-1.5 mb-1">
                      <User className="w-3.5 h-3.5 text-gray-400" />
                      <span className="text-sm font-medium text-gray-800">{item.customerName}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-gray-400" />
                      <span className="text-xs text-gray-500">{item.dropCity}</span>
                    </div>
                    {item.Order && (
                      <p className="text-xs text-gray-400 mt-1">
                        Order #{item.Order.id} · ₹{(item.Order.totalAmount || 0).toLocaleString("en-IN")}
                      </p>
                    )}
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[item.status] || "bg-gray-100 text-gray-600"}`}>
                    {STATUS_LABELS[item.status] || item.status}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-400">
                  <span>{new Date(item.updatedAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</span>
                  {(item.status === "DELIVERED" || item.status === "RETURNED") ? (
                    <span className={`font-semibold text-sm ${item.earnings > 0 ? "text-green-700" : "text-gray-400"}`}>
                      ₹{(item.earnings || 0).toLocaleString("en-IN")}
                    </span>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-6">
          <p className="text-sm text-gray-500">
            Page {page} of {totalPages} ({total} total)
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
