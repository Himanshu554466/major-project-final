import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Package,
  ShoppingCart,
  Clock,
  CheckCircle,
  IndianRupee,
  AlertTriangle,
} from 'lucide-react';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';

interface Stats {
  totalProducts: number;
  totalOrders: number;
  pendingOrders: number;
  deliveredOrders: number;
  revenue: number;
}

interface RecentOrder {
  id: string;
  customer: { email: string };
  items: { id: string }[];
  totalAmount: number;
  status: string;
  createdAt: string;
}

interface LowStockProduct {
  id: string;
  title: string;
  stock: number;
  lowStock: number;
}

interface DashboardData {
  stats: Stats;
  recentOrders: RecentOrder[];
  lowStockProducts: LowStockProduct[];
}

const statusColors: Record<string, string> = {
  placed: 'bg-blue-100 text-blue-700',
  confirmed: 'bg-indigo-100 text-indigo-700',
  preparing: 'bg-yellow-100 text-yellow-700',
  packed: 'bg-orange-100 text-orange-700',
  shipped: 'bg-purple-100 text-purple-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
  rejected: 'bg-red-100 text-red-700',
};

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const res = await api.get('/seller/dashboard');
        setData(res.data);
      } catch {
        setError('Failed to load dashboard data.');
      } finally {
        setLoading(false);
      }
    };
    fetchDashboard();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 text-red-600 bg-red-50 rounded-lg">{error}</div>
    );
  }

  const stats = data?.stats;

  const statCards = [
    {
      label: 'Total Products',
      value: stats?.totalProducts ?? 0,
      icon: Package,
      color: 'bg-indigo-50 text-indigo-600',
      border: 'border-indigo-200',
    },
    {
      label: 'Total Orders',
      value: stats?.totalOrders ?? 0,
      icon: ShoppingCart,
      color: 'bg-orange-50 text-orange-600',
      border: 'border-orange-200',
    },
    {
      label: 'Pending Orders',
      value: stats?.pendingOrders ?? 0,
      icon: Clock,
      color: 'bg-yellow-50 text-yellow-600',
      border: 'border-yellow-200',
    },
    {
      label: 'Delivered Orders',
      value: stats?.deliveredOrders ?? 0,
      icon: CheckCircle,
      color: 'bg-green-50 text-green-600',
      border: 'border-green-200',
    },
    {
      label: 'Revenue',
      value: `₹${(stats?.revenue ?? 0).toLocaleString('en-IN')}`,
      icon: IndianRupee,
      color: 'bg-purple-50 text-purple-600',
      border: 'border-purple-200',
    },
  ];

  return (
    <div className="p-6 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">
          Welcome back, {user?.shopName || user?.username || 'Seller'} 👋
        </h1>
        <p className="text-gray-500 mt-1">Here's what's happening with your store today.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className={`bg-white rounded-xl border ${card.border} p-5 flex items-center gap-4 shadow-sm`}
            >
              <div className={`p-3 rounded-lg ${card.color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm text-gray-500">{card.label}</p>
                <p className="text-xl font-bold text-gray-900">{card.value}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h2 className="text-base font-semibold text-gray-800">Recent Orders</h2>
            <Link
              to="/seller/orders"
              className="text-sm text-indigo-600 hover:text-indigo-800 font-medium"
            >
              View all →
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 text-gray-500 text-xs uppercase">
                  <th className="px-6 py-3 text-left">Order ID</th>
                  <th className="px-6 py-3 text-left">Customer</th>
                  <th className="px-6 py-3 text-left">Items</th>
                  <th className="px-6 py-3 text-left">Total</th>
                  <th className="px-6 py-3 text-left">Status</th>
                  <th className="px-6 py-3 text-left">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {data?.recentOrders?.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-6 py-8 text-center text-gray-400">
                      No recent orders
                    </td>
                  </tr>
                )}
                {data?.recentOrders?.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-3 font-mono text-xs text-gray-600">
                      #{String(order.id).padStart(6, '0')}
                    </td>
                    <td className="px-6 py-3 text-gray-700 truncate max-w-[140px]">
                      {order.customer?.email}
                    </td>
                    <td className="px-6 py-3 text-gray-600">{order.items?.length ?? 0}</td>
                    <td className="px-6 py-3 font-medium text-gray-800">
                      ₹{order.totalAmount?.toLocaleString('en-IN')}
                    </td>
                    <td className="px-6 py-3">
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-medium capitalize ${
                          statusColors[order.status] ?? 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {order.status}
                      </span>
                    </td>
                    <td className="px-6 py-3 text-gray-500 text-xs">
                      {new Date(order.createdAt).toLocaleDateString('en-IN')}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Low Stock Products */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
            <h2 className="text-base font-semibold text-gray-800 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-orange-500" />
              Low Stock
            </h2>
            <Link
              to="/seller/inventory"
              className="text-sm text-indigo-600 hover:text-indigo-800 font-medium"
            >
              Manage →
            </Link>
          </div>
          <div className="divide-y divide-gray-100">
            {data?.lowStockProducts?.length === 0 && (
              <p className="px-6 py-8 text-center text-gray-400 text-sm">
                All products are well stocked
              </p>
            )}
            {data?.lowStockProducts?.map((product) => (
              <div key={product.id} className="px-6 py-4 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-gray-800 truncate">{product.title}</p>
                  <p className="text-xs text-gray-500 mt-0.5">
                    Stock:{' '}
                    <span className="text-red-600 font-semibold">{product.stock}</span>
                    {' / '}
                    <span className="text-gray-400">threshold: {product.lowStock}</span>
                  </p>
                </div>
                <Link
                  to="/seller/inventory"
                  className="text-xs text-indigo-600 hover:text-indigo-800 font-medium whitespace-nowrap"
                >
                  Update
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
