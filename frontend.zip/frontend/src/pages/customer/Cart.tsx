import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';

export default function Cart() {
  const navigate = useNavigate();
  const { cartItems, cartTotal, loading, updateQty, removeFromCart } = useCart();

  // Calculate delivery charge: use the highest deliveryCharge among items,
  // but waive it if cartTotal >= freeDeliveryAbove threshold (or >= 499 fallback)
  const deliveryCharge = (() => {
    if (cartItems.length === 0) return 0;
    let charge = 0;
    for (const item of cartItems) {
      const itemCharge = item.product.deliveryCharge ?? 0;
      const freeAbove = item.product.freeDeliveryAbove ?? 499;
      // If cart total is below the free-delivery threshold, add this item's charge
      if (cartTotal < freeAbove && itemCharge > charge) {
        charge = itemCharge;
      }
    }
    // Fallback: if no product-level charge but total < 499, use ₹49
    if (charge === 0 && cartTotal < 499) {
      const hasAnyCharge = cartItems.some(i => (i.product.deliveryCharge ?? 0) > 0);
      if (!hasAnyCharge) charge = 49;
    }
    return charge;
  })();

  const total = cartTotal + deliveryCharge;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#EAEDED]">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="space-y-4">
            {[1, 2].map(i => (
              <div key={i} className="bg-white border border-[#ddd] rounded-lg p-4 animate-pulse flex gap-4">
                <div className="w-24 h-24 bg-[#f3f3f3] rounded flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-[#f3f3f3] rounded w-3/4" />
                  <div className="h-3 bg-[#f3f3f3] rounded w-1/2" />
                  <div className="h-4 bg-[#f3f3f3] rounded w-1/4" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-[#EAEDED]">
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <div className="bg-white border border-[#ddd] rounded-lg p-12 inline-block">
            <svg className="w-20 h-20 text-[#ddd] mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
            </svg>
            <h2 className="text-2xl font-medium text-[#0f1111] mb-2">Your Shopping Cart is empty</h2>
            <p className="text-[#555] text-sm mb-6">You have no items in your shopping cart.</p>
            <Link to="/products"
              className="inline-block px-8 py-2.5 bg-[#FFD814] hover:bg-[#7c3aed] border border-[#FCD200] rounded text-sm font-semibold text-[#111] transition-colors">
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#EAEDED]">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-5 items-start">

          {/* Cart Items */}
          <div className="flex-1 min-w-0">
            <div className="bg-white border border-[#ddd] rounded-lg overflow-hidden">
              <div className="px-6 py-4 border-b border-[#eee] flex items-center justify-between">
                <h1 className="text-2xl font-medium text-[#0f1111]">Shopping Cart</h1>
                <span className="text-sm text-[#555]">Price</span>
              </div>

              <div className="divide-y divide-[#eee]">
                {cartItems.map(item => {
                  const price = item.variant?.price ?? item.product?.price ?? 0;
                  const imageUrl = item.product?.images?.[0]?.url;
                  const variantLabel = [item.variant?.color, item.variant?.size].filter(Boolean).join(', ');

                  return (
                    <div key={item.id} className="px-6 py-5 flex gap-5">
                      {/* Image */}
                      <div className="w-24 h-24 flex-shrink-0 bg-white border border-[#f0f0f0] rounded flex items-center justify-center p-2">
                        {imageUrl ? (
                          <img src={imageUrl} alt={item.product.title} className="max-h-full max-w-full object-contain" />
                        ) : (
                          <span className="text-3xl text-[#ddd]">📦</span>
                        )}
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <Link to={`/products/${item.product.id}`}
                          className="text-base font-medium text-[#0f1111] hover:text-[#5b21b6] line-clamp-2 transition-colors">
                          {item.product.title}
                        </Link>
                        {variantLabel && <p className="text-sm text-[#555] mt-0.5">{variantLabel}</p>}
                        <p className="text-[#007600] text-sm mt-1">In Stock</p>

                        {/* Quantity controls */}
                        <div className="flex items-center gap-3 mt-3">
                          <div className="flex items-center border border-[#888c8c] rounded overflow-hidden">
                            <button
                              onClick={() => { if (item.quantity <= 1) removeFromCart(item.id); else updateQty(item.id, item.quantity - 1); }}
                              className="px-3 py-1.5 bg-[#f0f0f0] hover:bg-[#e0e0e0] text-[#111] text-sm font-bold transition-colors border-r border-[#888c8c]"
                            >−</button>
                            <span className="px-4 py-1.5 text-sm font-semibold text-[#111] bg-white min-w-[3rem] text-center">{item.quantity}</span>
                            <button
                              onClick={() => updateQty(item.id, item.quantity + 1)}
                              className="px-3 py-1.5 bg-[#f0f0f0] hover:bg-[#e0e0e0] text-[#111] text-sm font-bold transition-colors border-l border-[#888c8c]"
                            >+</button>
                          </div>
                          <span className="text-[#888c8c] text-sm">|</span>
                          <button onClick={() => removeFromCart(item.id)}
                            className="text-sm text-[#0066c0] hover:text-[#5b21b6] hover:underline transition-colors">
                            Delete
                          </button>
                          <span className="text-[#888c8c] text-sm">|</span>
                          <button className="text-sm text-[#0066c0] hover:text-[#5b21b6] hover:underline transition-colors">
                            Save for later
                          </button>
                        </div>
                      </div>

                      {/* Price */}
                      <div className="text-right shrink-0">
                        <p className="text-lg font-bold text-[#0f1111]">₹{(price * item.quantity).toLocaleString('en-IN')}</p>
                        {item.quantity > 1 && (
                          <p className="text-xs text-[#555]">₹{price.toLocaleString('en-IN')} each</p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Subtotal at bottom */}
              <div className="px-6 py-4 border-t border-[#eee] text-right">
                <p className="text-lg text-[#0f1111]">
                  Subtotal ({cartItems.reduce((s, i) => s + i.quantity, 0)} items):{' '}
                  <span className="font-bold">₹{cartTotal.toLocaleString('en-IN')}</span>
                </p>
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:w-80 flex-shrink-0">
            <div className="bg-white border border-[#ddd] rounded-lg p-5">
              {deliveryCharge === 0 && (
                <div className="flex items-center gap-2 mb-4 text-[#007600] text-sm font-medium">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  Your order qualifies for FREE Delivery
                </div>
              )}

              <p className="text-lg text-[#0f1111] mb-1">
                Subtotal ({cartItems.reduce((s, i) => s + i.quantity, 0)} items):{' '}
                <span className="font-bold">₹{cartTotal.toLocaleString('en-IN')}</span>
              </p>

              <div className="space-y-1 text-sm text-[#555] mb-4">
                <div className="flex justify-between">
                  <span>Delivery</span>
                  {deliveryCharge === 0 ? (
                    <span className="text-[#007600] font-medium">FREE</span>
                  ) : (
                    <span>₹{deliveryCharge}</span>
                  )}
                </div>
                <div className="flex justify-between font-bold text-[#0f1111] text-base border-t border-[#eee] pt-2 mt-2">
                  <span>Order Total</span>
                  <span>₹{total.toLocaleString('en-IN')}</span>
                </div>
              </div>

              {deliveryCharge > 0 && (
                <p className="text-xs text-[#555] mb-4 bg-[#ede9fe] border border-[#FFD814] rounded px-3 py-2">
                  Add ₹{(499 - cartTotal).toLocaleString('en-IN')} more for FREE delivery
                </p>
              )}

              <button onClick={() => navigate('/checkout')}
                className="w-full py-2.5 bg-[#FFD814] hover:bg-[#7c3aed] border border-[#FCD200] rounded text-sm font-semibold text-[#111] transition-colors">
                Proceed to Buy
              </button>

              <Link to="/products"
                className="block text-center mt-3 text-sm text-[#0066c0] hover:text-[#5b21b6] hover:underline">
                Continue Shopping
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
