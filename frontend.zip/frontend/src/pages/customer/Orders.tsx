import React, { useEffect, useState, useCallback } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import {
  Package, ChevronRight, ChevronLeft, MapPin, Truck,
  CheckCircle, XCircle, Clock, Loader2, RotateCcw, AlertCircle,
} from 'lucide-react';
import api from '../../services/api';

interface OrderItem {
  id: string;
  quantity: number;
  price: number;
  product: { title: string; images: { id: string; url: string }[] };
  variant?: { color?: string; size?: string };
}

interface Order {
  id: string;
  status: string;
  totalAmount: number;
  paymentMethod: string;
  paymentStatus: string;
  createdAt: string;
  returnReason?: string;
  items: OrderItem[];
  address: { name: string; phone: string; line1: string; city: string; pincode: string };
}

const STATUS_TABS = ['All', 'placed', 'confirmed', 'shipped', 'delivered', 'return_requested', 'returned', 'cancelled'];

const STATUS_BADGE: Record<string, string> = {
  placed: 'bg-blue-100 text-blue-700',
  confirmed: 'bg-indigo-100 text-indigo-700',
  preparing: 'bg-yellow-100 text-yellow-700',
  packed: 'bg-orange-100 text-orange-700',
  shipped: 'bg-purple-100 text-purple-700',
  out_for_delivery: 'bg-cyan-100 text-cyan-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
  return_requested: 'bg-pink-100 text-pink-700',
  return_approved: 'bg-orange-100 text-orange-700',
  returned: 'bg-teal-100 text-teal-700',
  refund_initiated: 'bg-yellow-100 text-yellow-700',
  refund_completed: 'bg-green-100 text-green-700',
};

const STATUS_ICON: Record<string, React.ReactNode> = {
  placed: <Clock className="w-3.5 h-3.5" />,
  confirmed: <CheckCircle className="w-3.5 h-3.5" />,
  preparing: <Package className="w-3.5 h-3.5" />,
  packed: <Package className="w-3.5 h-3.5" />,
  shipped: <Truck className="w-3.5 h-3.5" />,
  out_for_delivery: <Truck className="w-3.5 h-3.5" />,
  delivered: <CheckCircle className="w-3.5 h-3.5" />,
  cancelled: <XCircle className="w-3.5 h-3.5" />,
  return_requested: <RotateCcw className="w-3.5 h-3.5" />,
  return_approved: <RotateCcw className="w-3.5 h-3.5" />,
  returned: <CheckCircle className="w-3.5 h-3.5" />,
  refund_initiated: <Clock className="w-3.5 h-3.5" />,
  refund_completed: <CheckCircle className="w-3.5 h-3.5" />,
};

const ACTIVE_STATUSES = ['placed', 'confirmed', 'preparing', 'packed', 'shipped', 'out_for_delivery'];

// ── Return Request Modal ─────────────────────────────────────────────────────
function ReturnModal({ order, onClose, onSuccess }: {
  order: Order;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [reason, setReason] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const RETURN_REASONS = [
    'Wrong item received',
    'Item damaged or defective',
    'Item not as described',
    'Changed my mind',
    'Better price available elsewhere',
    'Other',
  ];

  const handleSubmit = async () => {
    if (!reason.trim()) { setError('Please select or enter a reason.'); return; }
    setSubmitting(true);
    setError('');
    try {
      await api.post(`/customer/orders/${order.id}/return`, { reason });
      onSuccess();
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
      setError(msg || 'Failed to submit return request.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <RotateCcw className="w-5 h-5 text-orange-500" />
            <h2 className="text-base font-bold text-gray-900">Request Return</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl leading-none">×</button>
        </div>

        <div className="p-6 space-y-4">
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-3 text-sm text-orange-800">
            <p className="font-semibold">Order #{String(order.id).padStart(6, '0')}</p>
            <p className="text-xs mt-0.5 text-orange-600">
              Once approved by the seller, a delivery partner will be assigned to pick up the item from you.
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Reason for Return *</label>
            <div className="space-y-2">
              {RETURN_REASONS.map(r => (
                <label key={r} className={`flex items-center gap-3 p-3 rounded-xl border-2 cursor-pointer transition-colors ${
                  reason === r ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-orange-200'
                }`}>
                  <input type="radio" name="reason" value={r} checked={reason === r}
                    onChange={() => setReason(r)} className="accent-orange-500" />
                  <span className="text-sm text-gray-700">{r}</span>
                </label>
              ))}
            </div>
            {reason === 'Other' && (
              <textarea
                placeholder="Please describe your reason..."
                rows={3}
                className="mt-2 w-full border border-gray-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 resize-none"
                onChange={e => setReason(e.target.value === '' ? 'Other' : e.target.value)}
              />
            )}
          </div>

          {error && (
            <p className="text-sm text-red-500 flex items-center gap-1">
              <AlertCircle className="w-4 h-4" /> {error}
            </p>
          )}
        </div>

        <div className="flex gap-3 px-6 py-4 border-t border-gray-100">
          <button onClick={onClose}
            className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50">
            Cancel
          </button>
          <button onClick={handleSubmit} disabled={submitting}
            className="flex-1 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-sm font-semibold disabled:opacity-50 flex items-center justify-center gap-2">
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />}
            {submitting ? 'Submitting...' : 'Submit Return'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main Component ───────────────────────────────────────────────────────────
export default function Orders() {
  const navigate = useNavigate();
  const location = useLocation();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('All');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [successMsg, setSuccessMsg] = useState('');
  const [returnOrder, setReturnOrder] = useState<Order | null>(null);

  useEffect(() => {
    if ((location.state as { success?: boolean })?.success) {
      setSuccessMsg('Order placed successfully! 🎉');
      setTimeout(() => setSuccessMsg(''), 4000);
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location, navigate]);

  const fetchOrders = useCallback(() => {
    setLoading(true);
    const params = new URLSearchParams({ page: String(page), limit: '10' });
    if (activeTab !== 'All') params.set('status', activeTab);
    api.get(`/customer/orders?${params.toString()}`)
      .then(res => {
        setOrders(res.data.orders || res.data || []);
        const total = res.data.total ?? 0;
        setTotalPages(Math.ceil(total / 10) || 1);
      })
      .catch(() => setOrders([]))
      .finally(() => setLoading(false));
  }, [activeTab, page]);

  useEffect(() => { fetchOrders(); }, [fetchOrders]);

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

  const handleReturnSuccess = () => {
    setReturnOrder(null);
    setSuccessMsg('Return request submitted! The seller will review it shortly.');
    setTimeout(() => setSuccessMsg(''), 5000);
    fetchOrders();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {returnOrder && (
        <ReturnModal
          order={returnOrder}
          onClose={() => setReturnOrder(null)}
          onSuccess={handleReturnSuccess}
        />
      )}

      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">My Orders</h1>

        {successMsg && (
          <div className="mb-4 bg-green-50 border border-green-200 text-green-700 rounded-xl px-4 py-3 flex items-center gap-2">
            <CheckCircle className="w-5 h-5" /> {successMsg}
          </div>
        )}

        {/* Status Tabs */}
        <div className="flex gap-1 overflow-x-auto pb-1 mb-6 bg-white rounded-xl shadow-sm p-1">
          {STATUS_TABS.map(tab => (
            <button key={tab} onClick={() => { setActiveTab(tab); setPage(1); }}
              className={`flex-shrink-0 px-3 py-2 rounded-lg text-xs font-medium transition-colors capitalize ${
                activeTab === tab ? 'bg-orange-500 text-white' : 'text-gray-600 hover:bg-gray-100'
              }`}>
              {tab.replace(/_/g, ' ')}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-20">
            <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-lg font-semibold text-gray-600">No orders found</p>
            <p className="text-sm text-gray-400 mt-1">
              {activeTab === 'All' ? "You haven't placed any orders yet." : `No ${activeTab.replace(/_/g, ' ')} orders.`}
            </p>
            <Link to="/products" className="mt-4 inline-block text-orange-500 hover:text-orange-600 font-medium text-sm">
              Start Shopping →
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map(order => {
              const firstItem = order.items?.[0];
              const moreCount = (order.items?.length ?? 0) - 1;
              const isActive = ACTIVE_STATUSES.includes(order.status);
              const canReturn = order.status === 'delivered';
              const imageUrl = firstItem?.product?.images?.[0]?.url;

              return (
                <div key={order.id} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                  {/* Header */}
                  <div className="flex items-center justify-between px-5 py-3 border-b border-gray-100 bg-gray-50">
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-gray-500">Order #{String(order.id).padStart(6, '0')}</span>
                      <span className="text-xs text-gray-400">·</span>
                      <span className="text-xs text-gray-500">{formatDate(order.createdAt)}</span>
                    </div>
                    <span className={`flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full capitalize ${STATUS_BADGE[order.status] || 'bg-gray-100 text-gray-600'}`}>
                      {STATUS_ICON[order.status]}
                      {order.status.replace(/_/g, ' ')}
                    </span>
                  </div>

                  {/* Body */}
                  <div className="px-5 py-4 flex items-center gap-4">
                    <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                      {imageUrl ? (
                        <img src={imageUrl} alt={firstItem?.product?.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Package className="w-7 h-7 text-gray-300" />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-800 line-clamp-1">
                        {firstItem?.product?.title}
                      </p>
                      {moreCount > 0 && (
                        <p className="text-xs text-gray-500 mt-0.5">+{moreCount} more item{moreCount > 1 ? 's' : ''}</p>
                      )}
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-sm font-bold text-gray-900">₹{order.totalAmount.toLocaleString()}</span>
                        <span className="text-xs text-gray-400 capitalize">{order.paymentMethod?.replace(/_/g, ' ')}</span>
                      </div>
                      {/* Return reason if already requested */}
                      {order.returnReason && ['return_requested', 'return_approved'].includes(order.status) && (
                        <p className="text-xs text-pink-600 mt-1">↩ Return: {order.returnReason}</p>
                      )}
                      {/* Refund info */}
                      {order.status === 'refund_completed' && (
                        <p className="text-xs text-green-600 mt-1 font-medium">✓ Refund processed</p>
                      )}
                    </div>

                    <div className="flex flex-col gap-2 flex-shrink-0 items-end">
                      <button onClick={() => navigate(`/orders/${order.id}`)}
                        className="flex items-center gap-1 text-sm text-orange-500 hover:text-orange-600 font-medium">
                        Details <ChevronRight className="w-4 h-4" />
                      </button>
                      {isActive && (
                        <button onClick={() => navigate(`/orders/${order.id}/track`)}
                          className="flex items-center gap-1 text-xs text-indigo-500 hover:text-indigo-600 font-medium">
                          <MapPin className="w-3.5 h-3.5" /> Track
                        </button>
                      )}
                      {canReturn && (
                        <button onClick={() => setReturnOrder(order)}
                          className="flex items-center gap-1 text-xs text-pink-500 hover:text-pink-600 font-medium border border-pink-200 rounded-lg px-2 py-1 hover:bg-pink-50 transition-colors">
                          <RotateCcw className="w-3 h-3" /> Return
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-8">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="p-2 rounded-lg border border-gray-200 disabled:opacity-40 hover:bg-gray-50">
              <ChevronLeft className="w-4 h-4" />
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
              <button key={p} onClick={() => setPage(p)}
                className={`w-9 h-9 rounded-lg text-sm font-medium transition-colors ${
                  p === page ? 'bg-orange-500 text-white' : 'border border-gray-200 hover:bg-gray-50 text-gray-700'
                }`}>
                {p}
              </button>
            ))}
            <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="p-2 rounded-lg border border-gray-200 disabled:opacity-40 hover:bg-gray-50">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
