import { useEffect, useState, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  Package, MapPin, User, Phone, IndianRupee,
  ChevronLeft, ChevronRight, Loader2, AlertCircle,
  CheckCircle, XCircle, Bell,
} from "lucide-react";
import { io, Socket } from "socket.io-client";
import API from "../../services/api";
import { useAuth } from "../../context/AuthContext";
import { SOCKET_URL } from "../../config";

interface Shipment {
  id: number;
  status: string;
  dropAddress: string;
  dropCity: string;
  dropPincode: string;
  customerName: string;
  customerPhone: string;
  earnings: number;
  isReturn?: boolean;
  returnReason?: string;
  Order?: { id: number; totalAmount: number };
}

interface AssignmentRequest {
  shipmentId: number;
  orderId: number;
  dropCity: string;
  dropPincode: string;
  dropAddress: string;
  customerName: string;
  earnings: number;
  isReturn?: boolean;
  broadcastAt: string;
}

const STATUS_LABELS: Record<string, string> = {
  ASSIGNED: "Assigned",
  ACCEPTED: "Accepted",
  PICKED_UP: "Picked Up",
  IN_TRANSIT: "In Transit",
  OUT_FOR_DELIVERY: "Out for Delivery",
  DELIVERED: "Delivered",
  FAILED: "Failed",
};

const STATUS_COLORS: Record<string, string> = {
  ASSIGNED: "bg-yellow-100 text-yellow-700",
  ACCEPTED: "bg-blue-100 text-blue-700",
  PICKED_UP: "bg-indigo-100 text-indigo-700",
  IN_TRANSIT: "bg-purple-100 text-purple-700",
  OUT_FOR_DELIVERY: "bg-orange-100 text-orange-700",
  DELIVERED: "bg-green-100 text-green-700",
  FAILED: "bg-red-100 text-red-700",
};

const NEXT_ACTION: Record<string, { label: string; status: string; color: string }> = {
  ACCEPTED: { label: "Mark Picked Up", status: "PICKED_UP", color: "bg-indigo-600 hover:bg-indigo-700" },
  PICKED_UP: { label: "In Transit", status: "IN_TRANSIT", color: "bg-purple-600 hover:bg-purple-700" },
  IN_TRANSIT: { label: "Out for Delivery", status: "OUT_FOR_DELIVERY", color: "bg-orange-600 hover:bg-orange-700" },
};

export default function Shipments() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<"pending" | "active" | "all">("pending");
  const [pendingRequests, setPendingRequests] = useState<AssignmentRequest[]>([]);
  const [activeShipments, setActiveShipments] = useState<Shipment[]>([]);
  const [allShipments, setAllShipments] = useState<Shipment[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<number | null>(null);
  const [error, setError] = useState("");
  const socketRef = useRef<Socket | null>(null);
  const navigate = useNavigate();
  const limit = 10;

  // ── Fetch pending requests from API (survives page reload) ────────────────
  const fetchPending = useCallback(() => {
    API.get<{ shipments: Shipment[] }>("/delivery/shipments/pending")
      .then(res => {
        const shipments = res.data.shipments || [];
        // Replace state with fresh API data — removes any that were accepted by others
        setPendingRequests(shipments.map(s => ({
          shipmentId: s.id,
          orderId: (s as any).Order?.id || (s as any).orderId || 0,
          dropCity: s.dropCity,
          dropPincode: s.dropPincode,
          dropAddress: s.dropAddress,
          customerName: s.customerName,
          earnings: s.earnings,
          isReturn: s.isReturn,
          broadcastAt: (s as any).createdAt || new Date().toISOString(),
        })));
      })
      .catch(() => {});
  }, []);

  // Socket.io — listen for new assignment broadcasts
  useEffect(() => {
    if (!user?.id) return;
    const socket = io(SOCKET_URL, {
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
    });
    socketRef.current = socket;

    socket.on("connect", () => {
      socket.emit("partner:join", user.id);
      // Re-fetch pending on reconnect to catch any missed broadcasts
      fetchPending();
    });

    socket.on("delivery:new_assignment_request", (data: AssignmentRequest) => {
      setPendingRequests(prev => {
        if (prev.find(r => r.shipmentId === data.shipmentId)) return prev;
        return [data, ...prev];
      });
      setActiveTab("pending");
    });

    socket.on("delivery:assignment_taken", (data: { shipmentId: number }) => {
      setPendingRequests(prev => prev.filter(r => r.shipmentId !== data.shipmentId));
    });

    return () => { socket.disconnect(); };
  }, [user?.id, fetchPending]);

  // Fetch pending on mount + every 1 minute
  useEffect(() => {
    fetchPending();
    const interval = setInterval(fetchPending, 60000);
    return () => clearInterval(interval);
  }, [fetchPending]);

  const fetchActive = useCallback(() => {
    return API.get<{ shipments: Shipment[] } | Shipment[]>("/delivery/shipments/active").then((res) => {
      const data = res.data as any;
      setActiveShipments(Array.isArray(data) ? data : (data.shipments ?? []));
    });
  }, []);

  const fetchAll = useCallback(() => {
    const params = new URLSearchParams({
      page: String(page), limit: String(limit),
      ...(statusFilter ? { status: statusFilter } : {}),
    });
    return API.get<{ shipments: Shipment[]; total: number }>(`/delivery/shipments?${params}`).then((res) => {
      setAllShipments(res.data.shipments ?? (res.data as unknown as Shipment[]));
      setTotal(res.data.total ?? 0);
    });
  }, [page, statusFilter]);

  useEffect(() => {
    setLoading(true);
    setError("");
    const fetch = activeTab === "active" ? fetchActive()
      : activeTab === "all" ? fetchAll()
      : Promise.resolve(); // pending tab — fetched separately
    fetch.catch(() => setError("Failed to load shipments.")).finally(() => setLoading(false));

    // Auto-refresh every 1 minute
    const interval = setInterval(() => {
      if (activeTab === "active") fetchActive().catch(() => {});
      else if (activeTab === "all") fetchAll().catch(() => {});
    }, 60000);
    return () => clearInterval(interval);
  }, [activeTab, fetchActive, fetchAll]);

  // Accept a broadcast shipment
  const handleAccept = async (shipmentId: number) => {
    setActionLoading(shipmentId);
    try {
      await API.post(`/delivery/shipments/${shipmentId}/accept`);
      setPendingRequests(prev => prev.filter(r => r.shipmentId !== shipmentId));
      setActiveTab("active");
      fetchActive();
      fetchPending(); // refresh pending list
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
      if (msg?.includes("already")) {
        setPendingRequests(prev => prev.filter(r => r.shipmentId !== shipmentId));
        fetchPending();
        alert("This shipment was already accepted by another partner.");
      } else {
        alert(msg || "Failed to accept shipment.");
      }
    } finally {
      setActionLoading(null);
    }
  };

  // Decline a broadcast request — call API to record decline, then remove from local list
  const handleDeclineRequest = async (shipmentId: number) => {
    setActionLoading(shipmentId);
    try {
      await API.post(`/delivery/shipments/${shipmentId}/decline-request`);
    } catch {
      // Even if API fails, remove from local list so it doesn't bother the partner
    } finally {
      setPendingRequests(prev => prev.filter(r => r.shipmentId !== shipmentId));
      setActionLoading(null);
    }
  };

  // Decline an already-ASSIGNED shipment
  const handleDeclineAssigned = async (shipmentId: number) => {
    const reason = window.prompt("Reason for declining (optional):") ?? "No reason given";
    setActionLoading(shipmentId);
    try {
      await API.post(`/delivery/shipments/${shipmentId}/decline`, { reason });
      fetchActive();
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { message?: string } } })?.response?.data?.message;
      alert(msg || "Failed to decline shipment.");
    } finally {
      setActionLoading(null);
    }
  };

  const handleStatusAction = async (shipmentId: number, status: string) => {
    setActionLoading(shipmentId);
    try {
      await API.put(`/delivery/shipments/${shipmentId}/status`, { status });
      if (activeTab === "active") fetchActive();
      else fetchAll();
    } catch {
      // silently fail
    } finally {
      setActionLoading(null);
    }
  };

  const totalPages = Math.ceil(total / limit);

  const ShipmentCard = ({ shipment }: { shipment: Shipment }) => {
    // For return shipments, use different action labels
    const RETURN_NEXT_ACTION: Record<string, { label: string; status: string; color: string }> = {
      ACCEPTED: { label: "Mark Picked Up", status: "PICKED_UP", color: "bg-indigo-600 hover:bg-indigo-700" },
      PICKED_UP: { label: "In Transit to Seller", status: "IN_TRANSIT", color: "bg-purple-600 hover:bg-purple-700" },
      IN_TRANSIT: { label: "Arriving at Seller", status: "OUT_FOR_DELIVERY", color: "bg-orange-600 hover:bg-orange-700" },
    };

    const nextAction = shipment.isReturn
      ? RETURN_NEXT_ACTION[shipment.status]
      : NEXT_ACTION[shipment.status];
    const isOutForDelivery = shipment.status === "OUT_FOR_DELIVERY";

    return (
      <div
        className="bg-white border border-gray-200 rounded-xl p-4 hover:border-green-300 transition-colors cursor-pointer"
        onClick={() => navigate(`/delivery/shipments/${shipment.id}`)}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[shipment.status] || "bg-gray-100 text-gray-600"}`}>
                {STATUS_LABELS[shipment.status] || shipment.status}
              </span>
              <span className="text-xs text-gray-400">#{shipment.id}</span>
              {shipment.isReturn && (
                <span className="text-xs bg-pink-100 text-pink-700 px-2 py-0.5 rounded-full font-medium">↩ RETURN</span>
              )}
            </div>
            <div className="flex items-center gap-1.5 mb-1">
              <User className="w-3.5 h-3.5 text-gray-400 shrink-0" />
              <span className="text-sm font-medium text-gray-900">{shipment.customerName}</span>
            </div>
            {shipment.customerPhone && (
              <div className="flex items-center gap-1.5 mb-1">
                <Phone className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                <span className="text-xs text-gray-500">{shipment.customerPhone}</span>
              </div>
            )}
            <div className="flex items-start gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-gray-400 shrink-0 mt-0.5" />
              <span className="text-xs text-gray-500">
                {shipment.dropAddress}, {shipment.dropCity} - {shipment.dropPincode}
              </span>
            </div>
            <div className="flex items-center gap-1 mt-2">
              <IndianRupee className="w-3.5 h-3.5 text-green-700" />
              <span className="text-sm font-semibold text-green-700">
                {(shipment.earnings || 0).toLocaleString("en-IN")}
              </span>
            </div>
          </div>

          <div className="flex flex-col gap-2 shrink-0" onClick={(e) => e.stopPropagation()}>
            {nextAction && (
              <button
                onClick={() => handleStatusAction(shipment.id, nextAction.status)}
                disabled={actionLoading === shipment.id}
                className={`text-xs px-3 py-1.5 text-white rounded-lg disabled:opacity-50 flex items-center gap-1 ${nextAction.color}`}
              >
                {actionLoading === shipment.id && <Loader2 className="w-3 h-3 animate-spin" />}
                {nextAction.label}
              </button>
            )}
            {shipment.status === "ASSIGNED" && (
              <button
                onClick={() => handleDeclineAssigned(shipment.id)}
                disabled={actionLoading === shipment.id}
                className="text-xs px-3 py-1.5 bg-red-100 text-red-700 hover:bg-red-200 rounded-lg disabled:opacity-50"
              >
                Decline
              </button>
            )}
            {isOutForDelivery && (
              <>
                <button
                  onClick={() => navigate(`/delivery/shipments/${shipment.id}?action=deliver`)}
                  className="text-xs px-3 py-1.5 bg-green-700 text-white rounded-lg hover:bg-green-800"
                >
                  {shipment.isReturn ? 'Delivered to Seller' : 'Mark Delivered'}
                </button>
                <button
                  onClick={() => navigate(`/delivery/shipments/${shipment.id}?action=fail`)}
                  className="text-xs px-3 py-1.5 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Report Failed
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
          <Package className="w-5 h-5 text-green-700" />
          Shipments
        </h1>
        <p className="text-sm text-gray-400 mt-0.5">Manage your delivery tasks</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 rounded-xl p-1 mb-6 w-fit">
        {([
          { key: "pending", label: "New Requests" },
          { key: "active", label: "Active" },
          { key: "all", label: "All Shipments" },
        ] as const).map(({ key, label }) => (
          <button
            key={key}
            onClick={() => { setActiveTab(key); setPage(1); }}
            className={`relative px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeTab === key ? "bg-white text-green-700 shadow-sm" : "text-gray-500 hover:text-gray-700"
            }`}
          >
            {label}
            {key === "pending" && pendingRequests.length > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                {pendingRequests.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* ── Pending Requests Tab ── */}
      {activeTab === "pending" && (
        <div>
          {pendingRequests.length === 0 ? (
            <div className="text-center py-16 bg-white border border-gray-200 rounded-xl">
              <Bell className="w-12 h-12 text-gray-200 mx-auto mb-3" />
              <p className="text-sm font-medium text-gray-500">No new delivery requests</p>
              <p className="text-xs text-gray-400 mt-1">New orders matching your city & pincode will appear here</p>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingRequests.map(req => (
                <div key={req.shipmentId} className="bg-white border-2 border-green-400 rounded-xl p-5 shadow-sm">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-3">
                        <span className="text-sm font-bold text-green-700">
                          {req.isReturn ? '↩ Return Pickup Request' : '🚚 New Delivery Request'}
                        </span>
                        <span className="text-xs text-gray-400">Shipment #{req.shipmentId}</span>
                        {req.isReturn && (
                          <span className="text-xs bg-pink-100 text-pink-700 px-2 py-0.5 rounded-full font-medium">RETURN</span>
                        )}
                      </div>
                      <div className="space-y-1.5 text-sm text-gray-600">
                        <div className="flex items-start gap-2">
                          <MapPin className="w-4 h-4 text-gray-400 shrink-0 mt-0.5" />
                          <span>{req.dropAddress || "—"}, {req.dropCity} - {req.dropPincode}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-gray-400 shrink-0" />
                          <span>{req.customerName || "Customer"}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <IndianRupee className="w-4 h-4 text-green-600 shrink-0" />
                          <span className="font-semibold text-green-700">₹{req.earnings || 0} earnings</span>
                        </div>
                        <p className="text-xs text-gray-400">
                          Received: {new Date(req.broadcastAt).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2 shrink-0">
                      <button
                        onClick={() => handleAccept(req.shipmentId)}
                        disabled={actionLoading === req.shipmentId}
                        className="flex items-center gap-1.5 px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-semibold rounded-xl disabled:opacity-50"
                      >
                        {actionLoading === req.shipmentId
                          ? <Loader2 className="w-4 h-4 animate-spin" />
                          : <CheckCircle className="w-4 h-4" />}
                        Accept
                      </button>
                      <button
                        onClick={() => handleDeclineRequest(req.shipmentId)}
                        disabled={actionLoading === req.shipmentId}
                        className="flex items-center gap-1.5 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-medium rounded-xl disabled:opacity-50"
                      >
                        <XCircle className="w-4 h-4" />
                        Decline
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Active / All Tabs ── */}
      {activeTab !== "pending" && (
        <>
          {/* Filters for All tab */}
          {activeTab === "all" && (
            <div className="mb-4">
              <select
                value={statusFilter}
                onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
                className="text-sm border border-gray-200 rounded-lg px-3 py-2 text-gray-700 focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="">All Statuses</option>
                {Object.entries(STATUS_LABELS).map(([val, label]) => (
                  <option key={val} value={val}>{label}</option>
                ))}
              </select>
            </div>
          )}

          {loading ? (
            <div className="flex items-center justify-center h-48">
              <Loader2 className="w-8 h-8 animate-spin text-green-600" />
            </div>
          ) : error ? (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-2 text-red-700 text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />{error}
            </div>
          ) : (activeTab === "active" ? activeShipments : allShipments).length === 0 ? (
            <div className="text-center py-16 bg-white border border-gray-200 rounded-xl">
              <Package className="w-12 h-12 text-gray-200 mx-auto mb-3" />
              <p className="text-sm text-gray-400">No shipments found</p>
            </div>
          ) : (
            <div className="space-y-3">
              {(activeTab === "active" ? activeShipments : allShipments).map(shipment => (
                <ShipmentCard key={shipment.id} shipment={shipment} />
              ))}
            </div>
          )}

          {activeTab === "all" && totalPages > 1 && (
            <div className="flex items-center justify-between mt-6">
              <p className="text-sm text-gray-500">Page {page} of {totalPages} ({total} total)</p>
              <div className="flex gap-2">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
                  className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
                  className="p-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 disabled:opacity-40">
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
